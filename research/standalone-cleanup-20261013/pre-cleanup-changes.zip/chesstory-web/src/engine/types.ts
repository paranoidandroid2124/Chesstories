import type { Uci, VariantKey, Tree } from '../review/types';
import { isMoveReviewEngineProfile, moveReviewEngineProfile, moveReviewEngineProfileSpec, type MoveReviewEngineProfile, type MoveReviewVariant } from './profiles';
export { isMoveReviewEngineProfile, moveReviewEngineProfile };
export type { MoveReviewEngineProfile, MoveReviewVariant };
export type Feature = 'wasm' | 'sharedMem' | 'simd' | 'dynamicImportFromWorker' | 'bigint' | 'structuredClone';

export type WinningChances = number;
export type SearchBy = { movetime: number } | { depth: number } | { nodes: number };
export type Search = { by: SearchBy; multiPv: number; indeterminate?: boolean };
export type Millis = number;

export interface Work {
  variant: VariantKey;
  threads: number;
  hashSize: number | undefined;
  gameId: string | undefined; // send ucinewgame when changed
  stopRequested: boolean;

  path: string;
  search: SearchBy;
  multiPv: number;
  ply: number;
  threatMode: boolean;
  initialFen: string;
  currentFen: string;
  moves: string[];
  emit: (ev: Tree.LocalEval) => void;
}

export type MoveReviewWorkInput = Omit<
  Work,
  'variant' | 'threads' | 'hashSize' | 'gameId' | 'stopRequested' | 'search' | 'threatMode' | 'emit'
> & {
  variant: MoveReviewVariant;
  searchLimits: { depth: number; nodes: number; movetimeMs: number };
  rootMoves: Uci[];
  observe?: (nodes: number, engineTimeMs: number) => void;
  emit: (evaluation: Tree.LocalEval) => void;
};

type MoveReviewWork = Work & {
  readonly profile: MoveReviewEngineProfile;
  readonly searchLimits: MoveReviewWorkInput['searchLimits'];
  readonly rootMoves: Uci[];
  readonly observe?: MoveReviewWorkInput['observe'];
};

export function makeMoveReviewWork(
  profile: MoveReviewEngineProfile,
  input: MoveReviewWorkInput,
): MoveReviewWork {
  const spec = moveReviewEngineProfileSpec();
  return {
    ...input,
    threads: spec.threads,
    hashSize: spec.hashSize,
    search: { depth: input.searchLimits.depth },
    threatMode: false,
    gameId: undefined,
    stopRequested: false,
    profile,
  };
}

export function isMoveReviewWork(work: Work | undefined): work is MoveReviewWork {
  return !!work && 'profile' in work && isMoveReviewEngineProfile(work.profile);
}

export interface BaseEngineInfo {
  id: string;
  name: string;
  short?: string;
  variants?: VariantKey[];
  minThreads?: number;
  maxThreads?: number;
  maxHash?: number;
  requires?: Feature[];
}

export interface BrowserEngineInfo extends BaseEngineInfo {
  tech: 'HCE' | 'NNUE';
  short: string;
  minMem?: number;
  assets: { root?: string; js?: string; wasm?: string; version?: string; nnue?: string[] };
  requires: Feature[];
  obsoletedBy?: Feature;
}

export type EngineInfo = BrowserEngineInfo;

