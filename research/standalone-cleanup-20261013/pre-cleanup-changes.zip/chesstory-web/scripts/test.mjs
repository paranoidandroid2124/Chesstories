import { build } from 'esbuild';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { rm } from 'node:fs/promises';

process.chdir(fileURLToPath(new URL('../', import.meta.url)));
const outfiles = ['core', 'referencePurpose', 'preview'].map(name => `test-dist/${name}.test.mjs`);
try {
  await build({ entryPoints: ['tests/core.test.ts', 'tests/referencePurpose.test.ts', 'tests/preview.test.ts'],
    outdir: 'test-dist', outExtension: { '.js': '.mjs' }, bundle: true, platform: 'node', format: 'esm', target: 'node22' });
  process.exitCode = spawnSync(process.execPath, ['--test', ...outfiles], { stdio: 'inherit' }).status ?? 1;
} finally { await Promise.all(outfiles.map(file => rm(file, { force: true }))); }
