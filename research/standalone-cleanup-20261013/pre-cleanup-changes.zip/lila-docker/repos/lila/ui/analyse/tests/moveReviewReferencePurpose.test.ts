// The standalone app owns this shared contract test.
import '../../../../../../chesstory-web/tests/referencePurpose.test';
