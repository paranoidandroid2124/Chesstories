import type { Outcome } from 'chessops/types';
import type { Prop } from '../index';
import type { Feature } from '../device';
import type CevalCtrl from './ctrl';
import type { VNode } from 'snabbdom';
import {
  isMoveReviewEngineProfile,
  moveReviewEngineProfile,
  moveReviewEngineProfileSpec,
  type MoveReviewEngineProfile,
  type MoveReviewVariant,
} from './engines/moveReviewEngineProfiles';

export { isMoveReviewEngineProfile, moveReviewEngineProfile };
export type { MoveReviewEngineProfile, MoveReviewVariant };

import type { WinningChances, SearchBy, Search, Millis, Work, MoveReviewWorkInput, BaseEngineInfo, BrowserEngineInfo, EngineInfo } from '../../../../../../../chesstory-web/src/engine/types';
export type { WinningChances, SearchBy, Search, Millis, Work, MoveReviewWorkInput, BaseEngineInfo, BrowserEngineInfo, EngineInfo } from '../../../../../../../chesstory-web/src/engine/types';
export { makeMoveReviewWork, isMoveReviewWork } from '../../../../../../../chesstory-web/src/engine/types';

export type EngineNotifier = (status?: {
  download?: { bytes: number; total: number };
  error?: string;
}) => void;

export enum CevalState {
  Initial,
  Loading,
  Idle,
  Computing,
  Failed,
}

export interface CevalEngine {
  getInfo(): EngineInfo;
  getState(): CevalState;
  start(work: Work): void;
  stop(): void;
  destroy(): void;
}

export interface MoveReviewEngine extends CevalEngine {
  readonly ready: Promise<boolean>;
}

export interface EvalMeta {
  path: string;
  threatMode: boolean;
}

export type Redraw = () => void;
export type Progress = (p?: { bytes: number; total: number }) => void;

export interface CustomCeval {
  search?: () => Search | Millis; // pass number as millis to cap user defined search
  pearlNode?: () => VNode | undefined;
  statusNode?: () => VNode | string | undefined;
}

export interface CevalOpts {
  variant: Variant;
  initialFen: string | undefined;
  emit: (ev: Tree.LocalEval, meta: EvalMeta) => void;
  onUciHover: (hovering: Hovering | null) => void;
  redraw: Redraw;
  onSelectEngine?: () => void;
  custom?: CustomCeval; // hides switch, threat, and go deeper buttons
}

export interface Hovering {
  fen: string;
  uci: string;
}

export interface PvBoard {
  fen: string;
  uci: string;
}

export interface Started {
  path: string;
  steps: Step[];
  gameId: string | undefined;
  threatMode: boolean;
}

export interface CevalHandler {
  ceval: CevalCtrl;
  nextNodeBest(): string | undefined;
  toggleThreatMode(v?: boolean): void;
  outcome(): Outcome | undefined;
  showEvalGauge: Prop<boolean>;
  ongoing: boolean;
  playUciList(uciList: string[]): void;
  getOrientation(): Color;
  threatMode(): boolean;
  getNode(): Tree.Node;
  clearCeval: () => void;
  startCeval: () => void;
  cevalEnabled: (enable?: boolean) => boolean | 'force';
}

export interface NodeEvals {
  client?: Tree.ClientEval;
  server?: Tree.ServerEval;
}

export interface Step {
  ply: number;
  fen: string;
  san?: string;
  uci?: string;
  threat?: Tree.ClientEval;
  ceval?: Tree.ClientEval;
}
