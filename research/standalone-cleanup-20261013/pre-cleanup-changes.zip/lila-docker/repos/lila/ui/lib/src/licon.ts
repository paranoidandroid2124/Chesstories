// Shared implementation now belongs to the standalone Chesstories app.
export * from '../../../../../../chesstory-web/src/licon';
