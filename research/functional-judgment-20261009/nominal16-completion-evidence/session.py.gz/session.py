"""Execute sealed adaptive research plans in one sequential engine session.

This is independent research. It never constructs or submits a product report.
Each later plan is accepted only after it has been saved and explicitly named
on stdin. The engine stays alive while the next plan is prepared.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

import chess

ROOT = Path(__file__).resolve().parents[3]
HOME = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    if path.exists() and path.name.startswith('sealed-'):
        raise AssertionError(f'Immutable file already exists: {path}')
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf8')


def check_files(values):
    changed = [path for path, expected in values.items() if not Path(path).is_file() or sha(path) != expected]
    assert not changed, f'Declared frozen input changed: {changed}'


def load_stage(path, expected_sha, study):
    path = Path(path).resolve()
    assert path.is_relative_to(HOME)
    assert sha(path) == expected_sha
    plan = json.loads(path.read_text(encoding='utf8'))
    assert plan['study_id'] == study['study_id'] and plan['epoch_id'] == study['epoch_id']
    assert plan['engine_profile'] == study['engine_profile']
    assert plan['depth'] in study['allowed_depths'] and plan['product_reports_submitted'] == 0
    assert 1 <= len(plan['queries']) <= 3
    return path, plan


def validate_query(query, study):
    work = query['work']
    assert work['engineProfile'] == study['engine_profile']
    assert work['searchLimits']['depth'] in study['allowed_depths']
    assert 1 <= work['searchLimits']['depth'] <= 18
    assert work['searchLimits']['movetimeMs'] <= study['per_query_limits']['movetime_ms']
    assert work['maxSearchElapsedMs'] == work['searchLimits']['movetimeMs'] + 2000
    expected_key = dict(work)
    observed_key = expected_key.pop('executionKeySha256')
    assert hashlib.sha256(json.dumps(expected_key, sort_keys=True).encode()).hexdigest() == observed_key
    board = chess.Board(work['enginePositionInitialFen'])
    for move in work['enginePositionMovesUci']:
        board.push_uci(move)
    assert board.fen() == work['searchFen']
    all_legal = sorted(move.uci() for move in board.legal_moves)
    assert all_legal == query['all_legal_root_uci']
    restricted = work['rootRestriction']['kind'] == 'restricted'
    eligible = work['rootRestriction']['movesUci'] if restricted else all_legal
    assert eligible and len(eligible) == len(set(eligible))
    assert set(eligible) <= set(all_legal)
    assert work['searchLimits']['multiPv'] == min(3, len(eligible)) if not restricted else work['searchLimits']['multiPv'] == len(eligible)
    assert query['request'] == study['original_request']
    assert work['enginePositionMovesUci'][:len(study['exact_history_prefix'])] == study['exact_history_prefix']
    return board, eligible


def summary_for(query, result, board, elapsed):
    execution = result.get('execution', {})
    outcome = execution.get('outcome', {})
    lines, legal = [], True
    for line in outcome.get('lineSuffixes', []):
        position, sans = board.copy(), []
        try:
            for uci in line['moves']:
                move = chess.Move.from_uci(uci)
                assert move in position.legal_moves
                sans.append(position.san(move))
                position.push(move)
        except Exception:
            legal = False
        lines.append({'root_uci': line['moves'][0] if line.get('moves') else None,
                      'root_san': sans[0] if sans else None,
                      'white_score': line.get('whiteScore'), 'depth': line.get('depth'), 'uci': line.get('moves', []), 'san': sans})
    completed = outcome.get('kind') == 'completed' and outcome.get('completedDepth') == query['work']['searchLimits']['depth']
    if completed:
        roots = [line['root_uci'] for line in lines]
        assert legal and len(roots) == len(set(roots)) == query['work']['searchLimits']['multiPv']
        assert all(line['depth'] == query['work']['searchLimits']['depth'] for line in lines)
        assert set(roots) <= set(query['all_legal_root_uci'])
        if query['work']['rootRestriction']['kind'] == 'restricted':
            assert set(roots) == set(query['work']['rootRestriction']['movesUci'])
    evaluations = execution.get('evaluations', [])
    return {'id': query['id'], 'work_id': query['work']['workId'],
            'execution_key': query['work']['executionKeySha256'],
            'kind': outcome.get('kind', 'executor_error'), 'completed_depth': outcome.get('completedDepth'),
            'elapsed_ms': execution.get('elapsed_ms'), 'wall_ms': elapsed,
            'nodes': outcome.get('nodes', outcome.get('observedNodes')),
            'last_complete_depth': max((row['depth'] for row in evaluations), default=None),
            'failure_code': outcome.get('failureCode'), 'pv_legal': legal,
            'scope': query['scope'], 'values': lines}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('study')
    parser.add_argument('stage')
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    study_path = Path(args.study).resolve()
    study = json.loads(study_path.read_text(encoding='utf8'))
    check_files(study['frozen_runtime_sha256'])
    assert study['runner_sha256'] == sha(__file__)
    assert study['sequential'] and study['one_persistent_engine_process']
    out = Path(args.out).resolve()
    assert out.is_relative_to(HOME)
    out.mkdir(parents=True, exist_ok=False)
    spec = importlib.util.spec_from_file_location('independent_comparison_rpc', study['rpc_source'])
    rpc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rpc)
    log = (out / 'process.log').open('w', encoding='utf8')
    node = rpc.RPC([study['node_binary'], study['bundle'], study['engine_asset']], log)
    results, summaries, stages, ids, keys = [], [], [], set(), set()
    began_session = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    shutdown = None
    try:
        boot = node.receive(30)
        assert boot.get('ready')
        save(out / 'boot.json', boot)
        next_stage = {'path': args.stage, 'sha256': sha(args.stage)}
        while next_stage:
            path, plan = load_stage(next_stage['path'], next_stage['sha256'], study)
            stages.append({'path': str(path), 'sha256': sha(path), 'phase': plan['phase'],
                           'query_ids': [query['id'] for query in plan['queries']]})
            save(out / f"sealed-stage-{len(stages):02d}.json", plan)
            for query in plan['queries']:
                assert query['id'] not in ids and query['work']['executionKeySha256'] not in keys
                assert len(ids) < 3, 'Finite study allows three queries and no retry'
                ids.add(query['id']); keys.add(query['work']['executionKeySha256'])
                check_files(study['frozen_runtime_sha256'])
                assert query['work']['searchLimits']['depth'] == plan['depth']
                board, _ = validate_query(query, study)
                remaining_ms = study['research_policy_ms'] - round((time.monotonic() - began_session) * 1000)
                if remaining_ms <= 2000:
                    raise TimeoutError('Explicit 30-minute study deadline reached before required query')
                began = time.monotonic()
                work = query['work']
                print(json.dumps({'starting_query': query['id'], 'prefix': query['relative_prefix_uci'],
                                  'time_limit_ms': work['searchLimits']['movetimeMs']}, ensure_ascii=False), flush=True)
                result = node.call({'request': query['request'], 'research_work': work,
                                    'snapshot': {'deadline_epoch_ms': int(time.time() * 1000) + min(work['maxSearchElapsedMs'] + 5000, remaining_ms)}},
                                   work['maxSearchElapsedMs'] / 1000 + 20)
                elapsed = round((time.monotonic() - began) * 1000)
                record = {'id': query['id'], 'query': query, 'stage_sha256': sha(path), 'result': result}
                results.append(record)
                save(out / 'results.json', results)
                summary = summary_for(query, result, board, elapsed)
                summaries.append(summary)
                save(out / 'summary.json', summaries)
                check_files(study['frozen_runtime_sha256'])
                print(json.dumps(summary, ensure_ascii=False), flush=True)
            save(out / 'progress.json', {'status': 'awaiting_sealed_next_stage', 'stages': stages,
                                        'queries_executed': len(results), 'new_engine_queries': len(results),
                                        'product_reports_submitted': 0})
            next_stage = None
    finally:
        shutdown = node.close()
        log.close()
        changed = [path for path, expected in study['frozen_runtime_sha256'].items()
                   if not Path(path).is_file() or sha(path) != expected]
        save(out / 'manifest.json', {'study_id': study['study_id'], 'epoch_id': study['epoch_id'],
                                    'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
                                    'session_wall_ms': round((time.monotonic() - began_session) * 1000),
                                    'engine_processes': 1, 'new_engine_queries': len(results),
                                    'product_reports_submitted': 0, 'stages': stages,
                                    'study_sha256': sha(study_path), 'runner_sha256': sha(__file__),
                                    'frozen_runtime_hashes_passed_before_and_after': not changed,
                                    'changed_frozen_inputs': changed, 'shutdown': shutdown})
        assert not changed


if __name__ == '__main__':
    main()
