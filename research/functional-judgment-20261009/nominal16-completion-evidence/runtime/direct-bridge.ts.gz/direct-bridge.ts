import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { performance } from 'node:perf_hooks';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
const { JSDOM } = createRequire(resolve('target/relationship-delivery-20261004/frontend-probe/package.json'))('jsdom');
import { parseFen } from 'chessops/fen';
import { makeSan } from 'chessops/san';
import { parseUci } from 'chessops/util';
import { setupPosition } from 'chessops/variant';
const dom = new JSDOM('<!doctype html><html><body></body></html>', { url: 'http://localhost/', pretendToBeVisual: true });
Object.assign(globalThis, { window: dom.window, document: dom.window.document, HTMLElement: dom.window.HTMLElement,
  Event: dom.window.Event, requestAnimationFrame: dom.window.requestAnimationFrame.bind(dom.window),
  cancelAnimationFrame: dom.window.cancelAnimationFrame.bind(dom.window) });
const { Protocol } = await import('C:/Users/양자/.codex/worktrees/functional-choice-value/Chesstories/lila-docker/repos/lila/ui/lib/src/ceval/protocol');
const { makeMoveReviewWork } = await import('C:/Users/양자/.codex/worktrees/functional-choice-value/Chesstories/lila-docker/repos/lila/ui/lib/src/ceval/types');
const { decodeMoveReviewSnapshot, moveReviewEngineOutcomeAtRequiredDepth, buildMoveReviewEngineWorkReport } =
  await import('C:/Users/양자/.codex/worktrees/functional-choice-value/Chesstories/lila-docker/repos/lila/ui/analyse/src/moveReview');
const started = performance.now(), protocol = new Protocol(), boot: any[] = [];
const engine = spawn(process.execPath, [process.argv[2]], { stdio: ['pipe', 'pipe', 'inherit'] });
let transcript = boot, onExit: ((reason: string) => void) | undefined;
engine.on('error', error => onExit?.(String(error)));
engine.on('exit', code => onExit?.(`engine exited ${code}`));
createInterface({ input: engine.stdout }).on('line', line => { transcript.push({ received: line }); protocol.received(line); });
protocol.connected(cmd => { transcript.push({ sent: cmd }); engine.stdin.write(cmd + '\n'); });
const readyTimer = setTimeout(() => { engine.kill(); console.error('engine initialization timed out'); process.exit(1); }, 15000);
await protocol.ready;
clearTimeout(readyTimer);
console.log(JSON.stringify({ ready: true, engine_name: protocol.engineName, engine_startup_ms: Math.floor(performance.now() - started), boot }));
async function execute(input: any) {
  const began = performance.now(), request = input.request, wire = input.snapshot;
  const pos = setupPosition('chess', parseFen(request.current_fen).unwrap()).unwrap();
  const subject = { variant: request.variant, initialFen: request.initial_fen, movePrefixUci: request.move_prefix_uci,
    before: { path: '', fen: request.current_fen }, after: { path: 'probe', fen: request.focus.resulting_fen },
    played: { uci: request.focus.played_move_uci, san: makeSan(pos, parseUci(request.focus.played_move_uci)!) } };
  const work = input.research_work;
  if (!work) throw Error("Explicit independent research work required");
  if (!Number.isInteger(work.searchLimits.depth) || work.searchLimits.depth < 1 || work.searchLimits.depth > 18) throw Error("Independent study depth must remain within18");
  transcript = [];
  let previous: any, latestNodes = 0, latestMillis = 0, timedOut = false;
  const evaluations: any[] = [];
  return await new Promise(resolve => {
    let done = false;
    const finish = (outcome: any, researchError?: string) => {
      if (done) return;
      done = true; clearTimeout(limit); clearTimeout(hardLimit); onExit = undefined;
      resolve({ independent_research: true, execution: {
        elapsed_ms: Math.floor(performance.now() - began), outcome, evaluations, transcript,
        ...(researchError ? { research_executor_error: researchError } : {}) } });
    };
    const failure = (failureCode: string) => ({ kind: 'executor_failed', failureCode,
      executorElapsedMs: Math.floor(performance.now() - began), observedNodes: latestNodes,
      engineTimeMs: latestMillis, diagnostic: JSON.stringify({ lastDepth: evaluations.at(-1)?.depth,
        pvDepths: evaluations.at(-1)?.pvs.map((pv: any) => pv.depth),
        bounds: evaluations.at(-1)?.pvs.map((pv: any) => pv.bound),
        nodesOver: latestNodes > work.searchLimits.nodes, timeOver: latestMillis > work.searchLimits.movetimeMs,
        leaseExpired: timedOut }) });
    const lease = Math.max(0, Math.min(work.maxSearchElapsedMs, wire.deadline_epoch_ms - Date.now()));
    const limit = setTimeout(() => { timedOut = true; protocol.compute(undefined); }, lease);
    const hardLimit = setTimeout(() => { engine.kill(); finish(failure('engine_failure'), 'Engine did not release bestmove after stop'); }, lease + 2000);
    onExit = reason => finish(failure('engine_failure'), reason);
    protocol.compute(makeMoveReviewWork(work.engineProfile, { variant: work.variant,
      initialFen: work.enginePositionInitialFen, currentFen: work.searchFen, moves: work.enginePositionMovesUci,
      path: `move-review:${work.workId}`, multiPv: work.searchLimits.multiPv, searchLimits: work.searchLimits,
      ply: (Number(work.searchFen.split(' ')[5]) - 1) * 2 + (work.searchFen.split(' ')[1] === 'b' ? 1 : 0),
      rootMoves: work.rootRestriction.kind === 'restricted' ? work.rootRestriction.movesUci : [],
      observe: (nodes, millis) => { latestNodes = Math.max(latestNodes, nodes); latestMillis = Math.max(latestMillis, millis); },
      emit: evaluation => {
        latestNodes = Math.max(latestNodes, evaluation.nodes); latestMillis = Math.max(latestMillis, evaluation.millis);
        evaluations.push(structuredClone(evaluation));
        if (evaluation.depth === work.searchLimits.depth - 1 && evaluation.bestmove === undefined) previous = structuredClone(evaluation);
        if (timedOut) { if (evaluation.bestmove !== undefined) finish(failure('lease_expired')); return; }
        const outcome = moveReviewEngineOutcomeAtRequiredDepth(work,
          { ...evaluation, nodes: latestNodes, millis: latestMillis }, previous, Math.floor(performance.now() - began));
        if (outcome) finish(outcome);
        else if (evaluation.bestmove !== undefined) finish(failure('search_budget_exhausted'));
      } }));
  });
}
for await (const line of createInterface({ input: process.stdin })) {
  try { console.log(JSON.stringify(await execute(JSON.parse(line)))); }
  catch (error) { console.log(JSON.stringify({ executor_error: String(error) })); }
}
engine.stdin.end('quit\n'); dom.window.close();
