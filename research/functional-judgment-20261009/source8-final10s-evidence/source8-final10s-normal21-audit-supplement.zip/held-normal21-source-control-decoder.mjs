var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// target/relationship-delivery-20261004/frontend-probe/node_modules/@badrap/result/dist/node-mjs/index.mjs
var _Result, _Ok, _Err, Result;
var init_node_mjs = __esm({
  "target/relationship-delivery-20261004/frontend-probe/node_modules/@badrap/result/dist/node-mjs/index.mjs"() {
    _Result = class {
      unwrap(ok, err) {
        const r = this._chain((value) => Result.ok(ok ? ok(value) : value), (error) => err ? Result.ok(err(error)) : Result.err(error));
        if (r.isErr) {
          throw r.error;
        }
        return r.value;
      }
      map(ok, err) {
        return this._chain((value) => Result.ok(ok(value)), (error) => Result.err(err ? err(error) : error));
      }
      chain(ok, err) {
        return this._chain(ok, err ?? ((error) => Result.err(error)));
      }
    };
    _Ok = class extends _Result {
      value;
      isOk = true;
      isErr = false;
      constructor(value) {
        super();
        this.value = value;
      }
      _chain(ok, _err) {
        return ok(this.value);
      }
    };
    _Err = class extends _Result {
      error;
      isOk = false;
      isErr = true;
      constructor(error) {
        super();
        this.error = error;
      }
      _chain(_ok, err) {
        return err(this.error);
      }
    };
    (function(Result2) {
      function ok(value) {
        return new _Ok(value);
      }
      Result2.ok = ok;
      function err(error) {
        return new _Err(error || new Error());
      }
      Result2.err = err;
      function all(obj) {
        if (Array.isArray(obj)) {
          const res2 = [];
          for (let i = 0; i < obj.length; i++) {
            const item = obj[i];
            if (item.isErr) {
              return item;
            }
            res2.push(item.value);
          }
          return Result2.ok(res2);
        }
        const res = {};
        const keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
          const item = obj[keys[i]];
          if (item.isErr) {
            return item;
          }
          res[keys[i]] = item.value;
        }
        return Result2.ok(res);
      }
      Result2.all = all;
    })(Result || (Result = {}));
  }
});

// target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/squareSet.js
var popcnt32, bswap32, rbit32, SquareSet;
var init_squareSet = __esm({
  "target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/squareSet.js"() {
    popcnt32 = (n) => {
      n = n - (n >>> 1 & 1431655765);
      n = (n & 858993459) + (n >>> 2 & 858993459);
      return Math.imul(n + (n >>> 4) & 252645135, 16843009) >> 24;
    };
    bswap32 = (n) => {
      n = n >>> 8 & 16711935 | (n & 16711935) << 8;
      return n >>> 16 & 65535 | (n & 65535) << 16;
    };
    rbit32 = (n) => {
      n = n >>> 1 & 1431655765 | (n & 1431655765) << 1;
      n = n >>> 2 & 858993459 | (n & 858993459) << 2;
      n = n >>> 4 & 252645135 | (n & 252645135) << 4;
      return bswap32(n);
    };
    SquareSet = class _SquareSet {
      constructor(lo, hi) {
        this.lo = lo | 0;
        this.hi = hi | 0;
      }
      static fromSquare(square) {
        return square >= 32 ? new _SquareSet(0, 1 << square - 32) : new _SquareSet(1 << square, 0);
      }
      static fromRank(rank) {
        return new _SquareSet(255, 0).shl64(8 * rank);
      }
      static fromFile(file) {
        return new _SquareSet(16843009 << file, 16843009 << file);
      }
      static empty() {
        return new _SquareSet(0, 0);
      }
      static full() {
        return new _SquareSet(4294967295, 4294967295);
      }
      static corners() {
        return new _SquareSet(129, 2164260864);
      }
      static center() {
        return new _SquareSet(402653184, 24);
      }
      static backranks() {
        return new _SquareSet(255, 4278190080);
      }
      static backrank(color) {
        return color === "white" ? new _SquareSet(255, 0) : new _SquareSet(0, 4278190080);
      }
      static lightSquares() {
        return new _SquareSet(1437226410, 1437226410);
      }
      static darkSquares() {
        return new _SquareSet(2857740885, 2857740885);
      }
      complement() {
        return new _SquareSet(~this.lo, ~this.hi);
      }
      xor(other) {
        return new _SquareSet(this.lo ^ other.lo, this.hi ^ other.hi);
      }
      union(other) {
        return new _SquareSet(this.lo | other.lo, this.hi | other.hi);
      }
      intersect(other) {
        return new _SquareSet(this.lo & other.lo, this.hi & other.hi);
      }
      diff(other) {
        return new _SquareSet(this.lo & ~other.lo, this.hi & ~other.hi);
      }
      intersects(other) {
        return this.intersect(other).nonEmpty();
      }
      isDisjoint(other) {
        return this.intersect(other).isEmpty();
      }
      supersetOf(other) {
        return other.diff(this).isEmpty();
      }
      subsetOf(other) {
        return this.diff(other).isEmpty();
      }
      shr64(shift) {
        if (shift >= 64)
          return _SquareSet.empty();
        if (shift >= 32)
          return new _SquareSet(this.hi >>> shift - 32, 0);
        if (shift > 0)
          return new _SquareSet(this.lo >>> shift ^ this.hi << 32 - shift, this.hi >>> shift);
        return this;
      }
      shl64(shift) {
        if (shift >= 64)
          return _SquareSet.empty();
        if (shift >= 32)
          return new _SquareSet(0, this.lo << shift - 32);
        if (shift > 0)
          return new _SquareSet(this.lo << shift, this.hi << shift ^ this.lo >>> 32 - shift);
        return this;
      }
      bswap64() {
        return new _SquareSet(bswap32(this.hi), bswap32(this.lo));
      }
      rbit64() {
        return new _SquareSet(rbit32(this.hi), rbit32(this.lo));
      }
      minus64(other) {
        const lo = this.lo - other.lo;
        const c = (lo & other.lo & 1) + (other.lo >>> 1) + (lo >>> 1) >>> 31;
        return new _SquareSet(lo, this.hi - (other.hi + c));
      }
      equals(other) {
        return this.lo === other.lo && this.hi === other.hi;
      }
      size() {
        return popcnt32(this.lo) + popcnt32(this.hi);
      }
      isEmpty() {
        return this.lo === 0 && this.hi === 0;
      }
      nonEmpty() {
        return this.lo !== 0 || this.hi !== 0;
      }
      has(square) {
        return (square >= 32 ? this.hi & 1 << square - 32 : this.lo & 1 << square) !== 0;
      }
      set(square, on) {
        return on ? this.with(square) : this.without(square);
      }
      with(square) {
        return square >= 32 ? new _SquareSet(this.lo, this.hi | 1 << square - 32) : new _SquareSet(this.lo | 1 << square, this.hi);
      }
      without(square) {
        return square >= 32 ? new _SquareSet(this.lo, this.hi & ~(1 << square - 32)) : new _SquareSet(this.lo & ~(1 << square), this.hi);
      }
      toggle(square) {
        return square >= 32 ? new _SquareSet(this.lo, this.hi ^ 1 << square - 32) : new _SquareSet(this.lo ^ 1 << square, this.hi);
      }
      last() {
        if (this.hi !== 0)
          return 63 - Math.clz32(this.hi);
        if (this.lo !== 0)
          return 31 - Math.clz32(this.lo);
        return;
      }
      first() {
        if (this.lo !== 0)
          return 31 - Math.clz32(this.lo & -this.lo);
        if (this.hi !== 0)
          return 63 - Math.clz32(this.hi & -this.hi);
        return;
      }
      withoutFirst() {
        if (this.lo !== 0)
          return new _SquareSet(this.lo & this.lo - 1, this.hi);
        return new _SquareSet(0, this.hi & this.hi - 1);
      }
      moreThanOne() {
        return this.hi !== 0 && this.lo !== 0 || (this.lo & this.lo - 1) !== 0 || (this.hi & this.hi - 1) !== 0;
      }
      singleSquare() {
        return this.moreThanOne() ? void 0 : this.last();
      }
      *[Symbol.iterator]() {
        let lo = this.lo;
        let hi = this.hi;
        while (lo !== 0) {
          const idx = 31 - Math.clz32(lo & -lo);
          lo ^= 1 << idx;
          yield idx;
        }
        while (hi !== 0) {
          const idx = 31 - Math.clz32(hi & -hi);
          hi ^= 1 << idx;
          yield 32 + idx;
        }
      }
      *reversed() {
        let lo = this.lo;
        let hi = this.hi;
        while (hi !== 0) {
          const idx = 31 - Math.clz32(hi);
          hi ^= 1 << idx;
          yield 32 + idx;
        }
        while (lo !== 0) {
          const idx = 31 - Math.clz32(lo);
          lo ^= 1 << idx;
          yield idx;
        }
      }
    };
  }
});

// target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/types.js
var FILE_NAMES, RANK_NAMES, COLORS, ROLES, CASTLING_SIDES, isDrop;
var init_types = __esm({
  "target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/types.js"() {
    FILE_NAMES = ["a", "b", "c", "d", "e", "f", "g", "h"];
    RANK_NAMES = ["1", "2", "3", "4", "5", "6", "7", "8"];
    COLORS = ["white", "black"];
    ROLES = ["pawn", "knight", "bishop", "rook", "queen", "king"];
    CASTLING_SIDES = ["a", "h"];
    isDrop = (v) => "role" in v;
  }
});

// target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/board.js
var Board;
var init_board = __esm({
  "target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/board.js"() {
    init_squareSet();
    init_types();
    Board = class _Board {
      constructor() {
      }
      static default() {
        const board = new _Board();
        board.reset();
        return board;
      }
      /**
       * Resets all pieces to the default starting position for standard chess.
       */
      reset() {
        this.occupied = new SquareSet(65535, 4294901760);
        this.promoted = SquareSet.empty();
        this.white = new SquareSet(65535, 0);
        this.black = new SquareSet(0, 4294901760);
        this.pawn = new SquareSet(65280, 16711680);
        this.knight = new SquareSet(66, 1107296256);
        this.bishop = new SquareSet(36, 603979776);
        this.rook = new SquareSet(129, 2164260864);
        this.queen = new SquareSet(8, 134217728);
        this.king = new SquareSet(16, 268435456);
      }
      static empty() {
        const board = new _Board();
        board.clear();
        return board;
      }
      clear() {
        this.occupied = SquareSet.empty();
        this.promoted = SquareSet.empty();
        for (const color of COLORS)
          this[color] = SquareSet.empty();
        for (const role of ROLES)
          this[role] = SquareSet.empty();
      }
      clone() {
        const board = new _Board();
        board.occupied = this.occupied;
        board.promoted = this.promoted;
        for (const color of COLORS)
          board[color] = this[color];
        for (const role of ROLES)
          board[role] = this[role];
        return board;
      }
      getColor(square) {
        if (this.white.has(square))
          return "white";
        if (this.black.has(square))
          return "black";
        return;
      }
      getRole(square) {
        for (const role of ROLES) {
          if (this[role].has(square))
            return role;
        }
        return;
      }
      get(square) {
        const color = this.getColor(square);
        if (!color)
          return;
        const role = this.getRole(square);
        const promoted = this.promoted.has(square);
        return { color, role, promoted };
      }
      /**
       * Removes and returns the piece from the given `square`, if any.
       */
      take(square) {
        const piece = this.get(square);
        if (piece) {
          this.occupied = this.occupied.without(square);
          this[piece.color] = this[piece.color].without(square);
          this[piece.role] = this[piece.role].without(square);
          if (piece.promoted)
            this.promoted = this.promoted.without(square);
        }
        return piece;
      }
      /**
       * Put `piece` onto `square`, potentially replacing an existing piece.
       * Returns the existing piece, if any.
       */
      set(square, piece) {
        const old = this.take(square);
        this.occupied = this.occupied.with(square);
        this[piece.color] = this[piece.color].with(square);
        this[piece.role] = this[piece.role].with(square);
        if (piece.promoted)
          this.promoted = this.promoted.with(square);
        return old;
      }
      has(square) {
        return this.occupied.has(square);
      }
      *[Symbol.iterator]() {
        for (const square of this.occupied) {
          yield [square, this.get(square)];
        }
      }
      pieces(color, role) {
        return this[color].intersect(this[role]);
      }
      rooksAndQueens() {
        return this.rook.union(this.queen);
      }
      bishopsAndQueens() {
        return this.bishop.union(this.queen);
      }
      steppers() {
        return this.knight.union(this.pawn).union(this.king);
      }
      sliders() {
        return this.bishop.union(this.rook).union(this.queen);
      }
      /**
       * Finds the unique king of the given `color`, if any.
       */
      kingOf(color) {
        return this.pieces(color, "king").singleSquare();
      }
    };
  }
});

// target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/setup.js
var MaterialSide, Material, RemainingChecks;
var init_setup = __esm({
  "target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/setup.js"() {
    init_types();
    MaterialSide = class _MaterialSide {
      constructor() {
      }
      static empty() {
        const m = new _MaterialSide();
        for (const role of ROLES)
          m[role] = 0;
        return m;
      }
      static fromBoard(board, color) {
        const m = new _MaterialSide();
        for (const role of ROLES)
          m[role] = board.pieces(color, role).size();
        return m;
      }
      clone() {
        const m = new _MaterialSide();
        for (const role of ROLES)
          m[role] = this[role];
        return m;
      }
      equals(other) {
        return ROLES.every((role) => this[role] === other[role]);
      }
      add(other) {
        const m = new _MaterialSide();
        for (const role of ROLES)
          m[role] = this[role] + other[role];
        return m;
      }
      subtract(other) {
        const m = new _MaterialSide();
        for (const role of ROLES)
          m[role] = this[role] - other[role];
        return m;
      }
      nonEmpty() {
        return ROLES.some((role) => this[role] > 0);
      }
      isEmpty() {
        return !this.nonEmpty();
      }
      hasPawns() {
        return this.pawn > 0;
      }
      hasNonPawns() {
        return this.knight > 0 || this.bishop > 0 || this.rook > 0 || this.queen > 0 || this.king > 0;
      }
      size() {
        return this.pawn + this.knight + this.bishop + this.rook + this.queen + this.king;
      }
    };
    Material = class _Material {
      constructor(white, black) {
        this.white = white;
        this.black = black;
      }
      static empty() {
        return new _Material(MaterialSide.empty(), MaterialSide.empty());
      }
      static fromBoard(board) {
        return new _Material(MaterialSide.fromBoard(board, "white"), MaterialSide.fromBoard(board, "black"));
      }
      clone() {
        return new _Material(this.white.clone(), this.black.clone());
      }
      equals(other) {
        return this.white.equals(other.white) && this.black.equals(other.black);
      }
      add(other) {
        return new _Material(this.white.add(other.white), this.black.add(other.black));
      }
      subtract(other) {
        return new _Material(this.white.subtract(other.white), this.black.subtract(other.black));
      }
      count(role) {
        return this.white[role] + this.black[role];
      }
      size() {
        return this.white.size() + this.black.size();
      }
      isEmpty() {
        return this.white.isEmpty() && this.black.isEmpty();
      }
      nonEmpty() {
        return !this.isEmpty();
      }
      hasPawns() {
        return this.white.hasPawns() || this.black.hasPawns();
      }
      hasNonPawns() {
        return this.white.hasNonPawns() || this.black.hasNonPawns();
      }
    };
    RemainingChecks = class _RemainingChecks {
      constructor(white, black) {
        this.white = white;
        this.black = black;
      }
      static default() {
        return new _RemainingChecks(3, 3);
      }
      clone() {
        return new _RemainingChecks(this.white, this.black);
      }
      equals(other) {
        return this.white === other.white && this.black === other.black;
      }
    };
  }
});

// target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/util.js
function charToRole(ch) {
  switch (ch.toLowerCase()) {
    case "p":
      return "pawn";
    case "n":
      return "knight";
    case "b":
      return "bishop";
    case "r":
      return "rook";
    case "q":
      return "queen";
    case "k":
      return "king";
    default:
      return;
  }
}
function parseSquare(str) {
  if (str.length !== 2)
    return;
  return squareFromCoords(str.charCodeAt(0) - "a".charCodeAt(0), str.charCodeAt(1) - "1".charCodeAt(0));
}
var defined, opposite, squareRank, squareFile, squareFromCoords, roleToChar, makeSquare, parseUci, makeUci, kingCastlesTo, rookCastlesTo;
var init_util = __esm({
  "target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/util.js"() {
    init_types();
    defined = (v) => v !== void 0;
    opposite = (color) => color === "white" ? "black" : "white";
    squareRank = (square) => square >> 3;
    squareFile = (square) => square & 7;
    squareFromCoords = (file, rank) => 0 <= file && file < 8 && 0 <= rank && rank < 8 ? file + 8 * rank : void 0;
    roleToChar = (role) => {
      switch (role) {
        case "pawn":
          return "p";
        case "knight":
          return "n";
        case "bishop":
          return "b";
        case "rook":
          return "r";
        case "queen":
          return "q";
        case "king":
          return "k";
      }
    };
    makeSquare = (square) => FILE_NAMES[squareFile(square)] + RANK_NAMES[squareRank(square)];
    parseUci = (str) => {
      if (str[1] === "@" && str.length === 4) {
        const role = charToRole(str[0]);
        const to = parseSquare(str.slice(2));
        if (role && defined(to))
          return { role, to };
      } else if (str.length === 4 || str.length === 5) {
        const from = parseSquare(str.slice(0, 2));
        const to = parseSquare(str.slice(2, 4));
        let promotion;
        if (str.length === 5) {
          promotion = charToRole(str[4]);
          if (!promotion)
            return;
        }
        if (defined(from) && defined(to))
          return { from, to, promotion };
      }
      return;
    };
    makeUci = (move) => isDrop(move) ? `${roleToChar(move.role).toUpperCase()}@${makeSquare(move.to)}` : makeSquare(move.from) + makeSquare(move.to) + (move.promotion ? roleToChar(move.promotion) : "");
    kingCastlesTo = (color, side) => color === "white" ? side === "a" ? 2 : 6 : side === "a" ? 58 : 62;
    rookCastlesTo = (color, side) => color === "white" ? side === "a" ? 3 : 5 : side === "a" ? 59 : 61;
  }
});

// target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/fen.js
var INITIAL_BOARD_FEN, INITIAL_EPD, INITIAL_FEN, EMPTY_BOARD_FEN, EMPTY_EPD, EMPTY_FEN, InvalidFen, FenError, nthIndexOf, parseSmallUint, charToPiece, parseBoardFen, parsePockets, parseCastlingFen, parseRemainingChecks, parseFen, makePiece, makeBoardFen, makePocket, makePockets, makeCastlingFen, makeRemainingChecks, makeFen;
var init_fen = __esm({
  "target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/fen.js"() {
    init_node_mjs();
    init_board();
    init_setup();
    init_squareSet();
    init_types();
    init_util();
    INITIAL_BOARD_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";
    INITIAL_EPD = INITIAL_BOARD_FEN + " w KQkq -";
    INITIAL_FEN = INITIAL_EPD + " 0 1";
    EMPTY_BOARD_FEN = "8/8/8/8/8/8/8/8";
    EMPTY_EPD = EMPTY_BOARD_FEN + " w - -";
    EMPTY_FEN = EMPTY_EPD + " 0 1";
    (function(InvalidFen2) {
      InvalidFen2["Fen"] = "ERR_FEN";
      InvalidFen2["Board"] = "ERR_BOARD";
      InvalidFen2["Pockets"] = "ERR_POCKETS";
      InvalidFen2["Turn"] = "ERR_TURN";
      InvalidFen2["Castling"] = "ERR_CASTLING";
      InvalidFen2["EpSquare"] = "ERR_EP_SQUARE";
      InvalidFen2["RemainingChecks"] = "ERR_REMAINING_CHECKS";
      InvalidFen2["Halfmoves"] = "ERR_HALFMOVES";
      InvalidFen2["Fullmoves"] = "ERR_FULLMOVES";
    })(InvalidFen || (InvalidFen = {}));
    FenError = class extends Error {
    };
    nthIndexOf = (haystack, needle, n) => {
      let index = haystack.indexOf(needle);
      while (n-- > 0) {
        if (index === -1)
          break;
        index = haystack.indexOf(needle, index + needle.length);
      }
      return index;
    };
    parseSmallUint = (str) => /^\d{1,4}$/.test(str) ? parseInt(str, 10) : void 0;
    charToPiece = (ch) => {
      const role = charToRole(ch);
      return role && { role, color: ch.toLowerCase() === ch ? "black" : "white" };
    };
    parseBoardFen = (boardPart) => {
      const board = Board.empty();
      let rank = 7;
      let file = 0;
      for (let i = 0; i < boardPart.length; i++) {
        const c = boardPart[i];
        if (c === "/" && file === 8) {
          file = 0;
          rank--;
        } else {
          const step = parseInt(c, 10);
          if (step > 0)
            file += step;
          else {
            if (file >= 8 || rank < 0)
              return Result.err(new FenError(InvalidFen.Board));
            const square = file + rank * 8;
            const piece = charToPiece(c);
            if (!piece)
              return Result.err(new FenError(InvalidFen.Board));
            if (boardPart[i + 1] === "~") {
              piece.promoted = true;
              i++;
            }
            board.set(square, piece);
            file++;
          }
        }
      }
      if (rank !== 0 || file !== 8)
        return Result.err(new FenError(InvalidFen.Board));
      return Result.ok(board);
    };
    parsePockets = (pocketPart) => {
      if (pocketPart.length > 64)
        return Result.err(new FenError(InvalidFen.Pockets));
      const pockets = Material.empty();
      for (const c of pocketPart) {
        const piece = charToPiece(c);
        if (!piece)
          return Result.err(new FenError(InvalidFen.Pockets));
        pockets[piece.color][piece.role]++;
      }
      return Result.ok(pockets);
    };
    parseCastlingFen = (board, castlingPart) => {
      let castlingRights = SquareSet.empty();
      if (castlingPart === "-")
        return Result.ok(castlingRights);
      for (const c of castlingPart) {
        const lower = c.toLowerCase();
        const color = c === lower ? "black" : "white";
        const rank = color === "white" ? 0 : 7;
        if ("a" <= lower && lower <= "h") {
          castlingRights = castlingRights.with(squareFromCoords(lower.charCodeAt(0) - "a".charCodeAt(0), rank));
        } else if (lower === "k" || lower === "q") {
          const rooksAndKings = board[color].intersect(SquareSet.backrank(color)).intersect(board.rook.union(board.king));
          const candidate = lower === "k" ? rooksAndKings.last() : rooksAndKings.first();
          castlingRights = castlingRights.with(defined(candidate) && board.rook.has(candidate) ? candidate : squareFromCoords(lower === "k" ? 7 : 0, rank));
        } else
          return Result.err(new FenError(InvalidFen.Castling));
      }
      if (COLORS.some((color) => SquareSet.backrank(color).intersect(castlingRights).size() > 2)) {
        return Result.err(new FenError(InvalidFen.Castling));
      }
      return Result.ok(castlingRights);
    };
    parseRemainingChecks = (part) => {
      const parts = part.split("+");
      if (parts.length === 3 && parts[0] === "") {
        const white = parseSmallUint(parts[1]);
        const black = parseSmallUint(parts[2]);
        if (!defined(white) || white > 3 || !defined(black) || black > 3) {
          return Result.err(new FenError(InvalidFen.RemainingChecks));
        }
        return Result.ok(new RemainingChecks(3 - white, 3 - black));
      } else if (parts.length === 2) {
        const white = parseSmallUint(parts[0]);
        const black = parseSmallUint(parts[1]);
        if (!defined(white) || white > 3 || !defined(black) || black > 3) {
          return Result.err(new FenError(InvalidFen.RemainingChecks));
        }
        return Result.ok(new RemainingChecks(white, black));
      } else
        return Result.err(new FenError(InvalidFen.RemainingChecks));
    };
    parseFen = (fen) => {
      const parts = fen.split(/[\s_]+/);
      const boardPart = parts.shift();
      let board;
      let pockets = Result.ok(void 0);
      if (boardPart.endsWith("]")) {
        const pocketStart = boardPart.indexOf("[");
        if (pocketStart === -1)
          return Result.err(new FenError(InvalidFen.Fen));
        board = parseBoardFen(boardPart.slice(0, pocketStart));
        pockets = parsePockets(boardPart.slice(pocketStart + 1, -1));
      } else {
        const pocketStart = nthIndexOf(boardPart, "/", 7);
        if (pocketStart === -1)
          board = parseBoardFen(boardPart);
        else {
          board = parseBoardFen(boardPart.slice(0, pocketStart));
          pockets = parsePockets(boardPart.slice(pocketStart + 1));
        }
      }
      let turn;
      const turnPart = parts.shift();
      if (!defined(turnPart) || turnPart === "w")
        turn = "white";
      else if (turnPart === "b")
        turn = "black";
      else
        return Result.err(new FenError(InvalidFen.Turn));
      return board.chain((board2) => {
        const castlingPart = parts.shift();
        const castlingRights = defined(castlingPart) ? parseCastlingFen(board2, castlingPart) : Result.ok(SquareSet.empty());
        const epPart = parts.shift();
        let epSquare;
        if (defined(epPart) && epPart !== "-") {
          epSquare = parseSquare(epPart);
          if (!defined(epSquare))
            return Result.err(new FenError(InvalidFen.EpSquare));
        }
        let halfmovePart = parts.shift();
        let earlyRemainingChecks;
        if (defined(halfmovePart) && halfmovePart.includes("+")) {
          earlyRemainingChecks = parseRemainingChecks(halfmovePart);
          halfmovePart = parts.shift();
        }
        const halfmoves = defined(halfmovePart) ? parseSmallUint(halfmovePart) : 0;
        if (!defined(halfmoves))
          return Result.err(new FenError(InvalidFen.Halfmoves));
        const fullmovesPart = parts.shift();
        const fullmoves = defined(fullmovesPart) ? parseSmallUint(fullmovesPart) : 1;
        if (!defined(fullmoves))
          return Result.err(new FenError(InvalidFen.Fullmoves));
        const remainingChecksPart = parts.shift();
        let remainingChecks = Result.ok(void 0);
        if (defined(remainingChecksPart)) {
          if (defined(earlyRemainingChecks))
            return Result.err(new FenError(InvalidFen.RemainingChecks));
          remainingChecks = parseRemainingChecks(remainingChecksPart);
        } else if (defined(earlyRemainingChecks)) {
          remainingChecks = earlyRemainingChecks;
        }
        if (parts.length > 0)
          return Result.err(new FenError(InvalidFen.Fen));
        return pockets.chain((pockets2) => castlingRights.chain((castlingRights2) => remainingChecks.map((remainingChecks2) => {
          return {
            board: board2,
            pockets: pockets2,
            turn,
            castlingRights: castlingRights2,
            remainingChecks: remainingChecks2,
            epSquare,
            halfmoves,
            fullmoves: Math.max(1, fullmoves)
          };
        })));
      });
    };
    makePiece = (piece) => {
      let r = roleToChar(piece.role);
      if (piece.color === "white")
        r = r.toUpperCase();
      if (piece.promoted)
        r += "~";
      return r;
    };
    makeBoardFen = (board) => {
      let fen = "";
      let empty = 0;
      for (let rank = 7; rank >= 0; rank--) {
        for (let file = 0; file < 8; file++) {
          const square = file + rank * 8;
          const piece = board.get(square);
          if (!piece)
            empty++;
          else {
            if (empty > 0) {
              fen += empty;
              empty = 0;
            }
            fen += makePiece(piece);
          }
          if (file === 7) {
            if (empty > 0) {
              fen += empty;
              empty = 0;
            }
            if (rank !== 0)
              fen += "/";
          }
        }
      }
      return fen;
    };
    makePocket = (material) => ROLES.map((role) => roleToChar(role).repeat(material[role])).join("");
    makePockets = (pocket) => makePocket(pocket.white).toUpperCase() + makePocket(pocket.black);
    makeCastlingFen = (board, castlingRights) => {
      let fen = "";
      for (const color of COLORS) {
        const backrank = SquareSet.backrank(color);
        let king = board.kingOf(color);
        if (defined(king) && !backrank.has(king))
          king = void 0;
        const candidates = board.pieces(color, "rook").intersect(backrank);
        for (const rook of castlingRights.intersect(backrank).reversed()) {
          if (rook === candidates.first() && defined(king) && rook < king) {
            fen += color === "white" ? "Q" : "q";
          } else if (rook === candidates.last() && defined(king) && king < rook) {
            fen += color === "white" ? "K" : "k";
          } else {
            const file = FILE_NAMES[squareFile(rook)];
            fen += color === "white" ? file.toUpperCase() : file;
          }
        }
      }
      return fen || "-";
    };
    makeRemainingChecks = (checks) => `${checks.white}+${checks.black}`;
    makeFen = (setup, opts) => [
      makeBoardFen(setup.board) + (setup.pockets ? `[${makePockets(setup.pockets)}]` : ""),
      setup.turn[0],
      makeCastlingFen(setup.board, setup.castlingRights),
      defined(setup.epSquare) ? makeSquare(setup.epSquare) : "-",
      ...setup.remainingChecks ? [makeRemainingChecks(setup.remainingChecks)] : [],
      ...(opts === null || opts === void 0 ? void 0 : opts.epd) ? [] : [Math.max(0, Math.min(setup.halfmoves, 9999)), Math.max(1, Math.min(setup.fullmoves, 9999))]
    ].join(" ");
  }
});

// target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/attacks.js
var computeRange, tabulate, KING_ATTACKS, KNIGHT_ATTACKS, PAWN_ATTACKS, kingAttacks, knightAttacks, pawnAttacks, FILE_RANGE, RANK_RANGE, DIAG_RANGE, ANTI_DIAG_RANGE, hyperbola, fileAttacks, rankAttacks, bishopAttacks, rookAttacks, queenAttacks, attacks, ray, between;
var init_attacks = __esm({
  "target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/attacks.js"() {
    init_squareSet();
    init_util();
    computeRange = (square, deltas) => {
      let range = SquareSet.empty();
      for (const delta of deltas) {
        const sq = square + delta;
        if (0 <= sq && sq < 64 && Math.abs(squareFile(square) - squareFile(sq)) <= 2) {
          range = range.with(sq);
        }
      }
      return range;
    };
    tabulate = (f) => {
      const table = [];
      for (let square = 0; square < 64; square++)
        table[square] = f(square);
      return table;
    };
    KING_ATTACKS = tabulate((sq) => computeRange(sq, [-9, -8, -7, -1, 1, 7, 8, 9]));
    KNIGHT_ATTACKS = tabulate((sq) => computeRange(sq, [-17, -15, -10, -6, 6, 10, 15, 17]));
    PAWN_ATTACKS = {
      white: tabulate((sq) => computeRange(sq, [7, 9])),
      black: tabulate((sq) => computeRange(sq, [-7, -9]))
    };
    kingAttacks = (square) => KING_ATTACKS[square];
    knightAttacks = (square) => KNIGHT_ATTACKS[square];
    pawnAttacks = (color, square) => PAWN_ATTACKS[color][square];
    FILE_RANGE = tabulate((sq) => SquareSet.fromFile(squareFile(sq)).without(sq));
    RANK_RANGE = tabulate((sq) => SquareSet.fromRank(squareRank(sq)).without(sq));
    DIAG_RANGE = tabulate((sq) => {
      const diag = new SquareSet(134480385, 2151686160);
      const shift = 8 * (squareRank(sq) - squareFile(sq));
      return (shift >= 0 ? diag.shl64(shift) : diag.shr64(-shift)).without(sq);
    });
    ANTI_DIAG_RANGE = tabulate((sq) => {
      const diag = new SquareSet(270549120, 16909320);
      const shift = 8 * (squareRank(sq) + squareFile(sq) - 7);
      return (shift >= 0 ? diag.shl64(shift) : diag.shr64(-shift)).without(sq);
    });
    hyperbola = (bit, range, occupied) => {
      let forward = occupied.intersect(range);
      let reverse = forward.bswap64();
      forward = forward.minus64(bit);
      reverse = reverse.minus64(bit.bswap64());
      return forward.xor(reverse.bswap64()).intersect(range);
    };
    fileAttacks = (square, occupied) => hyperbola(SquareSet.fromSquare(square), FILE_RANGE[square], occupied);
    rankAttacks = (square, occupied) => {
      const range = RANK_RANGE[square];
      let forward = occupied.intersect(range);
      let reverse = forward.rbit64();
      forward = forward.minus64(SquareSet.fromSquare(square));
      reverse = reverse.minus64(SquareSet.fromSquare(63 - square));
      return forward.xor(reverse.rbit64()).intersect(range);
    };
    bishopAttacks = (square, occupied) => {
      const bit = SquareSet.fromSquare(square);
      return hyperbola(bit, DIAG_RANGE[square], occupied).xor(hyperbola(bit, ANTI_DIAG_RANGE[square], occupied));
    };
    rookAttacks = (square, occupied) => fileAttacks(square, occupied).xor(rankAttacks(square, occupied));
    queenAttacks = (square, occupied) => bishopAttacks(square, occupied).xor(rookAttacks(square, occupied));
    attacks = (piece, square, occupied) => {
      switch (piece.role) {
        case "pawn":
          return pawnAttacks(piece.color, square);
        case "knight":
          return knightAttacks(square);
        case "bishop":
          return bishopAttacks(square, occupied);
        case "rook":
          return rookAttacks(square, occupied);
        case "queen":
          return queenAttacks(square, occupied);
        case "king":
          return kingAttacks(square);
      }
    };
    ray = (a, b) => {
      const other = SquareSet.fromSquare(b);
      if (RANK_RANGE[a].intersects(other))
        return RANK_RANGE[a].with(a);
      if (ANTI_DIAG_RANGE[a].intersects(other))
        return ANTI_DIAG_RANGE[a].with(a);
      if (DIAG_RANGE[a].intersects(other))
        return DIAG_RANGE[a].with(a);
      if (FILE_RANGE[a].intersects(other))
        return FILE_RANGE[a].with(a);
      return SquareSet.empty();
    };
    between = (a, b) => ray(a, b).intersect(SquareSet.full().shl64(a).xor(SquareSet.full().shl64(b))).withoutFirst();
  }
});

// target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/san.js
var makeSanWithoutSuffix, makeSanAndPlay, makeSan;
var init_san = __esm({
  "target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/san.js"() {
    init_attacks();
    init_squareSet();
    init_types();
    init_util();
    makeSanWithoutSuffix = (pos, move) => {
      let san2 = "";
      if (isDrop(move)) {
        if (move.role !== "pawn")
          san2 = roleToChar(move.role).toUpperCase();
        san2 += "@" + makeSquare(move.to);
      } else {
        const role = pos.board.getRole(move.from);
        if (!role)
          return "--";
        if (role === "king" && (pos.board[pos.turn].has(move.to) || Math.abs(move.to - move.from) === 2)) {
          san2 = move.to > move.from ? "O-O" : "O-O-O";
        } else {
          const capture = pos.board.occupied.has(move.to) || role === "pawn" && squareFile(move.from) !== squareFile(move.to);
          if (role !== "pawn") {
            san2 = roleToChar(role).toUpperCase();
            let others;
            if (role === "king")
              others = kingAttacks(move.to).intersect(pos.board.king);
            else if (role === "queen")
              others = queenAttacks(move.to, pos.board.occupied).intersect(pos.board.queen);
            else if (role === "rook")
              others = rookAttacks(move.to, pos.board.occupied).intersect(pos.board.rook);
            else if (role === "bishop")
              others = bishopAttacks(move.to, pos.board.occupied).intersect(pos.board.bishop);
            else
              others = knightAttacks(move.to).intersect(pos.board.knight);
            others = others.intersect(pos.board[pos.turn]).without(move.from);
            if (others.nonEmpty()) {
              const ctx = pos.ctx();
              for (const from of others) {
                if (!pos.dests(from, ctx).has(move.to))
                  others = others.without(from);
              }
              if (others.nonEmpty()) {
                let row = false;
                let column = others.intersects(SquareSet.fromRank(squareRank(move.from)));
                if (others.intersects(SquareSet.fromFile(squareFile(move.from))))
                  row = true;
                else
                  column = true;
                if (column)
                  san2 += FILE_NAMES[squareFile(move.from)];
                if (row)
                  san2 += RANK_NAMES[squareRank(move.from)];
              }
            }
          } else if (capture)
            san2 = FILE_NAMES[squareFile(move.from)];
          if (capture)
            san2 += "x";
          san2 += makeSquare(move.to);
          if (move.promotion)
            san2 += "=" + roleToChar(move.promotion).toUpperCase();
        }
      }
      return san2;
    };
    makeSanAndPlay = (pos, move) => {
      var _a;
      const san2 = makeSanWithoutSuffix(pos, move);
      pos.play(move);
      if ((_a = pos.outcome()) === null || _a === void 0 ? void 0 : _a.winner)
        return san2 + "#";
      if (pos.isCheck())
        return san2 + "+";
      return san2;
    };
    makeSan = (pos, move) => makeSanAndPlay(pos.clone(), move);
  }
});

// target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/chess.js
var IllegalSetup, PositionError, attacksTo, Castles, Position, Chess, validEpSquare, legalEpSquare, canCaptureEp, castlingDest, pseudoDests, castlingSide, normalizeMove;
var init_chess = __esm({
  "target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/chess.js"() {
    init_node_mjs();
    init_attacks();
    init_board();
    init_squareSet();
    init_types();
    init_util();
    (function(IllegalSetup2) {
      IllegalSetup2["Empty"] = "ERR_EMPTY";
      IllegalSetup2["OppositeCheck"] = "ERR_OPPOSITE_CHECK";
      IllegalSetup2["PawnsOnBackrank"] = "ERR_PAWNS_ON_BACKRANK";
      IllegalSetup2["Kings"] = "ERR_KINGS";
      IllegalSetup2["Variant"] = "ERR_VARIANT";
    })(IllegalSetup || (IllegalSetup = {}));
    PositionError = class extends Error {
    };
    attacksTo = (square, attacker, board, occupied) => board[attacker].intersect(rookAttacks(square, occupied).intersect(board.rooksAndQueens()).union(bishopAttacks(square, occupied).intersect(board.bishopsAndQueens())).union(knightAttacks(square).intersect(board.knight)).union(kingAttacks(square).intersect(board.king)).union(pawnAttacks(opposite(attacker), square).intersect(board.pawn)));
    Castles = class _Castles {
      constructor() {
      }
      static default() {
        const castles = new _Castles();
        castles.castlingRights = SquareSet.corners();
        castles.rook = {
          white: { a: 0, h: 7 },
          black: { a: 56, h: 63 }
        };
        castles.path = {
          white: { a: new SquareSet(14, 0), h: new SquareSet(96, 0) },
          black: { a: new SquareSet(0, 234881024), h: new SquareSet(0, 1610612736) }
        };
        return castles;
      }
      static empty() {
        const castles = new _Castles();
        castles.castlingRights = SquareSet.empty();
        castles.rook = {
          white: { a: void 0, h: void 0 },
          black: { a: void 0, h: void 0 }
        };
        castles.path = {
          white: { a: SquareSet.empty(), h: SquareSet.empty() },
          black: { a: SquareSet.empty(), h: SquareSet.empty() }
        };
        return castles;
      }
      clone() {
        const castles = new _Castles();
        castles.castlingRights = this.castlingRights;
        castles.rook = {
          white: { a: this.rook.white.a, h: this.rook.white.h },
          black: { a: this.rook.black.a, h: this.rook.black.h }
        };
        castles.path = {
          white: { a: this.path.white.a, h: this.path.white.h },
          black: { a: this.path.black.a, h: this.path.black.h }
        };
        return castles;
      }
      add(color, side, king, rook) {
        const kingTo = kingCastlesTo(color, side);
        const rookTo = rookCastlesTo(color, side);
        this.castlingRights = this.castlingRights.with(rook);
        this.rook[color][side] = rook;
        this.path[color][side] = between(rook, rookTo).with(rookTo).union(between(king, kingTo).with(kingTo)).without(king).without(rook);
      }
      static fromSetup(setup) {
        const castles = _Castles.empty();
        const rooks = setup.castlingRights.intersect(setup.board.rook);
        for (const color of COLORS) {
          const backrank = SquareSet.backrank(color);
          const king = setup.board.kingOf(color);
          if (!defined(king) || !backrank.has(king))
            continue;
          const side = rooks.intersect(setup.board[color]).intersect(backrank);
          const aSide = side.first();
          if (defined(aSide) && aSide < king)
            castles.add(color, "a", king, aSide);
          const hSide = side.last();
          if (defined(hSide) && king < hSide)
            castles.add(color, "h", king, hSide);
        }
        return castles;
      }
      discardRook(square) {
        if (this.castlingRights.has(square)) {
          this.castlingRights = this.castlingRights.without(square);
          for (const color of COLORS) {
            for (const side of CASTLING_SIDES) {
              if (this.rook[color][side] === square)
                this.rook[color][side] = void 0;
            }
          }
        }
      }
      discardColor(color) {
        this.castlingRights = this.castlingRights.diff(SquareSet.backrank(color));
        this.rook[color].a = void 0;
        this.rook[color].h = void 0;
      }
    };
    Position = class {
      constructor(rules) {
        this.rules = rules;
      }
      reset() {
        this.board = Board.default();
        this.pockets = void 0;
        this.turn = "white";
        this.castles = Castles.default();
        this.epSquare = void 0;
        this.remainingChecks = void 0;
        this.halfmoves = 0;
        this.fullmoves = 1;
      }
      setupUnchecked(setup) {
        this.board = setup.board.clone();
        this.board.promoted = SquareSet.empty();
        this.pockets = void 0;
        this.turn = setup.turn;
        this.castles = Castles.fromSetup(setup);
        this.epSquare = validEpSquare(this, setup.epSquare);
        this.remainingChecks = void 0;
        this.halfmoves = setup.halfmoves;
        this.fullmoves = setup.fullmoves;
      }
      // When subclassing overwrite at least:
      //
      // - static default()
      // - static fromSetup()
      // - static clone()
      //
      // - dests()
      // - isVariantEnd()
      // - variantOutcome()
      // - hasInsufficientMaterial()
      // - isStandardMaterial()
      kingAttackers(square, attacker, occupied) {
        return attacksTo(square, attacker, this.board, occupied);
      }
      playCaptureAt(square, captured) {
        this.halfmoves = 0;
        if (captured.role === "rook")
          this.castles.discardRook(square);
        if (this.pockets)
          this.pockets[opposite(captured.color)][captured.promoted ? "pawn" : captured.role]++;
      }
      ctx() {
        const variantEnd = this.isVariantEnd();
        const king = this.board.kingOf(this.turn);
        if (!defined(king)) {
          return { king, blockers: SquareSet.empty(), checkers: SquareSet.empty(), variantEnd, mustCapture: false };
        }
        const snipers = rookAttacks(king, SquareSet.empty()).intersect(this.board.rooksAndQueens()).union(bishopAttacks(king, SquareSet.empty()).intersect(this.board.bishopsAndQueens())).intersect(this.board[opposite(this.turn)]);
        let blockers = SquareSet.empty();
        for (const sniper of snipers) {
          const b = between(king, sniper).intersect(this.board.occupied);
          if (!b.moreThanOne())
            blockers = blockers.union(b);
        }
        const checkers = this.kingAttackers(king, opposite(this.turn), this.board.occupied);
        return {
          king,
          blockers,
          checkers,
          variantEnd,
          mustCapture: false
        };
      }
      clone() {
        var _a, _b;
        const pos = new this.constructor();
        pos.board = this.board.clone();
        pos.pockets = (_a = this.pockets) === null || _a === void 0 ? void 0 : _a.clone();
        pos.turn = this.turn;
        pos.castles = this.castles.clone();
        pos.epSquare = this.epSquare;
        pos.remainingChecks = (_b = this.remainingChecks) === null || _b === void 0 ? void 0 : _b.clone();
        pos.halfmoves = this.halfmoves;
        pos.fullmoves = this.fullmoves;
        return pos;
      }
      validate() {
        if (this.board.occupied.isEmpty())
          return Result.err(new PositionError(IllegalSetup.Empty));
        if (this.board.king.size() !== 2)
          return Result.err(new PositionError(IllegalSetup.Kings));
        if (!defined(this.board.kingOf(this.turn)))
          return Result.err(new PositionError(IllegalSetup.Kings));
        const otherKing = this.board.kingOf(opposite(this.turn));
        if (!defined(otherKing))
          return Result.err(new PositionError(IllegalSetup.Kings));
        if (this.kingAttackers(otherKing, this.turn, this.board.occupied).nonEmpty()) {
          return Result.err(new PositionError(IllegalSetup.OppositeCheck));
        }
        if (SquareSet.backranks().intersects(this.board.pawn)) {
          return Result.err(new PositionError(IllegalSetup.PawnsOnBackrank));
        }
        return Result.ok(void 0);
      }
      dropDests(_ctx) {
        return SquareSet.empty();
      }
      dests(square, ctx) {
        ctx = ctx || this.ctx();
        if (ctx.variantEnd)
          return SquareSet.empty();
        const piece = this.board.get(square);
        if (!piece || piece.color !== this.turn)
          return SquareSet.empty();
        let pseudo, legal;
        if (piece.role === "pawn") {
          pseudo = pawnAttacks(this.turn, square).intersect(this.board[opposite(this.turn)]);
          const delta = this.turn === "white" ? 8 : -8;
          const step = square + delta;
          if (0 <= step && step < 64 && !this.board.occupied.has(step)) {
            pseudo = pseudo.with(step);
            const canDoubleStep = this.turn === "white" ? square < 16 : square >= 64 - 16;
            const doubleStep = step + delta;
            if (canDoubleStep && !this.board.occupied.has(doubleStep)) {
              pseudo = pseudo.with(doubleStep);
            }
          }
          if (defined(this.epSquare) && canCaptureEp(this, square, ctx)) {
            legal = SquareSet.fromSquare(this.epSquare);
          }
        } else if (piece.role === "bishop")
          pseudo = bishopAttacks(square, this.board.occupied);
        else if (piece.role === "knight")
          pseudo = knightAttacks(square);
        else if (piece.role === "rook")
          pseudo = rookAttacks(square, this.board.occupied);
        else if (piece.role === "queen")
          pseudo = queenAttacks(square, this.board.occupied);
        else
          pseudo = kingAttacks(square);
        pseudo = pseudo.diff(this.board[this.turn]);
        if (defined(ctx.king)) {
          if (piece.role === "king") {
            const occ = this.board.occupied.without(square);
            for (const to of pseudo) {
              if (this.kingAttackers(to, opposite(this.turn), occ).nonEmpty())
                pseudo = pseudo.without(to);
            }
            return pseudo.union(castlingDest(this, "a", ctx)).union(castlingDest(this, "h", ctx));
          }
          if (ctx.checkers.nonEmpty()) {
            const checker = ctx.checkers.singleSquare();
            if (!defined(checker))
              return SquareSet.empty();
            pseudo = pseudo.intersect(between(checker, ctx.king).with(checker));
          }
          if (ctx.blockers.has(square))
            pseudo = pseudo.intersect(ray(square, ctx.king));
        }
        if (legal)
          pseudo = pseudo.union(legal);
        return pseudo;
      }
      isVariantEnd() {
        return false;
      }
      variantOutcome(_ctx) {
        return;
      }
      hasInsufficientMaterial(color) {
        if (this.board[color].intersect(this.board.pawn.union(this.board.rooksAndQueens())).nonEmpty())
          return false;
        if (this.board[color].intersects(this.board.knight)) {
          return this.board[color].size() <= 2 && this.board[opposite(color)].diff(this.board.king).diff(this.board.queen).isEmpty();
        }
        if (this.board[color].intersects(this.board.bishop)) {
          const sameColor = !this.board.bishop.intersects(SquareSet.darkSquares()) || !this.board.bishop.intersects(SquareSet.lightSquares());
          return sameColor && this.board.pawn.isEmpty() && this.board.knight.isEmpty();
        }
        return true;
      }
      // The following should be identical in all subclasses
      toSetup() {
        var _a, _b;
        return {
          board: this.board.clone(),
          pockets: (_a = this.pockets) === null || _a === void 0 ? void 0 : _a.clone(),
          turn: this.turn,
          castlingRights: this.castles.castlingRights,
          epSquare: legalEpSquare(this),
          remainingChecks: (_b = this.remainingChecks) === null || _b === void 0 ? void 0 : _b.clone(),
          halfmoves: Math.min(this.halfmoves, 150),
          fullmoves: Math.min(Math.max(this.fullmoves, 1), 9999)
        };
      }
      isInsufficientMaterial() {
        return COLORS.every((color) => this.hasInsufficientMaterial(color));
      }
      hasDests(ctx) {
        ctx = ctx || this.ctx();
        for (const square of this.board[this.turn]) {
          if (this.dests(square, ctx).nonEmpty())
            return true;
        }
        return this.dropDests(ctx).nonEmpty();
      }
      isLegal(move, ctx) {
        if (isDrop(move)) {
          if (!this.pockets || this.pockets[this.turn][move.role] <= 0)
            return false;
          if (move.role === "pawn" && SquareSet.backranks().has(move.to))
            return false;
          return this.dropDests(ctx).has(move.to);
        } else {
          if (move.promotion === "pawn")
            return false;
          if (move.promotion === "king" && this.rules !== "antichess")
            return false;
          if (!!move.promotion !== (this.board.pawn.has(move.from) && SquareSet.backranks().has(move.to)))
            return false;
          const dests = this.dests(move.from, ctx);
          return dests.has(move.to) || dests.has(normalizeMove(this, move).to);
        }
      }
      isCheck() {
        const king = this.board.kingOf(this.turn);
        return defined(king) && this.kingAttackers(king, opposite(this.turn), this.board.occupied).nonEmpty();
      }
      isEnd(ctx) {
        if (ctx ? ctx.variantEnd : this.isVariantEnd())
          return true;
        return this.isInsufficientMaterial() || !this.hasDests(ctx);
      }
      isCheckmate(ctx) {
        ctx = ctx || this.ctx();
        return !ctx.variantEnd && ctx.checkers.nonEmpty() && !this.hasDests(ctx);
      }
      isStalemate(ctx) {
        ctx = ctx || this.ctx();
        return !ctx.variantEnd && ctx.checkers.isEmpty() && !this.hasDests(ctx);
      }
      outcome(ctx) {
        const variantOutcome = this.variantOutcome(ctx);
        if (variantOutcome)
          return variantOutcome;
        ctx = ctx || this.ctx();
        if (this.isCheckmate(ctx))
          return { winner: opposite(this.turn) };
        else if (this.isInsufficientMaterial() || this.isStalemate(ctx))
          return { winner: void 0 };
        else
          return;
      }
      allDests(ctx) {
        ctx = ctx || this.ctx();
        const d = /* @__PURE__ */ new Map();
        if (ctx.variantEnd)
          return d;
        for (const square of this.board[this.turn]) {
          d.set(square, this.dests(square, ctx));
        }
        return d;
      }
      play(move) {
        const turn = this.turn;
        const epSquare = this.epSquare;
        const castling = castlingSide(this, move);
        this.epSquare = void 0;
        this.halfmoves += 1;
        if (turn === "black")
          this.fullmoves += 1;
        this.turn = opposite(turn);
        if (isDrop(move)) {
          this.board.set(move.to, { role: move.role, color: turn });
          if (this.pockets)
            this.pockets[turn][move.role]--;
          if (move.role === "pawn")
            this.halfmoves = 0;
        } else {
          const piece = this.board.take(move.from);
          if (!piece)
            return;
          let epCapture;
          if (piece.role === "pawn") {
            this.halfmoves = 0;
            if (move.to === epSquare) {
              epCapture = this.board.take(move.to + (turn === "white" ? -8 : 8));
            }
            const delta = move.from - move.to;
            if (Math.abs(delta) === 16 && 8 <= move.from && move.from <= 55) {
              this.epSquare = move.from + move.to >> 1;
            }
            if (move.promotion) {
              piece.role = move.promotion;
              piece.promoted = !!this.pockets;
            }
          } else if (piece.role === "rook") {
            this.castles.discardRook(move.from);
          } else if (piece.role === "king") {
            if (castling) {
              const rookFrom = this.castles.rook[turn][castling];
              if (defined(rookFrom)) {
                const rook = this.board.take(rookFrom);
                this.board.set(kingCastlesTo(turn, castling), piece);
                if (rook)
                  this.board.set(rookCastlesTo(turn, castling), rook);
              }
            }
            this.castles.discardColor(turn);
          }
          if (!castling) {
            const capture = this.board.set(move.to, piece) || epCapture;
            if (capture)
              this.playCaptureAt(move.to, capture);
          }
        }
        if (this.remainingChecks) {
          if (this.isCheck())
            this.remainingChecks[turn] = Math.max(this.remainingChecks[turn] - 1, 0);
        }
      }
    };
    Chess = class extends Position {
      constructor() {
        super("chess");
      }
      static default() {
        const pos = new this();
        pos.reset();
        return pos;
      }
      static fromSetup(setup) {
        const pos = new this();
        pos.setupUnchecked(setup);
        return pos.validate().map((_) => pos);
      }
      clone() {
        return super.clone();
      }
    };
    validEpSquare = (pos, square) => {
      if (!defined(square))
        return;
      const epRank = pos.turn === "white" ? 5 : 2;
      const forward = pos.turn === "white" ? 8 : -8;
      if (squareRank(square) !== epRank)
        return;
      if (pos.board.occupied.has(square + forward))
        return;
      const pawn = square - forward;
      if (!pos.board.pawn.has(pawn) || !pos.board[opposite(pos.turn)].has(pawn))
        return;
      return square;
    };
    legalEpSquare = (pos) => {
      if (!defined(pos.epSquare))
        return;
      const ctx = pos.ctx();
      const ourPawns = pos.board.pieces(pos.turn, "pawn");
      const candidates = ourPawns.intersect(pawnAttacks(opposite(pos.turn), pos.epSquare));
      for (const candidate of candidates) {
        if (pos.dests(candidate, ctx).has(pos.epSquare))
          return pos.epSquare;
      }
      return;
    };
    canCaptureEp = (pos, pawnFrom, ctx) => {
      if (!defined(pos.epSquare))
        return false;
      if (!pawnAttacks(pos.turn, pawnFrom).has(pos.epSquare))
        return false;
      if (!defined(ctx.king))
        return true;
      const delta = pos.turn === "white" ? 8 : -8;
      const captured = pos.epSquare - delta;
      return pos.kingAttackers(ctx.king, opposite(pos.turn), pos.board.occupied.toggle(pawnFrom).toggle(captured).with(pos.epSquare)).without(captured).isEmpty();
    };
    castlingDest = (pos, side, ctx) => {
      if (!defined(ctx.king) || ctx.checkers.nonEmpty())
        return SquareSet.empty();
      const rook = pos.castles.rook[pos.turn][side];
      if (!defined(rook))
        return SquareSet.empty();
      if (pos.castles.path[pos.turn][side].intersects(pos.board.occupied))
        return SquareSet.empty();
      const kingTo = kingCastlesTo(pos.turn, side);
      const kingPath = between(ctx.king, kingTo);
      const occ = pos.board.occupied.without(ctx.king);
      for (const sq of kingPath) {
        if (pos.kingAttackers(sq, opposite(pos.turn), occ).nonEmpty())
          return SquareSet.empty();
      }
      const rookTo = rookCastlesTo(pos.turn, side);
      const after = pos.board.occupied.toggle(ctx.king).toggle(rook).toggle(rookTo);
      if (pos.kingAttackers(kingTo, opposite(pos.turn), after).nonEmpty())
        return SquareSet.empty();
      return SquareSet.fromSquare(rook);
    };
    pseudoDests = (pos, square, ctx) => {
      if (ctx.variantEnd)
        return SquareSet.empty();
      const piece = pos.board.get(square);
      if (!piece || piece.color !== pos.turn)
        return SquareSet.empty();
      let pseudo = attacks(piece, square, pos.board.occupied);
      if (piece.role === "pawn") {
        let captureTargets = pos.board[opposite(pos.turn)];
        if (defined(pos.epSquare))
          captureTargets = captureTargets.with(pos.epSquare);
        pseudo = pseudo.intersect(captureTargets);
        const delta = pos.turn === "white" ? 8 : -8;
        const step = square + delta;
        if (0 <= step && step < 64 && !pos.board.occupied.has(step)) {
          pseudo = pseudo.with(step);
          const canDoubleStep = pos.turn === "white" ? square < 16 : square >= 64 - 16;
          const doubleStep = step + delta;
          if (canDoubleStep && !pos.board.occupied.has(doubleStep)) {
            pseudo = pseudo.with(doubleStep);
          }
        }
        return pseudo;
      } else {
        pseudo = pseudo.diff(pos.board[pos.turn]);
      }
      if (square === ctx.king)
        return pseudo.union(castlingDest(pos, "a", ctx)).union(castlingDest(pos, "h", ctx));
      else
        return pseudo;
    };
    castlingSide = (pos, move) => {
      if (isDrop(move))
        return;
      const delta = move.to - move.from;
      if (Math.abs(delta) !== 2 && !pos.board[pos.turn].has(move.to))
        return;
      if (!pos.board.king.has(move.from))
        return;
      return delta > 0 ? "h" : "a";
    };
    normalizeMove = (pos, move) => {
      const side = castlingSide(pos, move);
      if (!side)
        return move;
      const rookFrom = pos.castles.rook[pos.turn][side];
      return {
        from: move.from,
        to: defined(rookFrom) ? rookFrom : move.to
      };
    };
  }
});

// target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/variant.js
var Crazyhouse, Atomic, Antichess, KingOfTheHill, ThreeCheck, racingKingsBoard, RacingKings, hordeBoard, Horde, setupPosition;
var init_variant = __esm({
  "target/relationship-delivery-20261004/frontend-probe/node_modules/chessops/dist/esm/variant.js"() {
    init_node_mjs();
    init_attacks();
    init_board();
    init_chess();
    init_setup();
    init_squareSet();
    init_types();
    init_util();
    Crazyhouse = class extends Position {
      constructor() {
        super("crazyhouse");
      }
      reset() {
        super.reset();
        this.pockets = Material.empty();
      }
      setupUnchecked(setup) {
        super.setupUnchecked(setup);
        this.board.promoted = setup.board.promoted.intersect(setup.board.occupied).diff(setup.board.king).diff(setup.board.pawn);
        this.pockets = setup.pockets ? setup.pockets.clone() : Material.empty();
      }
      static default() {
        const pos = new this();
        pos.reset();
        return pos;
      }
      static fromSetup(setup) {
        const pos = new this();
        pos.setupUnchecked(setup);
        return pos.validate().map((_) => pos);
      }
      clone() {
        return super.clone();
      }
      validate() {
        return super.validate().chain((_) => {
          var _a, _b;
          if ((_a = this.pockets) === null || _a === void 0 ? void 0 : _a.count("king")) {
            return Result.err(new PositionError(IllegalSetup.Kings));
          }
          if ((((_b = this.pockets) === null || _b === void 0 ? void 0 : _b.size()) || 0) + this.board.occupied.size() > 64) {
            return Result.err(new PositionError(IllegalSetup.Variant));
          }
          return Result.ok(void 0);
        });
      }
      hasInsufficientMaterial(color) {
        if (!this.pockets)
          return super.hasInsufficientMaterial(color);
        return this.board.occupied.size() + this.pockets.size() <= 3 && this.board.pawn.isEmpty() && this.board.promoted.isEmpty() && this.board.rooksAndQueens().isEmpty() && this.pockets.count("pawn") <= 0 && this.pockets.count("rook") <= 0 && this.pockets.count("queen") <= 0;
      }
      dropDests(ctx) {
        var _a, _b;
        const mask = this.board.occupied.complement().intersect(((_a = this.pockets) === null || _a === void 0 ? void 0 : _a[this.turn].hasNonPawns()) ? SquareSet.full() : ((_b = this.pockets) === null || _b === void 0 ? void 0 : _b[this.turn].hasPawns()) ? SquareSet.backranks().complement() : SquareSet.empty());
        ctx = ctx || this.ctx();
        if (defined(ctx.king) && ctx.checkers.nonEmpty()) {
          const checker = ctx.checkers.singleSquare();
          if (!defined(checker))
            return SquareSet.empty();
          return mask.intersect(between(checker, ctx.king));
        } else
          return mask;
      }
    };
    Atomic = class extends Position {
      constructor() {
        super("atomic");
      }
      static default() {
        const pos = new this();
        pos.reset();
        return pos;
      }
      static fromSetup(setup) {
        const pos = new this();
        pos.setupUnchecked(setup);
        return pos.validate().map((_) => pos);
      }
      clone() {
        return super.clone();
      }
      validate() {
        if (this.board.occupied.isEmpty())
          return Result.err(new PositionError(IllegalSetup.Empty));
        if (this.board.king.size() > 2)
          return Result.err(new PositionError(IllegalSetup.Kings));
        const otherKing = this.board.kingOf(opposite(this.turn));
        if (!defined(otherKing))
          return Result.err(new PositionError(IllegalSetup.Kings));
        if (this.kingAttackers(otherKing, this.turn, this.board.occupied).nonEmpty()) {
          return Result.err(new PositionError(IllegalSetup.OppositeCheck));
        }
        if (SquareSet.backranks().intersects(this.board.pawn)) {
          return Result.err(new PositionError(IllegalSetup.PawnsOnBackrank));
        }
        return Result.ok(void 0);
      }
      kingAttackers(square, attacker, occupied) {
        const attackerKings = this.board.pieces(attacker, "king");
        if (attackerKings.isEmpty() || kingAttacks(square).intersects(attackerKings)) {
          return SquareSet.empty();
        }
        return super.kingAttackers(square, attacker, occupied);
      }
      playCaptureAt(square, captured) {
        super.playCaptureAt(square, captured);
        this.board.take(square);
        for (const explode of kingAttacks(square).intersect(this.board.occupied).diff(this.board.pawn)) {
          const piece = this.board.take(explode);
          if ((piece === null || piece === void 0 ? void 0 : piece.role) === "rook")
            this.castles.discardRook(explode);
          if ((piece === null || piece === void 0 ? void 0 : piece.role) === "king")
            this.castles.discardColor(piece.color);
        }
      }
      hasInsufficientMaterial(color) {
        if (this.board.pieces(opposite(color), "king").isEmpty())
          return false;
        if (this.board[color].diff(this.board.king).isEmpty())
          return true;
        if (this.board[opposite(color)].diff(this.board.king).nonEmpty()) {
          if (this.board.occupied.equals(this.board.bishop.union(this.board.king))) {
            if (!this.board.bishop.intersect(this.board.white).intersects(SquareSet.darkSquares())) {
              return !this.board.bishop.intersect(this.board.black).intersects(SquareSet.lightSquares());
            }
            if (!this.board.bishop.intersect(this.board.white).intersects(SquareSet.lightSquares())) {
              return !this.board.bishop.intersect(this.board.black).intersects(SquareSet.darkSquares());
            }
          }
          return false;
        }
        if (this.board.queen.nonEmpty() || this.board.pawn.nonEmpty())
          return false;
        if (this.board.knight.union(this.board.bishop).union(this.board.rook).size() === 1)
          return true;
        if (this.board.occupied.equals(this.board.knight.union(this.board.king))) {
          return this.board.knight.size() <= 2;
        }
        return false;
      }
      dests(square, ctx) {
        ctx = ctx || this.ctx();
        let dests = SquareSet.empty();
        for (const to of pseudoDests(this, square, ctx)) {
          const after = this.clone();
          after.play({ from: square, to });
          const ourKing = after.board.kingOf(this.turn);
          if (defined(ourKing) && (!defined(after.board.kingOf(after.turn)) || after.kingAttackers(ourKing, after.turn, after.board.occupied).isEmpty())) {
            dests = dests.with(to);
          }
        }
        return dests;
      }
      isVariantEnd() {
        return !!this.variantOutcome();
      }
      variantOutcome(_ctx) {
        for (const color of COLORS) {
          if (this.board.pieces(color, "king").isEmpty())
            return { winner: opposite(color) };
        }
        return;
      }
    };
    Antichess = class extends Position {
      constructor() {
        super("antichess");
      }
      reset() {
        super.reset();
        this.castles = Castles.empty();
      }
      setupUnchecked(setup) {
        super.setupUnchecked(setup);
        this.castles = Castles.empty();
      }
      static default() {
        const pos = new this();
        pos.reset();
        return pos;
      }
      static fromSetup(setup) {
        const pos = new this();
        pos.setupUnchecked(setup);
        return pos.validate().map((_) => pos);
      }
      clone() {
        return super.clone();
      }
      validate() {
        if (this.board.occupied.isEmpty())
          return Result.err(new PositionError(IllegalSetup.Empty));
        if (SquareSet.backranks().intersects(this.board.pawn)) {
          return Result.err(new PositionError(IllegalSetup.PawnsOnBackrank));
        }
        return Result.ok(void 0);
      }
      kingAttackers(_square, _attacker, _occupied) {
        return SquareSet.empty();
      }
      ctx() {
        const ctx = super.ctx();
        if (defined(this.epSquare) && pawnAttacks(opposite(this.turn), this.epSquare).intersects(this.board.pieces(this.turn, "pawn"))) {
          ctx.mustCapture = true;
          return ctx;
        }
        const enemy = this.board[opposite(this.turn)];
        for (const from of this.board[this.turn]) {
          if (pseudoDests(this, from, ctx).intersects(enemy)) {
            ctx.mustCapture = true;
            return ctx;
          }
        }
        return ctx;
      }
      dests(square, ctx) {
        ctx = ctx || this.ctx();
        const dests = pseudoDests(this, square, ctx);
        const enemy = this.board[opposite(this.turn)];
        return dests.intersect(ctx.mustCapture ? defined(this.epSquare) && this.board.getRole(square) === "pawn" ? enemy.with(this.epSquare) : enemy : SquareSet.full());
      }
      hasInsufficientMaterial(color) {
        if (this.board[color].isEmpty())
          return false;
        if (this.board[opposite(color)].isEmpty())
          return true;
        if (this.board.occupied.equals(this.board.bishop)) {
          const weSomeOnLight = this.board[color].intersects(SquareSet.lightSquares());
          const weSomeOnDark = this.board[color].intersects(SquareSet.darkSquares());
          const theyAllOnDark = this.board[opposite(color)].isDisjoint(SquareSet.lightSquares());
          const theyAllOnLight = this.board[opposite(color)].isDisjoint(SquareSet.darkSquares());
          return weSomeOnLight && theyAllOnDark || weSomeOnDark && theyAllOnLight;
        }
        if (this.board.occupied.equals(this.board.knight) && this.board.occupied.size() === 2) {
          return this.board.white.intersects(SquareSet.lightSquares()) !== this.board.black.intersects(SquareSet.darkSquares()) !== (this.turn === color);
        }
        return false;
      }
      isVariantEnd() {
        return this.board[this.turn].isEmpty();
      }
      variantOutcome(ctx) {
        ctx = ctx || this.ctx();
        if (ctx.variantEnd || this.isStalemate(ctx)) {
          return { winner: this.turn };
        }
        return;
      }
    };
    KingOfTheHill = class extends Position {
      constructor() {
        super("kingofthehill");
      }
      static default() {
        const pos = new this();
        pos.reset();
        return pos;
      }
      static fromSetup(setup) {
        const pos = new this();
        pos.setupUnchecked(setup);
        return pos.validate().map((_) => pos);
      }
      clone() {
        return super.clone();
      }
      hasInsufficientMaterial(_color) {
        return false;
      }
      isVariantEnd() {
        return this.board.king.intersects(SquareSet.center());
      }
      variantOutcome(_ctx) {
        for (const color of COLORS) {
          if (this.board.pieces(color, "king").intersects(SquareSet.center()))
            return { winner: color };
        }
        return;
      }
    };
    ThreeCheck = class extends Position {
      constructor() {
        super("3check");
      }
      reset() {
        super.reset();
        this.remainingChecks = RemainingChecks.default();
      }
      setupUnchecked(setup) {
        var _a;
        super.setupUnchecked(setup);
        this.remainingChecks = ((_a = setup.remainingChecks) === null || _a === void 0 ? void 0 : _a.clone()) || RemainingChecks.default();
      }
      static default() {
        const pos = new this();
        pos.reset();
        return pos;
      }
      static fromSetup(setup) {
        const pos = new this();
        pos.setupUnchecked(setup);
        return pos.validate().map((_) => pos);
      }
      clone() {
        return super.clone();
      }
      hasInsufficientMaterial(color) {
        return this.board.pieces(color, "king").equals(this.board[color]);
      }
      isVariantEnd() {
        return !!this.remainingChecks && (this.remainingChecks.white <= 0 || this.remainingChecks.black <= 0);
      }
      variantOutcome(_ctx) {
        if (this.remainingChecks) {
          for (const color of COLORS) {
            if (this.remainingChecks[color] <= 0)
              return { winner: color };
          }
        }
        return;
      }
    };
    racingKingsBoard = () => {
      const board = Board.empty();
      board.occupied = new SquareSet(65535, 0);
      board.promoted = SquareSet.empty();
      board.white = new SquareSet(61680, 0);
      board.black = new SquareSet(3855, 0);
      board.pawn = SquareSet.empty();
      board.knight = new SquareSet(6168, 0);
      board.bishop = new SquareSet(9252, 0);
      board.rook = new SquareSet(16962, 0);
      board.queen = new SquareSet(129, 0);
      board.king = new SquareSet(33024, 0);
      return board;
    };
    RacingKings = class extends Position {
      constructor() {
        super("racingkings");
      }
      reset() {
        this.board = racingKingsBoard();
        this.pockets = void 0;
        this.turn = "white";
        this.castles = Castles.empty();
        this.epSquare = void 0;
        this.remainingChecks = void 0;
        this.halfmoves = 0;
        this.fullmoves = 1;
      }
      setupUnchecked(setup) {
        super.setupUnchecked(setup);
        this.castles = Castles.empty();
      }
      static default() {
        const pos = new this();
        pos.reset();
        return pos;
      }
      static fromSetup(setup) {
        const pos = new this();
        pos.setupUnchecked(setup);
        return pos.validate().map((_) => pos);
      }
      clone() {
        return super.clone();
      }
      validate() {
        if (this.isCheck() || this.board.pawn.nonEmpty())
          return Result.err(new PositionError(IllegalSetup.Variant));
        return super.validate();
      }
      dests(square, ctx) {
        ctx = ctx || this.ctx();
        if (square === ctx.king)
          return super.dests(square, ctx);
        let dests = SquareSet.empty();
        for (const to of super.dests(square, ctx)) {
          const move = { from: square, to };
          const after = this.clone();
          after.play(move);
          if (!after.isCheck())
            dests = dests.with(to);
        }
        return dests;
      }
      hasInsufficientMaterial(_color) {
        return false;
      }
      isVariantEnd() {
        const goal = SquareSet.fromRank(7);
        const inGoal = this.board.king.intersect(goal);
        if (inGoal.isEmpty())
          return false;
        if (this.turn === "white" || inGoal.intersects(this.board.black))
          return true;
        const blackKing = this.board.kingOf("black");
        if (defined(blackKing)) {
          const occ = this.board.occupied.without(blackKing);
          for (const target of kingAttacks(blackKing).intersect(goal).diff(this.board.black)) {
            if (this.kingAttackers(target, "white", occ).isEmpty())
              return false;
          }
        }
        return true;
      }
      variantOutcome(ctx) {
        if (ctx ? !ctx.variantEnd : !this.isVariantEnd())
          return;
        const goal = SquareSet.fromRank(7);
        const blackInGoal = this.board.pieces("black", "king").intersects(goal);
        const whiteInGoal = this.board.pieces("white", "king").intersects(goal);
        if (blackInGoal && !whiteInGoal)
          return { winner: "black" };
        if (whiteInGoal && !blackInGoal)
          return { winner: "white" };
        return { winner: void 0 };
      }
    };
    hordeBoard = () => {
      const board = Board.empty();
      board.occupied = new SquareSet(4294967295, 4294901862);
      board.promoted = SquareSet.empty();
      board.white = new SquareSet(4294967295, 102);
      board.black = new SquareSet(0, 4294901760);
      board.pawn = new SquareSet(4294967295, 16711782);
      board.knight = new SquareSet(0, 1107296256);
      board.bishop = new SquareSet(0, 603979776);
      board.rook = new SquareSet(0, 2164260864);
      board.queen = new SquareSet(0, 134217728);
      board.king = new SquareSet(0, 268435456);
      return board;
    };
    Horde = class extends Position {
      constructor() {
        super("horde");
      }
      reset() {
        this.board = hordeBoard();
        this.pockets = void 0;
        this.turn = "white";
        this.castles = Castles.default();
        this.castles.discardColor("white");
        this.epSquare = void 0;
        this.remainingChecks = void 0;
        this.halfmoves = 0;
        this.fullmoves = 1;
      }
      static default() {
        const pos = new this();
        pos.reset();
        return pos;
      }
      static fromSetup(setup) {
        const pos = new this();
        pos.setupUnchecked(setup);
        return pos.validate().map((_) => pos);
      }
      clone() {
        return super.clone();
      }
      validate() {
        if (this.board.occupied.isEmpty())
          return Result.err(new PositionError(IllegalSetup.Empty));
        if (this.board.king.size() !== 1)
          return Result.err(new PositionError(IllegalSetup.Kings));
        const otherKing = this.board.kingOf(opposite(this.turn));
        if (defined(otherKing) && this.kingAttackers(otherKing, this.turn, this.board.occupied).nonEmpty()) {
          return Result.err(new PositionError(IllegalSetup.OppositeCheck));
        }
        for (const color of COLORS) {
          const backranks = this.board.pieces(color, "king").isEmpty() ? SquareSet.backrank(opposite(color)) : SquareSet.backranks();
          if (this.board.pieces(color, "pawn").intersects(backranks)) {
            return Result.err(new PositionError(IllegalSetup.PawnsOnBackrank));
          }
        }
        return Result.ok(void 0);
      }
      hasInsufficientMaterial(color) {
        if (this.board.pieces(color, "king").nonEmpty())
          return false;
        const oppositeSquareColor = (squareColor) => squareColor === "light" ? "dark" : "light";
        const coloredSquares = (squareColor) => squareColor === "light" ? SquareSet.lightSquares() : SquareSet.darkSquares();
        const hasBishopPair = (side) => {
          const bishops = this.board.pieces(side, "bishop");
          return bishops.intersects(SquareSet.darkSquares()) && bishops.intersects(SquareSet.lightSquares());
        };
        const horde = MaterialSide.fromBoard(this.board, color);
        const hordeBishops = (squareColor) => coloredSquares(squareColor).intersect(this.board.pieces(color, "bishop")).size();
        const hordeBishopColor = hordeBishops("light") >= 1 ? "light" : "dark";
        const hordeNum = horde.pawn + horde.knight + horde.rook + horde.queen + Math.min(hordeBishops("dark"), 2) + Math.min(hordeBishops("light"), 2);
        const pieces = MaterialSide.fromBoard(this.board, opposite(color));
        const piecesBishops = (squareColor) => coloredSquares(squareColor).intersect(this.board.pieces(opposite(color), "bishop")).size();
        const piecesNum = pieces.size();
        const piecesOfRoleNot = (piece) => piecesNum - piece;
        if (hordeNum === 0)
          return true;
        if (hordeNum >= 4) {
          return false;
        }
        if ((horde.pawn >= 1 || horde.queen >= 1) && hordeNum >= 2) {
          return false;
        }
        if (horde.rook >= 1 && hordeNum >= 2) {
          if (!(hordeNum === 2 && horde.rook === 1 && horde.bishop === 1 && piecesOfRoleNot(piecesBishops(hordeBishopColor)) === 1)) {
            return false;
          }
        }
        if (hordeNum === 1) {
          if (piecesNum === 1) {
            return true;
          } else if (horde.queen === 1) {
            return !(pieces.pawn >= 1 || pieces.rook >= 1 || piecesBishops("light") >= 2 || piecesBishops("dark") >= 2);
          } else if (horde.pawn === 1) {
            const pawnSquare = this.board.pieces(color, "pawn").last();
            const promoteToQueen = this.clone();
            promoteToQueen.board.set(pawnSquare, { color, role: "queen" });
            const promoteToKnight = this.clone();
            promoteToKnight.board.set(pawnSquare, { color, role: "knight" });
            return promoteToQueen.hasInsufficientMaterial(color) && promoteToKnight.hasInsufficientMaterial(color);
          } else if (horde.rook === 1) {
            return !(pieces.pawn >= 2 || pieces.rook >= 1 && pieces.pawn >= 1 || pieces.rook >= 1 && pieces.knight >= 1 || pieces.pawn >= 1 && pieces.knight >= 1);
          } else if (horde.bishop === 1) {
            return !// The king can be mated on A1 if there is a pawn/opposite-color-bishop
            // on A2 and an opposite-color-bishop on B1.
            // If black has two or more pawns, white gets the benefit of the doubt;
            // there is an outside chance that white promotes its pawns to
            // opposite-color-bishops and selfmates theirself.
            // Every other case that the king is mated by the bishop requires that
            // black has two pawns or two opposite-color-bishop or a pawn and an
            // opposite-color-bishop.
            // For example a king on A3 can be mated if there is
            // a pawn/opposite-color-bishop on A4, a pawn/opposite-color-bishop on
            // B3, a pawn/bishop/rook/queen on A2 and any other piece on B2.
            (piecesBishops(oppositeSquareColor(hordeBishopColor)) >= 2 || piecesBishops(oppositeSquareColor(hordeBishopColor)) >= 1 && pieces.pawn >= 1 || pieces.pawn >= 2);
          } else if (horde.knight === 1) {
            return !// The king on A1 can be smother mated by a knight on C2 if there is
            // a pawn/knight/bishop on B2, a knight/rook on B1 and any other piece
            // on A2.
            // Moreover, when black has four or more pieces and two of them are
            // pawns, black can promote their pawns and selfmate theirself.
            (piecesNum >= 4 && (pieces.knight >= 2 || pieces.pawn >= 2 || pieces.rook >= 1 && pieces.knight >= 1 || pieces.rook >= 1 && pieces.bishop >= 1 || pieces.knight >= 1 && pieces.bishop >= 1 || pieces.rook >= 1 && pieces.pawn >= 1 || pieces.knight >= 1 && pieces.pawn >= 1 || pieces.bishop >= 1 && pieces.pawn >= 1 || hasBishopPair(opposite(color)) && pieces.pawn >= 1) && (piecesBishops("dark") < 2 || piecesOfRoleNot(piecesBishops("dark")) >= 3) && (piecesBishops("light") < 2 || piecesOfRoleNot(piecesBishops("light")) >= 3));
          }
        } else if (hordeNum === 2) {
          if (piecesNum === 1) {
            return true;
          } else if (horde.knight === 2) {
            return pieces.pawn + pieces.bishop + pieces.knight < 1;
          } else if (hasBishopPair(color)) {
            return !// A king on A1 obstructed by a pawn/bishop on A2 is mated
            // by the bishop pair.
            (pieces.pawn >= 1 || pieces.bishop >= 1 || pieces.knight >= 1 && pieces.rook + pieces.queen >= 1);
          } else if (horde.bishop >= 1 && horde.knight >= 1) {
            return !// A king on A1 obstructed by a pawn/opposite-color-bishop on
            // A2 is mated by a knight on D2 and a bishop on C3.
            (pieces.pawn >= 1 || piecesBishops(oppositeSquareColor(hordeBishopColor)) >= 1 || piecesOfRoleNot(piecesBishops(hordeBishopColor)) >= 3);
          } else {
            return !// A king on A1 obstructed by a pawn/opposite-bishop/knight
            // on A2 and a opposite-bishop/knight on B1 is mated by two
            // bishops on B2 and C3. This position is theoretically
            // achievable even when black has two pawns or when they
            // have a pawn and an opposite color bishop.
            (pieces.pawn >= 1 && piecesBishops(oppositeSquareColor(hordeBishopColor)) >= 1 || pieces.pawn >= 1 && pieces.knight >= 1 || piecesBishops(oppositeSquareColor(hordeBishopColor)) >= 1 && pieces.knight >= 1 || piecesBishops(oppositeSquareColor(hordeBishopColor)) >= 2 || pieces.knight >= 2 || pieces.pawn >= 2);
          }
        } else if (hordeNum === 3) {
          if (horde.knight === 2 && horde.bishop === 1 || horde.knight === 3 || hasBishopPair(color)) {
            return false;
          } else {
            return piecesNum === 1;
          }
        }
        return true;
      }
      isVariantEnd() {
        return this.board.white.isEmpty() || this.board.black.isEmpty();
      }
      variantOutcome(_ctx) {
        if (this.board.white.isEmpty())
          return { winner: "black" };
        if (this.board.black.isEmpty())
          return { winner: "white" };
        return;
      }
    };
    setupPosition = (rules, setup) => {
      switch (rules) {
        case "chess":
          return Chess.fromSetup(setup);
        case "antichess":
          return Antichess.fromSetup(setup);
        case "atomic":
          return Atomic.fromSetup(setup);
        case "horde":
          return Horde.fromSetup(setup);
        case "racingkings":
          return RacingKings.fromSetup(setup);
        case "kingofthehill":
          return KingOfTheHill.fromSetup(setup);
        case "3check":
          return ThreeCheck.fromSetup(setup);
        case "crazyhouse":
          return Crazyhouse.fromSetup(setup);
      }
    };
  }
});

// lila-docker/repos/lila/ui/lib/src/async.ts
var init_async = __esm({
  "lila-docker/repos/lila/ui/lib/src/async.ts"() {
  }
});

// lila-docker/repos/lila/ui/lib/src/richText.ts
var init_richText = __esm({
  "lila-docker/repos/lila/ui/lib/src/richText.ts"() {
    init_src();
  }
});

// lila-docker/repos/lila/ui/lib/src/common.ts
var defined2, memoize;
var init_common = __esm({
  "lila-docker/repos/lila/ui/lib/src/common.ts"() {
    defined2 = (value) => value !== void 0;
    memoize = (compute) => {
      let computed;
      return () => {
        if (computed === void 0) computed = compute();
        return computed;
      };
    };
  }
});

// lila-docker/repos/lila/ui/lib/src/storage.ts
function makeStorage(broadcastName) {
  const values = /* @__PURE__ */ new Map();
  const listeners = /* @__PURE__ */ new Map();
  const source = Math.random().toString(36).slice(2);
  let channel;
  const ensureChannel = () => {
    if (!broadcastName || channel || typeof window === "undefined" || typeof window.BroadcastChannel !== "function")
      return channel;
    channel = new window.BroadcastChannel(broadcastName);
    channel.addEventListener("message", (event) => {
      const message = event.data;
      if (!message || message.source === source || typeof message.key !== "string") return;
      const storageEvent = {
        sri: message.source,
        nonce: message.nonce,
        value: message.value
      };
      listeners.get(message.key)?.forEach((listener) => listener(storageEvent));
    });
    return channel;
  };
  const api = {
    get: (k) => values.get(k) ?? null,
    set: (k, v) => {
      values.set(k, v);
    },
    fire: (k, v) => {
      ensureChannel()?.postMessage({
        key: k,
        source,
        nonce: Math.random(),
        value: v
      });
    },
    remove: (k) => {
      values.delete(k);
    },
    make: (k, ttl) => {
      const bdKey = ttl && `${k}--bd`;
      const remove = () => {
        api.remove(k);
        if (bdKey) api.remove(bdKey);
      };
      return {
        get: () => {
          if (!bdKey) return api.get(k);
          const birthday = Number(api.get(bdKey));
          if (!birthday) api.set(bdKey, String(Date.now()));
          else if (Date.now() - birthday > ttl) remove();
          return api.get(k);
        },
        set: (v) => {
          api.set(k, v);
          if (bdKey) api.set(bdKey, String(Date.now()));
        },
        fire: (v) => api.fire(k, v),
        remove,
        listen: (f) => {
          if (!broadcastName) return;
          const keyListeners = listeners.get(k) ?? /* @__PURE__ */ new Set();
          keyListeners.add(f);
          listeners.set(k, keyListeners);
          ensureChannel();
        }
      };
    },
    boolean: (k) => ({
      get: () => api.get(k) === "1",
      getOrDefault: (defaultValue) => {
        const stored = api.get(k);
        return stored === null ? defaultValue : stored === "1";
      },
      set: (v) => api.set(k, v ? "1" : "0"),
      toggle: () => api.set(k, api.get(k) === "1" ? "0" : "1")
    })
  };
  return api;
}
var storage, tempStorage;
var init_storage = __esm({
  "lila-docker/repos/lila/ui/lib/src/storage.ts"() {
    init_common();
    storage = makeStorage("chesstory-memory-storage");
    tempStorage = makeStorage();
  }
});

// lila-docker/repos/lila/ui/lib/src/index.ts
var init_src = __esm({
  "lila-docker/repos/lila/ui/lib/src/index.ts"() {
    init_async();
    init_richText();
    init_storage();
    init_common();
  }
});

// lila-docker/repos/lila/ui/lib/src/ceval/engines/moveReviewEngineProfiles.ts
function isMoveReviewEngineProfile(value) {
  return value === moveReviewEngineProfile;
}
function moveReviewEngineProfileSpec() {
  return moveReviewEngineManifest;
}
var moveReviewEngineProfile, nnue, moveReviewEngineManifest;
var init_moveReviewEngineProfiles = __esm({
  "lila-docker/repos/lila/ui/lib/src/ceval/engines/moveReviewEngineProfiles.ts"() {
    moveReviewEngineProfile = "sf18-smallnet-t2-h16-v1";
    nnue = "nn-4ca89e4b3abf.nnue";
    moveReviewEngineManifest = {
      profile: moveReviewEngineProfile,
      variants: ["standard"],
      threads: 2,
      hashSize: 16,
      requiredDepth: 16,
      info: {
        id: "__sf18nnuesmall-move-review-t2",
        name: "Stockfish 18 NNUE \xB7 7MB smallnet \xB7 2 threads",
        short: "SF 18 \xB7 7MB \xB7 2t",
        tech: "NNUE",
        minMem: 1536,
        requires: ["sharedMem", "simd", "dynamicImportFromWorker"]
      },
      assets: {
        version: "0.4.2",
        root: "npm/stockfish-web",
        js: "sf_18_smallnet.js",
        wasm: "sf_18_smallnet.wasm",
        nnue: [nnue]
      }
    };
  }
});

// lila-docker/repos/lila/ui/lib/src/ceval/types.ts
var types_exports = {};
__export(types_exports, {
  CevalState: () => CevalState,
  isMoveReviewEngineProfile: () => isMoveReviewEngineProfile,
  isMoveReviewWork: () => isMoveReviewWork,
  makeMoveReviewWork: () => makeMoveReviewWork,
  moveReviewEngineProfile: () => moveReviewEngineProfile
});
function makeMoveReviewWork(profile, input) {
  const spec = moveReviewEngineProfileSpec();
  return {
    ...input,
    threads: spec.threads,
    hashSize: spec.hashSize,
    search: { depth: input.searchLimits.depth },
    threatMode: false,
    gameId: void 0,
    stopRequested: false,
    profile
  };
}
function isMoveReviewWork(work) {
  return !!work && "profile" in work && isMoveReviewEngineProfile(work.profile);
}
var CevalState;
var init_types2 = __esm({
  "lila-docker/repos/lila/ui/lib/src/ceval/types.ts"() {
    init_moveReviewEngineProfiles();
    CevalState = /* @__PURE__ */ ((CevalState2) => {
      CevalState2[CevalState2["Initial"] = 0] = "Initial";
      CevalState2[CevalState2["Loading"] = 1] = "Loading";
      CevalState2[CevalState2["Idle"] = 2] = "Idle";
      CevalState2[CevalState2["Computing"] = 3] = "Computing";
      CevalState2[CevalState2["Failed"] = 4] = "Failed";
      return CevalState2;
    })(CevalState || {});
  }
});

// lila-docker/repos/lila/ui/lib/src/ceval/protocol.ts
var protocol_exports = {};
__export(protocol_exports, {
  Protocol: () => Protocol
});
var Protocol;
var init_protocol = __esm({
  "lila-docker/repos/lila/ui/lib/src/ceval/protocol.ts"() {
    init_src();
    init_types2();
    Protocol = class {
      constructor() {
        this.expectedPvs = 1;
        this.moveReviewPvs = /* @__PURE__ */ new Map();
        this.moveReviewDepth = 0;
        this.moveReviewSeldepth = 0;
        this.moveReviewNodes = 0;
        this.moveReviewMillis = 0;
        this.initialReady = false;
        this.options = /* @__PURE__ */ new Map();
        this.ready = new Promise((resolve2) => this.resolveReady = resolve2);
      }
      connected(send) {
        this.send = send;
        this.moveReviewPreparing = void 0;
        this.initialReady = false;
        this.options.clear();
        this.send("uci");
      }
      setOption(name, value) {
        value = value.toString();
        if (this.send && this.options.get(name) !== value) {
          this.send(`setoption name ${name} value ${value}`);
          this.options.set(name, value);
        }
      }
      disconnected() {
        if (this.work && this.currentEval) {
          this.currentEval.bestmove ??= "(none)";
          this.work.emit(this.currentEval);
        }
        this.work = void 0;
        this.send = void 0;
      }
      received(command) {
        const parts = command.trim().split(/\s+/g);
        if (parts[0] === "uciok") {
          this.setOption("UCI_AnalyseMode", "true");
          this.setOption("Analysis Contempt", "Off");
          this.setOption("UCI_Chess960", "true");
          this.send?.("ucinewgame");
          this.send?.("isready");
        } else if (parts[0] === "readyok") {
          if (this.moveReviewPreparing) this.startMoveReviewWork();
          else {
            this.initialReady = true;
            this.resolveReady?.();
            this.resolveReady = void 0;
            this.swapWork();
          }
        } else if (parts[0] === "id" && parts[1] === "name") this.engineName = parts.slice(2).join(" ");
        else if (parts[0] === "bestmove") {
          const work = this.work;
          this.work = void 0;
          if (work) {
            const ceval = this.currentEval ?? { millis: 0, fen: work.currentFen, depth: 0, nodes: 0, pvs: [] };
            ceval.bestmove = parts[1];
            if (parts[2] === "ponder") ceval.ponder = parts[3];
            work.emit(ceval);
          }
          this.swapWork();
          return;
        } else if (this.work && parts[0] === "info") {
          let depth = 0, seldepth, nodes, multiPv = 1, millis, bound, isMate = false, povEv, moves = [];
          for (let i = 1; i < parts.length; i++) {
            switch (parts[i]) {
              case "depth":
                depth = parseInt(parts[++i]);
                break;
              case "nodes":
                nodes = parseInt(parts[++i]);
                break;
              case "seldepth":
                seldepth = parseInt(parts[++i]);
                break;
              case "multipv":
                multiPv = parseInt(parts[++i]);
                break;
              case "time":
                millis = parseInt(parts[++i]);
                break;
              case "score":
                isMate = parts[++i] === "mate";
                povEv = parseInt(parts[++i]);
                if (parts[i + 1] === "lowerbound" || parts[i + 1] === "upperbound")
                  bound = parts[++i];
                break;
              case "pv":
                moves = parts.slice(++i);
                i = parts.length;
                break;
            }
          }
          if (isMoveReviewWork(this.work) && (defined2(nodes) || defined2(millis)))
            this.work.observe?.(nodes ?? 0, millis ?? 0);
          if (this.work.stopRequested) return;
          if (isMate && !povEv) return;
          if (!isMoveReviewWork(this.work) && this.expectedPvs < multiPv) this.expectedPvs = multiPv;
          if (!defined2(nodes) || !defined2(millis) || !defined2(isMate) || !defined2(povEv)) return;
          const pivot = this.work.threatMode ? 0 : 1;
          const ev = this.work.ply % 2 === pivot ? -povEv : povEv;
          if (bound && multiPv === 1) {
            if (isMoveReviewWork(this.work) && depth >= this.moveReviewDepth) this.moveReviewPvs.clear();
            return;
          }
          const pvData = {
            moves,
            cp: isMate ? void 0 : ev,
            mate: isMate ? ev : void 0,
            depth,
            ...bound ? { bound } : {}
          };
          if (isMoveReviewWork(this.work)) {
            this.acceptMoveReviewPv(multiPv, depth, seldepth, nodes, millis, pvData);
            return;
          }
          if (multiPv === 1) {
            if (depth === (this.currentEval?.depth ?? 0) + 1) {
              this.currentEval = {
                fen: this.work.currentFen,
                depth,
                ...defined2(seldepth) ? { seldepth } : {},
                nodes,
                millis,
                cp: isMate ? void 0 : ev,
                mate: isMate ? ev : void 0,
                pvs: [pvData]
              };
            }
          } else if (this.currentEval) {
            if (this.currentEval.pvs.length < multiPv) this.currentEval.pvs.push(pvData);
            else this.currentEval.pvs[multiPv - 1] = pvData;
            this.currentEval.depth = Math.min(this.currentEval.depth, depth);
          }
          if (multiPv === this.expectedPvs && this.currentEval) {
            this.work.emit(this.currentEval);
          }
        } else if (command && !["Stockfish", "id", "option", "info"].includes(parts[0]) && !["Analysis Contempt", "UCI_Variant", "UCI_AnalyseMode"].includes(command.split(": ")[1]))
          console.warn(`SF: ${command}`);
      }
      stop() {
        if (this.work && !this.work.stopRequested) {
          this.work.stopRequested = true;
          this.send?.("stop");
        }
      }
      swapWork() {
        if (!this.send || this.work || this.moveReviewPreparing) return;
        if (isMoveReviewWork(this.nextWork)) {
          if (!this.initialReady) return;
          this.prepareMoveReviewWork();
          return;
        }
        this.work = this.nextWork;
        this.nextWork = void 0;
        if (this.work) {
          this.currentEval = void 0;
          this.expectedPvs = 1;
          this.setOption("UCI_Variant", this.work.variant);
          this.setOption("UCI_Chess960", "true");
          this.setOption("Threads", this.work.threads);
          this.setOption("Hash", this.work.hashSize || 16);
          this.setOption("MultiPV", Math.max(1, this.work.multiPv));
          if (this.gameId && this.gameId !== this.work.gameId) this.send("ucinewgame");
          this.gameId = this.work.gameId;
          this.send(["position fen", this.work.initialFen, "moves", ...this.work.moves].join(" "));
          const [by, value] = Object.entries(this.work.search)[0];
          this.send(`go ${by} ${value}`);
        }
      }
      prepareMoveReviewWork() {
        if (!this.send || !isMoveReviewWork(this.nextWork)) return;
        const work = this.nextWork;
        this.currentEval = void 0;
        this.expectedPvs = work.multiPv;
        this.moveReviewPvs.clear();
        this.moveReviewDepth = 0;
        this.moveReviewSeldepth = 0;
        this.moveReviewNodes = 0;
        this.moveReviewMillis = 0;
        this.setOption("UCI_Variant", work.variant);
        this.setOption("UCI_Chess960", "false");
        this.setOption("Threads", work.threads);
        this.setOption("Hash", work.hashSize || 16);
        this.setOption("MultiPV", Math.max(1, work.multiPv));
        this.send("setoption name Clear Hash");
        this.send("ucinewgame");
        this.moveReviewPreparing = work;
        this.send("isready");
      }
      acceptMoveReviewPv(multiPv, depth, seldepth, nodes, millis, pv) {
        const work = this.work;
        if (!work || !isMoveReviewWork(work) || !Number.isSafeInteger(multiPv) || multiPv < 1 || multiPv > this.expectedPvs || depth < this.moveReviewDepth)
          return;
        if (depth > this.moveReviewDepth || multiPv === 1) {
          this.moveReviewDepth = depth;
          this.moveReviewPvs.clear();
          this.moveReviewSeldepth = 0;
          this.moveReviewNodes = 0;
          this.moveReviewMillis = 0;
        }
        if (multiPv !== 1 && !this.moveReviewPvs.has(1)) return;
        this.moveReviewPvs.set(multiPv, pv);
        this.moveReviewSeldepth = Math.max(this.moveReviewSeldepth, seldepth ?? 0);
        this.moveReviewNodes = Math.max(this.moveReviewNodes, nodes);
        this.moveReviewMillis = Math.max(this.moveReviewMillis, millis);
        const pvs = Array.from({ length: this.expectedPvs }, (_, index) => this.moveReviewPvs.get(index + 1));
        if (pvs.some((candidate) => candidate === void 0)) return;
        const complete = pvs;
        const primary = complete[0];
        this.currentEval = {
          fen: work.currentFen,
          depth,
          ...this.moveReviewSeldepth ? { seldepth: this.moveReviewSeldepth } : {},
          nodes: this.moveReviewNodes,
          millis: this.moveReviewMillis,
          cp: primary.cp,
          mate: primary.mate,
          pvs: complete
        };
        this.moveReviewPvs.clear();
        work.emit(this.currentEval);
      }
      startMoveReviewWork() {
        const work = this.moveReviewPreparing;
        this.moveReviewPreparing = void 0;
        if (!work || !isMoveReviewWork(work) || !this.send || this.nextWork !== work) {
          this.swapWork();
          return;
        }
        this.work = work;
        this.nextWork = void 0;
        this.send(["position fen", work.initialFen, "moves", ...work.moves].join(" "));
        this.send(
          [
            "go",
            "depth",
            work.searchLimits.depth,
            "nodes",
            work.searchLimits.nodes,
            "movetime",
            work.searchLimits.movetimeMs,
            ...work.rootMoves.length ? ["searchmoves", ...work.rootMoves] : []
          ].join(" ")
        );
      }
      compute(nextWork) {
        this.nextWork = nextWork;
        this.stop();
        this.swapWork();
      }
      isComputing() {
        return !!this.work && !this.work.stopRequested;
      }
    };
  }
});

// lila-docker/repos/lila/ui/lib/src/device.ts
function sharedMemoryTest() {
  if (typeof Atomics !== "object" || typeof SharedArrayBuffer !== "function") return false;
  let mem;
  try {
    mem = new WebAssembly.Memory({ shared: true, initial: 1, maximum: 2 });
    if (!(mem.buffer instanceof SharedArrayBuffer)) return false;
    window.postMessage(mem.buffer, "*");
    return true;
  } catch {
    return false;
  }
}
var colCache, lowerAgent, isMobile, isAndroid, isIos, isIPad, webkitVersion, features, hasMouse;
var init_device = __esm({
  "lila-docker/repos/lila/ui/lib/src/device.ts"() {
    init_src();
    window.addEventListener("resize", () => colCache = void 0);
    lowerAgent = navigator.userAgent.toLowerCase();
    isMobile = () => isAndroid() || isIos();
    isAndroid = memoize(() => lowerAgent.includes("android"));
    isIos = memoize(() => /iphone|ipod/.test(lowerAgent) || isIPad());
    isIPad = () => navigator?.maxTouchPoints > 2 && /ipad|macintosh/.test(lowerAgent);
    webkitVersion = memoize(
      () => lowerAgent.includes("safari") && !lowerAgent.includes("chrome") && !lowerAgent.includes("android") && (lowerAgent.match(/version\/(.*)/)?.[1] || lowerAgent.includes("crios/") && lowerAgent.match(/ os ((?:\d+[._]?){1,3})/i)?.[1]) || false
    );
    features = memoize(() => {
      const features2 = [];
      if (typeof BigInt === "function") features2.push("bigint");
      if (typeof structuredClone !== "undefined") features2.push("structuredClone");
      if (typeof WebAssembly === "object" && typeof WebAssembly.validate === "function" && WebAssembly.validate(Uint8Array.from([0, 97, 115, 109, 1, 0, 0, 0]))) {
        features2.push("wasm");
        const sourceWithSimd = Uint8Array.from([
          0,
          97,
          115,
          109,
          1,
          0,
          0,
          0,
          1,
          12,
          2,
          96,
          2,
          123,
          123,
          1,
          123,
          96,
          1,
          123,
          1,
          123,
          3,
          3,
          2,
          0,
          1,
          7,
          9,
          2,
          1,
          97,
          0,
          0,
          1,
          98,
          0,
          1,
          10,
          19,
          2,
          9,
          0,
          32,
          0,
          32,
          1,
          253,
          186,
          1,
          11,
          7,
          0,
          32,
          0,
          253,
          253,
          1,
          11
        ]);
        if (WebAssembly.validate(sourceWithSimd)) features2.push("simd");
        if (sharedMemoryTest()) features2.push("sharedMem");
      }
      try {
        new Worker(
          URL.createObjectURL(
            new Blob(["import('data:text/javascript,export default {}')"], { type: "application/javascript" })
          )
        ).terminate();
        features2.push("dynamicImportFromWorker");
      } catch {
      }
      return Object.freeze(features2);
    });
    hasMouse = memoize(() => window.matchMedia("(hover: hover) and (pointer: fine)").matches);
  }
});

// lila-docker/repos/lila/ui/lib/src/licon.ts
var init_licon = __esm({
  "lila-docker/repos/lila/ui/lib/src/licon.ts"() {
  }
});

// lila-docker/repos/lila/ui/lib/src/icons.ts
var init_icons = __esm({
  "lila-docker/repos/lila/ui/lib/src/icons.ts"() {
  }
});

// lila-docker/repos/lila/ui/lib/src/view/snabbdom.ts
var init_snabbdom = __esm({
  "lila-docker/repos/lila/ui/lib/src/view/snabbdom.ts"() {
    init_licon();
    init_icons();
  }
});

// lila-docker/repos/lila/ui/lib/src/event.ts
var init_event = __esm({
  "lila-docker/repos/lila/ui/lib/src/event.ts"() {
  }
});

// lila-docker/repos/lila/ui/lib/src/xhr.ts
var init_xhr = __esm({
  "lila-docker/repos/lila/ui/lib/src/xhr.ts"() {
    init_src();
  }
});

// lila-docker/repos/lila/ui/lib/src/pubsub.ts
var Pubsub, pubsub;
var init_pubsub = __esm({
  "lila-docker/repos/lila/ui/lib/src/pubsub.ts"() {
    Pubsub = class {
      constructor() {
        this.allSubs = /* @__PURE__ */ new Map();
        this.oneTimeEvents = /* @__PURE__ */ new Map();
      }
      on(name, cb) {
        const subs = this.allSubs.get(name);
        if (subs) subs.add(cb);
        else this.allSubs.set(name, /* @__PURE__ */ new Set([cb]));
      }
      off(name, cb) {
        this.allSubs.get(name)?.delete(cb);
      }
      emit(name, ...args) {
        const callbacks = this.allSubs.get(name);
        if (callbacks) {
          for (const cb of callbacks) {
            cb(...args);
          }
        }
      }
      after(event) {
        const found = this.oneTimeEvents.get(event);
        if (found) return found.promise;
        const handler = {};
        handler.promise = new Promise((resolve2) => handler.resolve = resolve2);
        this.oneTimeEvents.set(event, handler);
        return handler.promise;
      }
      complete(event, value) {
        const found = this.oneTimeEvents.get(event);
        if (found) {
          found.resolve?.(value);
          found.resolve = void 0;
        } else this.oneTimeEvents.set(event, { promise: Promise.resolve(value) });
      }
      past(event) {
        return this.oneTimeEvents.has(event) && !this.oneTimeEvents.get(event)?.resolve;
      }
    };
    pubsub = new Pubsub();
  }
});

// lila-docker/repos/lila/ui/lib/src/view/dialog.ts
var init_dialog = __esm({
  "lila-docker/repos/lila/ui/lib/src/view/dialog.ts"() {
    init_snabbdom();
    init_device();
    init_src();
    init_event();
    init_xhr();
    init_pubsub();
  }
});

// lila-docker/repos/lila/ui/lib/src/ceval/util.ts
function threatSetup(fen) {
  const setup = parseFen(fen).unwrap();
  setup.turn = opposite(setup.turn);
  setup.epSquare = void 0;
  if (setup.turn === "white") setup.fullmoves += 1;
  return setup;
}
var fewerCores;
var init_util2 = __esm({
  "lila-docker/repos/lila/ui/lib/src/ceval/util.ts"() {
    init_device();
    init_src();
    init_dialog();
    init_fen();
    init_util();
    fewerCores = memoize(
      () => isMobile() || navigator.userAgent.includes("CrOS")
    );
  }
});

// lila-docker/repos/lila/ui/analyse/src/util.ts
function standardUci(beforeFen, value) {
  if (!["e1h1", "e1a1", "e8h8", "e8a8"].includes(value)) return value;
  const position = setupPosition("chess", parseFen(beforeFen).unwrap()).unwrap();
  const move = parseUci(value);
  const side = castlingSide(position, move);
  return side && "from" in move && position.isLegal(move) ? makeUci({ ...move, to: kingCastlesTo(position.turn, side) }) : value;
}
var init_util3 = __esm({
  "lila-docker/repos/lila/ui/analyse/src/util.ts"() {
    init_chess();
    init_fen();
    init_util();
    init_variant();
  }
});

// lila-docker/repos/lila/ui/analyse/src/moveReviewSelection.ts
function responseSearchPrefix(search) {
  return search.prefix_moves_uci ?? [search.root_move];
}
function commentarySearchAnchorPath(observations, rootFen, rootMove, rootOccurrenceId, positionId, prefix) {
  if (!prefix.length || prefix[0] !== rootMove) return;
  const position = observations.positions?.find((position2) => position2.id === positionId);
  return position && observations.paths.find(
    (path) => path.kind !== "history" && path.startFen === rootFen && observations.positions?.some((root) => root.id === path.positionIds?.[0] && root.fen === rootFen) && prefix.every((move, index) => path.moves[index]?.uci === move) && path.occurrenceIds[0] === rootOccurrenceId && path.positionIds?.[prefix.length] === positionId && path.moves[prefix.length - 1]?.fenAfter === position.fen
  );
}
function responseSearchMatchesInquiry(search, inquiry) {
  return responseSearchPrefix(search).length === 1 && search.root_move === inquiry.root_move && search.root_move_occurrence_id === inquiry.root_move_occurrence_id && search.child_position_id === inquiry.child_position_id;
}
function continuationRoutePoolMatches(inquiry, moves, pending = false, referenceMove = inquiry.route_challenge?.reference_move) {
  const route = inquiry.route_challenge;
  if (!route || !referenceMove || !moves.includes(referenceMove)) return false;
  const eligible = route.move_classes.filter(
    (group) => pending ? !group.sampled_work_ids.length : group.moves_uci.every((move) => moves.includes(move))
  );
  const classes = pending && eligible.some((group) => group.kind !== "exposed_capture") ? eligible.filter((group) => group.kind !== "exposed_capture") : eligible;
  return classes.length > 0 && sameIds(moves, [referenceMove, ...classes.flatMap((group) => group.moves_uci)]);
}
function responseSearchMatchesContinuation(search, inquiry) {
  return search.root_move_occurrence_id === inquiry.prefix_occurrence_ids[0] && search.child_position_id === inquiry.position_id && responseSearchPrefix(search).length === inquiry.prefix_moves_uci.length && responseSearchPrefix(search).every((move, index) => move === inquiry.prefix_moves_uci[index]);
}
function reviewedMoverResponsePoolMatches(inquiries, moves, searches, playedMove) {
  const inquiry = inquiries.find((inquiry2) => inquiry2.root_move === playedMove && inquiry2.original_target.square === playedMove.slice(0, 2) && inquiry2.target.square === playedMove.slice(2, 4));
  if (!inquiry) return false;
  const owned = searches?.filter((search) => responseSearchMatchesInquiry(search, inquiry)) ?? [];
  const full = owned.filter((search) => search.root_restriction.kind === "unrestricted").sort((left, right) => Number(right.work_id.slice(5)) - Number(left.work_id.slice(5)))[0];
  if (!full) return moves.length === 2 && sameIds(moves, [inquiry.reference_move, inquiry.alternative_move]);
  const missing = [inquiry.capture_moves, inquiry.decline_moves].filter((family) => !owned.some((search) => (search.root_restriction.kind === "unrestricted" || family.every((move) => search.root_restriction.kind === "restricted" && search.root_restriction.moves_uci.includes(move))) && search.candidates.some((candidate) => family.includes(candidate.move_uci))));
  if (!missing.length)
    return moves.length === 2 && sameIds(moves, [inquiry.reference_move, inquiry.alternative_move]);
  const leader = full.candidates[0]?.move_uci;
  return !!leader && sameIds(moves, [...missing.flat(), leader]);
}
function responsePoolMatchesClasses(inquiries, moves, searches, playedMove) {
  if (!inquiries.length) return false;
  if (playedMove && reviewedMoverResponsePoolMatches(inquiries, moves, searches, playedMove)) return true;
  if (inquiries.some((inquiry) => sameIds(moves, [inquiry.reference_move, inquiry.alternative_move])))
    return true;
  const classes = inquiries.flatMap((inquiry) => [inquiry.capture_moves, inquiry.decline_moves]);
  if (!sameIds(moves, classes.filter((family) => family.every((move) => moves.includes(move))).flat()))
    return false;
  const covers = (search, family) => search.root_restriction.kind === "unrestricted" || family.every(
    (move) => search.root_restriction.kind === "restricted" && search.root_restriction.moves_uci.includes(move)
  );
  if (!searches?.some((search) => covers(search, classes[0].concat(classes[1])))) return true;
  const missing = classes.filter(
    (family) => !searches.some(
      (search) => covers(search, family) && search.candidates.some((candidate) => family.includes(candidate.move_uci))
    )
  );
  return sameIds(moves, missing.flat());
}
function lineContinuationDetail(candidate) {
  return candidate.kind === "conditional_line" && candidate.detail.type === "line_continuation" ? candidate.detail : void 0;
}
function continuationRecoveries(detail, lossId) {
  const ids2 = /* @__PURE__ */ new Set([
    ...detail.capture_links.filter((link) => link.loss_event_id === lossId).map((link) => link.capture_event_id),
    ...detail.other_target_gains.filter((link) => link.loss_event_id === lossId).map((link) => link.gain_event_id)
  ]);
  return detail.events.filter((event) => ids2.has(event.id));
}
function continuationLossIsOpen(path, loss) {
  const summary = path.lineSummary;
  if (!summary?.material || !loss.original_victim) return false;
  const sign = loss.original_victim.side === summary.perspective ? 1 : -1;
  const interval = summary.material.events.filter((event) => event.ply_offset >= loss.ply_offset);
  return interval.length > 0 && interval.every((event) => event.balance_cp * sign < 0);
}
function continuationOpenLossIds(detail, path) {
  return new Set(
    detail.open_loss_event_ids ?? detail.events.filter((event) => continuationLossIsOpen(path, event)).map((event) => event.id)
  );
}
function continuationLossOrigins(detail, lossId) {
  const events = new Map(detail.events.map((event) => [event.id, event]));
  const pending = [lossId], visited = /* @__PURE__ */ new Set();
  while (pending.length) {
    const id2 = pending.pop();
    if (visited.has(id2)) continue;
    visited.add(id2);
    pending.push(
      ...(detail.recovery_losses ?? []).filter((link) => link.later_loss_event_id === id2).map((link) => link.loss_event_id)
    );
  }
  return new Set([...visited].map((id2) => events.get(id2).occurrence_id));
}
function continuationTriggerOrigins(detail, occurrences) {
  return occurrences.flatMap((occurrence) => {
    const event = detail.events.find((event2) => event2.occurrence_id === occurrence);
    return event ? [...continuationLossOrigins(detail, event.id)] : [occurrence];
  });
}
function continuationComparisonDetail(candidate) {
  return candidate.kind === "comparison" && candidate.detail.type === "line_continuation_comparison" ? candidate.detail : void 0;
}
function targetResponseComplete(detail) {
  return detail.branches.every(
    (branch) => branch.providers.state !== "unknown" && branch.recaptures.state !== "unknown" && (!branch.recaptures.moves.length || branch.observed_recapture.state === "complete")
  );
}
function decodeCommentaryEvaluation(value, moveCount) {
  if (!object(value) || !evaluationSource(value.source)) return;
  if (value.kind === "engine_search") {
    if (!exactKeys(value, ["source", "kind", "depth", "white_score"]) || !integer(value.depth, 1, 100) || !object(value.white_score) || !exactKeys(value.white_score, ["kind", "value"]) || !["cp", "mate"].includes(String(value.white_score.kind)) || !integer(value.white_score.value, -2147483648, 2147483647) || value.white_score.kind === "mate" && value.white_score.value === 0)
      return;
    return {
      source: value.source,
      kind: value.kind,
      depth: value.depth,
      white_score: { kind: value.white_score.kind, value: value.white_score.value }
    };
  }
  if (value.kind !== "exact_automatic_terminal" || moveCount !== 1 || !exactKeys(value, ["source", "kind", "terminal"]) || !object(value.terminal))
    return;
  const terminal = value.terminal;
  if (terminal.kind === "checkmate") {
    if (!exactKeys(terminal, ["kind", "winner"]) || !["white", "black"].includes(String(terminal.winner)))
      return;
    return {
      source: value.source,
      kind: value.kind,
      terminal: { kind: "checkmate", winner: terminal.winner }
    };
  }
  if (!exactKeys(terminal, ["kind"]) || !["stalemate", "insufficient_material", "fivefold_repetition", "seventy_five_move_rule"].includes(
    String(terminal.kind)
  ))
    return;
  return {
    source: value.source,
    kind: value.kind,
    terminal: {
      kind: terminal.kind
    }
  };
}
function rankingScore(evaluation, mover) {
  if (evaluation.kind === "exact_automatic_terminal")
    return evaluation.terminal.kind === "checkmate" ? evaluation.terminal.winner === mover ? 101 : -1 : 50;
  const score = evaluation.white_score;
  const white = score.kind === "mate" ? score.value > 0 ? 100 : 0 : 50 + 50 * (2 / (1 + Math.exp(-368208e-8 * score.value)) - 1);
  const mate = score.value * (mover === "white" ? 1 : -1);
  return (mover === "white" ? white : 100 - white) + (score.kind === "mate" ? Math.sign(mate) / Math.max(Math.abs(mate), 1) : 0);
}
function decodeComparisonAnswer(value, observations, context, positionId, referenceMove, alternativeMove, child) {
  if (!context || !isMoveReviewEngineProfile(context.engineProfile)) return;
  const positionFen = child ? observations.positions?.find((position) => position.id === positionId)?.fen : context.rootFen;
  if (!positionFen) return;
  const root = setupPosition("chess", parseFen(positionFen).unwrap()).unwrap();
  const offset = child ? child.prefixMoves?.length ?? 1 : 0;
  const scopeFields = child && child.scopeFields !== false;
  const paths = new Map(observations.paths.map((path) => [path.id, path]));
  const a = value;
  if (!object(a) || !exactKeys(a, [
    "work_id",
    "execution_key_sha256",
    "engine_profile",
    "required_depth",
    "reference_depth",
    "alternative_depth",
    "evaluation_relation",
    "reference_line_id",
    "alternative_line_id",
    "reference_occurrence_id",
    "alternative_occurrence_id",
    "reference_evaluation",
    "alternative_evaluation",
    ...scopeFields ? ["search_position_id", "ply_offset"] : []
  ]) || typeof a.work_id !== "string" || !/^work:[0-9]+$/.test(a.work_id) || typeof a.execution_key_sha256 !== "string" || !/^[a-f0-9]{64}$/.test(a.execution_key_sha256) || a.engine_profile !== context.engineProfile || !integer(a.required_depth, 1, 100) || !id(a.reference_line_id) || !id(a.alternative_line_id) || a.reference_line_id === a.alternative_line_id || scopeFields && (a.search_position_id !== positionId || a.ply_offset !== offset))
    return;
  const left = paths.get(a.reference_line_id), right = paths.get(a.alternative_line_id);
  if (!left || !right || [left, right].some(
    (path) => path.startFen !== context.rootFen || path.positionIds?.[offset] !== positionId || path.kind === "history" || child && (path.moves[0]?.uci !== child.rootMove || path.occurrenceIds[0] !== child.rootOccurrenceId || path.moves[offset - 1]?.fenAfter !== positionFen || child.prefixMoves?.some((move, index) => path.moves[index]?.uci !== move))
  ) || left.moves[offset]?.uci !== referenceMove || right.moves[offset]?.uci !== alternativeMove || a.reference_occurrence_id !== left.occurrenceIds[offset] || a.alternative_occurrence_id !== right.occurrenceIds[offset])
    return;
  const le = decodeCommentaryEvaluation(a.reference_evaluation, left.moves.length - offset);
  const re = decodeCommentaryEvaluation(a.alternative_evaluation, right.moves.length - offset);
  const ownsEvaluation = (path, evaluation) => child ? evaluation.source === "response_comparison" && path.conditionalEvaluations?.some(
    (entry) => entry.searchPositionId === positionId && entry.plyOffset === offset && JSON.stringify(entry.evaluation) === JSON.stringify(evaluation)
  ) : evaluation.source !== "response_comparison" && path.evaluations?.some((entry) => JSON.stringify(entry) === JSON.stringify(evaluation));
  if (!le || !re || le.source !== re.source || le.source === "direct_input" || !ownsEvaluation(left, le) || !ownsEvaluation(right, re))
    return;
  const ld = le.kind === "engine_search" ? le.depth : null;
  const rd = re.kind === "engine_search" ? re.depth : null;
  const requiredDepth = a.required_depth;
  if (a.reference_depth !== ld || a.alternative_depth !== rd || ld !== null && rd !== null && ld !== rd || [le, re].some(
    (e) => e.kind === "engine_search" && (e.depth < requiredDepth || e.white_score.kind !== "mate" && e.depth < 8)
  ))
    return;
  const difference = rankingScore(re, root.turn) - rankingScore(le, root.turn);
  if (a.evaluation_relation !== (difference > 0 ? "better" : difference < 0 ? "worse" : "equal")) return;
  return {
    ...a,
    reference_evaluation: le,
    alternative_evaluation: re
  };
}
function trackedPieces(path, ply) {
  const rootId = path.positionIds?.[0], positionId = path.positionIds?.[ply];
  if (!rootId || !positionId || ply > path.moves.length) return;
  const position = setupPosition("chess", parseFen(path.startFen).unwrap()).unwrap();
  const origins = new Map(
    [...position.board].map(([square, piece]) => [
      square,
      {
        position_id: rootId,
        side: piece.color,
        role: piece.role,
        square: makeSquare(square)
      }
    ])
  );
  for (const entry of path.moves.slice(0, ply)) {
    const move = parseUci(entry.uci);
    if (!move || !("from" in move) || !position.isLegal(move)) return;
    const original = origins.get(move.from), piece = position.board.get(move.from);
    if (!original) return;
    const castle = castlingSide(position, move);
    origins.delete(move.from);
    if (castle) {
      const rookFrom = position.castles.rook[position.turn][castle];
      const rook = rookFrom === void 0 ? void 0 : origins.get(rookFrom);
      if (rookFrom === void 0 || !rook) return;
      origins.delete(rookFrom);
      origins.set(kingCastlesTo(position.turn, castle), original);
      origins.set(rookCastlesTo(position.turn, castle), rook);
    } else {
      if (piece.role === "pawn" && move.to === position.epSquare)
        origins.delete(move.to + (position.turn === "white" ? -8 : 8));
      origins.delete(move.to);
      origins.set(move.to, original);
    }
    position.play(move);
  }
  return [...position.board].map(([square, piece]) => ({
    original: origins.get(square),
    current: {
      position_id: positionId,
      side: piece.color,
      role: piece.role,
      square: makeSquare(square)
    }
  }));
}
function questionFocusFrame(focus, observations) {
  const path = observations.paths.find((path2) => path2.id === focus.line_id);
  const offset = path?.occurrenceIds.indexOf(focus.occurrence_id) ?? -1;
  if (!path || offset < 0 || path.positionIds?.[offset + (focus.phase === "after" ? 1 : 0)] !== focus.position_id) return;
  const highlight = observations.highlights?.find((highlight2) => highlight2.occurrenceId === focus.occurrence_id && highlight2.frames?.some((frame) => frame.phase === focus.phase && frame.positionId === focus.position_id && JSON.stringify(frame.squares) === JSON.stringify(focus.squares) && JSON.stringify(frame.sourceIds) === JSON.stringify(focus.source_ids)));
  if (highlight) return { proofId: path.id, ply: offset + 1, phase: focus.phase, highlightKey: JSON.stringify(highlight) };
  return;
}
function decodeQuestionSummary(value, usedPaths, evidence, summaryText, sources, observations, proposals, playedMove, responseInquiries = [], responseSearches = []) {
  if (!object(value)) return;
  const selectedAnswer = ["observed_exchange", "observed_terminal_comparison", "selected_comparison"].includes(String(value.question));
  const typedAnswer = value.schema_version === 2;
  if (value.question === "current_defense" && !typedAnswer) return;
  const commonAnswer = typedAnswer || selectedAnswer;
  const terminal = (path) => {
    const ending = path.lineSummary?.ending;
    return !!ending && ["checkmate", "stalemate", "insufficient_material", "fivefold_repetition", "seventy_five_move_rule"].includes(ending.kind) && ending.ply_offset === path.moves.length - 1 && ending.occurrence_id === path.occurrenceIds[ending.ply_offset];
  };
  if (!exactKeys(value, ["question", "units", "detail_moves"], ["schema_version", "witness_line_ids", "detail_units", "first_target_response"]) || value.schema_version !== void 0 && value.schema_version !== 2 || ![
    "provider_transfer",
    "support_and_interposition",
    "paired_support_use",
    "escape_or_recapture",
    "capture_now_or_after_attack",
    "attack_or_immediate_exchange",
    "counter_capture_comparison",
    "occupied_pawn_destination",
    "controlled_destination",
    "opening_counterplay",
    "observed_move_order",
    "observed_arrangement_convergence",
    "check_status_comparison",
    "deferred_pawn_attack",
    "contested_pair_response",
    "observed_route_use",
    "selected_target_response",
    "attacker_removal_or_recapture",
    "observed_exchange",
    "observed_terminal_comparison",
    "selected_comparison",
    "current_defense",
    "observed_capture_target",
    "investigated_mechanism",
    "functional_response",
    "first_target_response"
  ].includes(String(value.question)) || !Array.isArray(value.units) || !value.units.length || value.units.length > 8 || value.detail_units !== void 0 && (!Array.isArray(value.detail_units) || value.detail_units.length > 8) || !Array.isArray(value.detail_moves) || value.detail_moves.length > 80 || usedPaths.length !== 2 || usedPaths[0].startFen !== usedPaths[1].startFen || usedPaths[0].positionIds?.[0] !== usedPaths[1].positionIds?.[0] || usedPaths[0].moves[0]?.uci === usedPaths[1].moves[0]?.uci || usedPaths.some((path) => !path.lineSummary?.material || path.lineSummary.ending.kind !== "line_end" && !(commonAnswer && terminal(path)) || !path.lineSummary.premise_ids.every((id2) => evidence.includes(id2)) || !commonAnswer && value.question !== "deferred_pawn_attack" && path.lineSummary.material.events.some((event) => event.promotion_gain_cp) || !sources.some((source) => source.line_id === path.id && (source.stop === null || commonAnswer && terminal(path) && source.stop === "automatic_terminal") && source.accepted_ply_count === path.moves.length))) return;
  if (value.question === "observed_terminal_comparison" && !usedPaths.some(terminal)) return;
  const firstOwner = value.first_target_response;
  if (value.question === "first_target_response" ? !typedAnswer || !object(firstOwner) || !exactKeys(firstOwner, [
    "response_inquiry_id",
    "full_pool_work_id",
    "full_pool_execution_key_sha256",
    "capture_decline_work_id",
    "capture_decline_execution_key_sha256"
  ]) || !["response_inquiry_id", "full_pool_work_id", "capture_decline_work_id"].every((field) => id(firstOwner[field])) || !["full_pool_execution_key_sha256", "capture_decline_execution_key_sha256"].every((field) => typeof firstOwner[field] === "string" && /^[a-f0-9]{64}$/.test(firstOwner[field])) : firstOwner !== void 0) return;
  const firstTarget = value.question === "first_target_response" && typedAnswer && playedMove ? responseInquiries.find((inquiry) => {
    const primary = usedPaths.find((path) => path.moves[0]?.uci === playedMove);
    return primary && object(firstOwner) && inquiry.id === firstOwner.response_inquiry_id && inquiry.state === "answered" && inquiry.stop_reason === null && inquiry.answer && inquiry.root_move === playedMove && inquiry.root_occurrence_id === primary.occurrenceIds[0] && inquiry.root_move_occurrence_id === primary.occurrenceIds[0] && inquiry.child_position_id === primary.positionIds?.[1] && inquiry.original_target.square === playedMove.slice(0, 2) && inquiry.target.square === playedMove.slice(2, 4);
  }) : void 0;
  const firstPair = firstTarget?.answer && object(firstOwner) ? responseSearches.find((search) => responseSearchMatchesInquiry(search, firstTarget) && search.work_id === firstTarget.answer.work_id && search.execution_key_sha256 === firstTarget.answer.execution_key_sha256 && search.work_id === firstOwner.capture_decline_work_id && search.execution_key_sha256 === firstOwner.capture_decline_execution_key_sha256 && search.engine_profile === firstTarget.answer.engine_profile && search.required_depth === firstTarget.answer.required_depth && [firstTarget.answer.reference_line_id, firstTarget.answer.alternative_line_id].every((line) => search.candidates.some((candidate) => candidate.line_id === line))) : void 0;
  const firstPool = firstTarget && firstPair ? [...responseSearches].reverse().filter((search) => responseSearchMatchesInquiry(search, firstTarget) && search.root_restriction.kind === "unrestricted" && search.engine_profile === firstPair.engine_profile && search.required_depth >= firstPair.required_depth).sort((left, right) => right.required_depth - left.required_depth)[0] : void 0;
  const firstLeader = firstPool?.candidates[0];
  const firstReplyPath = firstLeader && firstPair?.candidates.find((candidate) => candidate.move_uci === firstLeader.move_uci);
  if (value.question === "first_target_response") {
    if (!object(firstOwner) || !firstTarget || !firstPool || !firstPair || !firstReplyPath || firstPool.work_id !== firstOwner.full_pool_work_id || firstPool.execution_key_sha256 !== firstOwner.full_pool_execution_key_sha256) return;
    const selection = firstLeader.move_uci === firstTarget.reference_move ? firstTarget.reference_selection : firstLeader.move_uci === firstTarget.alternative_move ? firstTarget.alternative_selection : void 0;
    const selected = selection?.source === "child_search" && responseSearches.find((search) => responseSearchMatchesInquiry(search, firstTarget) && search.work_id === selection.work_id && search.candidates.some((candidate) => candidate.move_uci === firstLeader.move_uci && candidate.line_id === selection.line_id));
    const leaderPath = observations.paths.find((path) => path.id === firstLeader.line_id);
    const pairPath = observations.paths.find((path) => path.id === firstReplyPath.line_id);
    const selectedPath = selected && observations.paths.find((path) => path.id === selection.line_id);
    if (!leaderPath || !pairPath || !selectedPath || leaderPath.moves.length < 2 || ![pairPath, selectedPath].every((path) => path.moves.length >= 2 && [0, 1].every((index) => path.moves[index].uci === leaderPath.moves[index].uci && path.occurrenceIds[index] === leaderPath.occurrenceIds[index] && path.positionIds?.[index + 1] === leaderPath.positionIds?.[index + 1]))) return;
  }
  const conditionalPaths = /* @__PURE__ */ new Set();
  const conditionalDetailIds = new Set(Array.isArray(value.detail_units) ? value.detail_units.filter(object).flatMap((unit) => Array.isArray(unit.proof_moves) ? unit.proof_moves.filter(object).filter((ref) => id(ref.line_id)).map((ref) => ref.line_id) : []) : []);
  if (typedAnswer) {
    const condition = (path, predicate) => {
      const original = predicate.subject, resource = observations.positions?.find((p) => p.id === path.positionIds?.[1]);
      const current = original && trackedPieces(path, 1)?.find((piece) => piece.original.side === original.side && piece.original.role === original.role && piece.original.square === original.square)?.current;
      if (predicate.kind === "location") return current?.square;
      if (predicate.kind === "control" && current && predicate.square && resource?.controls.complete) {
        const row = resource.controls.pieces.find((row2) => row2.piece.side === current.side && row2.piece.role === current.role && row2.piece.square === current.square);
        if (row) return row.squares.includes(predicate.square) ? "present" : "absent";
      }
      return;
    };
    for (const proposal of proposals ?? []) {
      if (proposal.admission !== "generated" || proposal.origin.question.producer !== "C-reply-function") continue;
      const facts = proposal.requirements.filter((reading) => reading.kind === "fact");
      const fact = (id2) => facts.find((reading) => reading.id === id2);
      const root = proposal.requirements.find((reading) => reading.id === "function_root"), context = proposal.requirements.find((reading) => reading.id === "function_context"), live = fact("function_live"), left = fact("function_effect_reference"), right = fact("function_effect_alternative");
      if (root?.kind !== "compare_moves" || root.prefix_moves_uci.length || !playedMove || ![root.reference_move, root.alternative_move].includes(playedMove) || context?.kind !== "fact_group" || context.mode !== "all" || context.state !== "supported" || !context.members.includes("function_live") || context.members.some((id2) => proposal.requirements.find((reading) => reading.id === id2)?.state !== "supported") || !live || live.path.source.kind !== "declared" || live.path.source.moves_uci.length !== 1 || live.path.source.moves_uci[0] !== root.reference_move || live.at.kind !== "ply" || live.at.ply_count !== 1 || !left || !right || left.path.source.kind !== "declared" || right.path.source.kind !== "declared") continue;
      const l = left.path.source.moves_uci, r = right.path.source.moves_uci;
      if (l.length < 2 || l.length !== r.length || l[0] !== root.reference_move || r[0] !== root.alternative_move || !l.slice(1).every((move2, index) => r[index + 1] === move2)) continue;
      const primary = usedPaths.find((path) => path.moves[0]?.uci === root.reference_move), peer = usedPaths.find((path) => path !== primary), peerFact = fact("function_root_alternative");
      if (!primary || !peer || !peerFact || live.expected === void 0 || peerFact.expected === void 0 || JSON.stringify(live.predicate) !== JSON.stringify(peerFact.predicate) || condition(primary, live.predicate) !== live.expected || condition(peer, live.predicate) !== peerFact.expected || live.expected === peerFact.expected) continue;
      for (const reading of facts.filter((fact2) => [
        "function_effect_reference",
        "function_effect_alternative",
        "function_option",
        "function_price"
      ].includes(fact2.id))) {
        if (reading.state !== "supported" || reading.path.source.kind !== "declared") continue;
        const moves = reading.path.source.moves_uci;
        for (const path of observations.paths) if (path.startFen === primary.startFen && path.positionIds?.[0] === primary.positionIds?.[0] && (value.question === "functional_response" || conditionalDetailIds.has(path.id)) && moves.every((move2, index) => path.moves[index]?.uci === move2)) conditionalPaths.add(path.id);
      }
    }
  }
  const summaryPaths = [...usedPaths];
  if (value.witness_line_ids !== void 0) {
    const acceptsWitnesses = value.question === "attacker_removal_or_recapture" || typedAnswer && (["investigated_mechanism", "observed_terminal_comparison", "functional_response"].includes(String(value.question)) || value.question === "first_target_response" && !!firstReplyPath || conditionalPaths.size > 0);
    if (!acceptsWitnesses || !ids(value.witness_line_ids) || // Each delivery layer has its own five-path proof budget. The exact
    // referenced union is checked after admitting the units below.
    !value.witness_line_ids.length || value.witness_line_ids.length > (typedAnswer ? 10 : 5)) return;
    for (const lineId of value.witness_line_ids) {
      const path = observations.paths.find((path2) => path2.id === lineId);
      if (!path || summaryPaths.includes(path) || !path.lineSummary?.material || path.lineSummary.ending.kind !== "line_end" && !(typedAnswer && terminal(path)) || !path.lineSummary.premise_ids.every((id2) => evidence.includes(id2)) || !typedAnswer && path.lineSummary.material.events.some((event) => event.promotion_gain_cp) || !usedPaths.some((primary) => primary.startFen === path.startFen && primary.positionIds?.[0] === path.positionIds?.[0] && (primary.occurrenceIds[0] === path.occurrenceIds[0] && primary.moves[0]?.uci === path.moves[0]?.uci || conditionalPaths.has(path.id)))) return;
      summaryPaths.push(path);
    }
  }
  const move = (raw) => object(raw) && exactKeys(raw, ["line_id", "occurrence_id"]) && id(raw.line_id) && id(raw.occurrence_id) && evidence.includes(raw.occurrence_id) && summaryPaths.some((path) => path.id === raw.line_id && path.occurrenceIds.includes(raw.occurrence_id));
  const parts = (raw) => Array.isArray(raw) && raw.length > 0 && raw.length <= 80 && raw.every((part) => typeof part === "string" ? part.length > 0 && part.length <= 2e3 : move(part));
  const key = (ref) => `${ref.line_id}/${ref.occurrence_id}`;
  const refs = (parts2) => parts2.filter((p) => typeof p !== "string");
  const proofRefs = (unit) => unit.proof_moves ?? refs(unit.en);
  const accountRefs = (unit) => unit.action_moves ?? (unit.proof_moves === void 0 ? refs(unit.en) : [...new Map([...proofRefs(unit), ...refs(unit.en)].map((ref) => [key(ref), ref])).values()]);
  const signature = (moves) => moves.map(key).sort().join("|");
  if (!value.detail_moves.every(move) || new Set(value.detail_moves.map(key)).size !== value.detail_moves.length) return;
  for (const unit of [...value.units, ...value.detail_units ?? []]) {
    if (!object(unit) || !exactKeys(unit, ["role", "en", "ko", "covered_moves"], ["proof_moves", "action_moves", "required_moves", "recorded_end_moves", "focus", "english_only"]) || !["condition", "reply", "cost"].includes(String(unit.role)) || !parts(unit.en) || !parts(unit.ko) || !Array.isArray(unit.covered_moves) || unit.covered_moves.length > 80 || !unit.covered_moves.every(move) || signature(refs(unit.en)) !== signature(refs(unit.ko)) || !refs(unit.en).length || new Set(unit.covered_moves.map(key)).size !== unit.covered_moves.length || unit.role === "cost" !== unit.covered_moves.length > 0 || unit.english_only !== void 0 && (unit.english_only !== true || JSON.stringify(unit.en) !== JSON.stringify(unit.ko))) return;
    if (unit.proof_moves !== void 0 && (!Array.isArray(unit.proof_moves) || !unit.proof_moves.length || unit.proof_moves.length > summaryPaths.reduce((size, path) => size + path.occurrenceIds.length, 0) || !unit.proof_moves.every(move) || new Set(unit.proof_moves.map(key)).size !== unit.proof_moves.length)) return;
    const proof = unit.proof_moves;
    const owned = new Set((proof ?? refs(unit.en)).map(key));
    if (unit.action_moves !== void 0 && (!typedAnswer || !proof || !Array.isArray(unit.action_moves) || unit.action_moves.length > proof.length || !unit.action_moves.every(move) || new Set(unit.action_moves.map(key)).size !== unit.action_moves.length || unit.action_moves.some((ref) => !owned.has(key(ref))) || unit.covered_moves.some((ref) => !unit.action_moves.some((other) => key(other) === key(ref))))) return;
    if (proof && (refs(unit.en).some((ref) => !owned.has(key(ref)) && (!proof.some((other) => other.line_id === ref.line_id) || summaryPaths.find((path) => path.id === ref.line_id).occurrenceIds[0] !== ref.occurrence_id)) || unit.covered_moves.some((ref) => !owned.has(key(ref))))) return;
    if (unit.required_moves !== void 0 && (!Array.isArray(unit.required_moves) || unit.required_moves.length > 80 || !unit.required_moves.every(move) || new Set(unit.required_moves.map(key)).size !== unit.required_moves.length || unit.required_moves.some((ref) => !owned.has(key(ref))))) return;
    if (unit.recorded_end_moves !== void 0 && (!Array.isArray(unit.recorded_end_moves) || unit.recorded_end_moves.length > 80 || !unit.recorded_end_moves.every(move) || new Set(unit.recorded_end_moves.map(key)).size !== unit.recorded_end_moves.length || unit.recorded_end_moves.some((ref) => {
      const path = summaryPaths.find((path2) => path2.id === ref.line_id), ending = path.lineSummary.ending;
      return !owned.has(key(ref)) || ending.kind !== "line_end" || ending.ply_offset !== path.moves.length - 1 || ending.occurrence_id !== ref.occurrence_id || path.occurrenceIds[path.moves.length - 1] !== ref.occurrence_id;
    }))) return;
    if (unit.focus !== void 0) {
      if (!Array.isArray(unit.focus) || unit.focus.length > 80) return;
      const assigned = /* @__PURE__ */ new Set();
      for (const focus of unit.focus) {
        if (!object(focus) || !exactKeys(focus, ["line_id", "occurrence_id", "phase", "position_id", "squares", "source_ids"]) || !move({ line_id: focus.line_id, occurrence_id: focus.occurrence_id }) || !["before", "after"].includes(String(focus.phase)) || !id(focus.position_id) || !ids(focus.squares) || !focus.squares.length || focus.squares.length > 64 || !focus.squares.every((square) => /^[a-h][1-8]$/.test(square)) || !ids(focus.source_ids)) return;
        const ref = focus;
        if (!owned.has(key(ref)) || assigned.has(key(ref)) || !questionFocusFrame(ref, observations)) return;
        assigned.add(key(ref));
      }
    }
  }
  const result = value, mentioned = result.units.flatMap(accountRefs);
  const witnessIds = (units, extra = []) => new Set(
    [...units.flatMap((unit) => [
      ...proofRefs(unit),
      ...refs(unit.en),
      ...refs(unit.ko),
      ...unit.covered_moves,
      ...unit.required_moves ?? [],
      ...unit.recorded_end_moves ?? [],
      ...unit.focus ?? []
    ]), ...extra].map((ref) => ref.line_id).filter((lineId) => !usedPaths.some((path) => path.id === lineId))
  );
  const coreWitnesses = witnessIds(result.units), detailWitnesses = witnessIds(result.detail_units ?? [], result.detail_moves), referencedWitnesses = /* @__PURE__ */ new Set([...coreWitnesses, ...detailWitnesses]);
  if (coreWitnesses.size > 5 || detailWitnesses.size > 5 || !sameIds(result.witness_line_ids ?? [], [...referencedWitnesses])) return;
  const text2 = result.units.map((unit) => unit.en.map((part) => typeof part === "string" ? part : (() => {
    const path = summaryPaths.find((path2) => path2.id === part.line_id);
    return path.moves[path.occurrenceIds.indexOf(part.occurrence_id)].label;
  })()).join("")).join(" ");
  if (text2 !== summaryText || text2.length > 4e3 || usedPaths.some((path) => !result.units.flatMap((unit) => refs(unit.en)).some((ref) => ref.line_id === path.id && ref.occurrence_id === path.occurrenceIds[0]))) return;
  const delivered = (units, extra = []) => {
    const mentioned2 = [...units.flatMap(accountRefs), ...extra], recordedEnds = new Set(units.flatMap((unit) => unit.recorded_end_moves ?? []).map(key));
    if (units.some((unit) => unit.covered_moves.some((ref) => !proofRefs(unit).some((other) => key(ref) === key(other))))) return false;
    for (const path of summaryPaths) {
      const visible = mentioned2.filter((ref) => ref.line_id === path.id), covered = [...new Map(units.flatMap((unit) => unit.covered_moves).filter((ref) => ref.line_id === path.id).map((ref) => [key(ref), ref])).values()], material = path.lineSummary.material.events, has = (offset) => visible.some((ref) => ref.occurrence_id === path.occurrenceIds[offset]);
      if (covered.some((ref) => !visible.some((other) => key(other) === key(ref)) || !material.some((event) => event.capture && event.occurrence_id === ref.occurrence_id))) return false;
      for (const ref of visible) {
        const offset = path.occurrenceIds.indexOf(ref.occurrence_id), capture = material.find((event) => event.ply_offset === offset && event.capture), previous = material.find((event) => event.ply_offset === offset - 1 && event.capture), next = material.find((event) => event.ply_offset === offset + 1 && event.capture), ended = commonAnswer && terminal(path) && offset === path.lineSummary.ending.ply_offset;
        if (capture && !covered.some((other) => key(other) === key(ref))) return false;
        if (!ended && !recordedEnds.has(key(ref)) && !has(offset + 1) && setupPosition("chess", parseFen(path.moves[offset].fenAfter).unwrap()).unwrap().isCheck()) return false;
        if (capture?.capture?.recapture === "proven" && previous && previous.side !== capture.side && capture.capture.square === path.moves[offset - 1]?.uci.slice(2, 4) && !has(offset - 1)) return false;
        if (capture && next?.capture?.recapture === "proven" && next.side !== capture.side && next.capture.square === path.moves[offset].uci.slice(2, 4) && !has(offset + 1)) return false;
      }
    }
    return true;
  };
  if (value.question === "first_target_response") {
    const observed = observations.paths.find((path) => path.id === firstReplyPath.line_id);
    const core = result.units.flatMap(accountRefs);
    if (!observed || observed.moves.length < 3 || !summaryPaths.some((path) => path.moves.length >= 3 && path.moves.slice(0, 3).every((move2, index) => move2.uci === observed.moves[index]?.uci && path.occurrenceIds[index] === observed.occurrenceIds[index] && path.positionIds?.[index + 1] === observed.positionIds?.[index + 1]) && [1, 2].every((offset) => core.some((ref) => ref.line_id === path.id && ref.occurrence_id === path.occurrenceIds[offset])))) return;
  }
  if (result.detail_units && !delivered(result.detail_units, typedAnswer ? result.detail_moves : [])) return;
  if (commonAnswer || result.question === "selected_target_response" || result.question === "attacker_removal_or_recapture") {
    const roots = [];
    if (typedAnswer) for (const path of usedPaths) {
      const occurrence = path.occurrenceIds[0];
      if (!id(occurrence)) return;
      roots.push({ line_id: path.id, occurrence_id: occurrence });
    }
    const witnessed = typedAnswer ? result.units.flatMap(proofRefs) : mentioned;
    const conditionalDetail = typedAnswer ? (result.detail_units ?? []).flatMap(proofRefs) : [];
    if (!commonAnswer && result.detail_moves.length || !delivered(result.units, roots) || summaryPaths.some((path) => !witnessed.some((ref) => ref.line_id === path.id) && !(typedAnswer && conditionalDetail.some((ref) => ref.line_id === path.id)))) return;
    return result;
  }
  const alignment = ["observed_move_order", "observed_arrangement_convergence", "observed_route_use"].includes(result.question);
  const ends = /* @__PURE__ */ new Map();
  for (const path of usedPaths) {
    const core = mentioned.filter((ref) => ref.line_id === path.id), covered = result.units.flatMap((unit) => unit.covered_moves).filter((ref) => ref.line_id === path.id), detail = result.detail_moves.filter((ref) => ref.line_id === path.id), all = [...core, ...covered, ...alignment ? detail : []], end = Math.max(...all.map((ref) => path.occurrenceIds.indexOf(ref.occurrence_id))), materialEvents = path.lineSummary.material.events, captures = materialEvents.filter((event) => event.capture && (result.question === "occupied_pawn_destination" || event.ply_offset <= end));
    ends.set(path.id, end);
    if (alignment && (detail.length !== end + 1 || path.occurrenceIds.slice(0, end + 1).some((id2) => !detail.some((ref) => ref.occurrence_id === id2)))) return;
    const materialQuestion = [
      "paired_support_use",
      "escape_or_recapture",
      "capture_now_or_after_attack",
      "attack_or_immediate_exchange",
      "counter_capture_comparison",
      "occupied_pawn_destination",
      "opening_counterplay",
      "check_status_comparison",
      "deferred_pawn_attack",
      "contested_pair_response",
      "observed_route_use"
    ].includes(result.question);
    for (let offset = 0; offset <= end; offset++) {
      if (!/[+#]$/.test(path.moves[offset].label)) continue;
      const matches = (ref, index) => ref.line_id === path.id && ref.occurrence_id === path.occurrenceIds[index];
      const answeredInUnit = ["escape_or_recapture", "opening_counterplay", "check_status_comparison", "deferred_pawn_attack", "contested_pair_response"].includes(result.question) && result.units.some((unit) => [offset, offset + 1].every((index) => accountRefs(unit).some((ref) => matches(ref, index))));
      const neutralCheck = result.question === "check_status_comparison" && captures.some((first) => first.ply_offset === offset && captures.some((second) => second.ply_offset === offset + 1 && second.side !== first.side && second.capture.role === first.capture.role && second.capture.recapture === "proven"));
      const pairedInDetail = (result.question === "counter_capture_comparison" || neutralCheck) && [offset, offset + 1].every((index) => result.detail_moves.some((ref) => matches(ref, index)) && !core.some((ref) => matches(ref, index)) && (neutralCheck || !captures.some((event) => event.ply_offset === index)));
      if (!answeredInUnit && !pairedInDetail) return;
    }
    if (materialQuestion) {
      if (result.question === "counter_capture_comparison" && captures.length) {
        const first = captures[0], captor = trackedPieces(path, first.ply_offset)?.find((piece) => piece.current.square === path.moves[first.ply_offset].uci.slice(0, 2))?.original;
        if (!captor || materialEvents.some((event) => event.capture && event.ply_offset > end && trackedPieces(path, event.ply_offset)?.some((piece) => piece.current.square === event.capture.square && samePiece(piece.original, captor)))) return;
      }
      const lastCapture = captures.find((event) => event.ply_offset === end), nextCapture = path.lineSummary.material.events.find((event) => event.ply_offset === end + 1 && event.capture);
      if (lastCapture && nextCapture?.capture?.recapture === "proven" && nextCapture.side !== lastCapture.side && nextCapture.capture.square === path.moves[end].uci.slice(2, 4)) return;
      if (new Set(covered.map(key)).size !== covered.length || captures.length !== covered.length || captures.some((event) => !covered.some((ref) => ref.occurrence_id === event.occurrence_id)) || covered.some((ref) => !core.concat(result.detail_moves).some((other) => key(other) === key(ref)))) return;
    } else if (covered.length || captures.length) return;
    if (result.question === "paired_support_use") {
      if (!covered.length) return;
      const balance = /* @__PURE__ */ new Map();
      for (const event of captures) balance.set(
        event.capture.role,
        (balance.get(event.capture.role) ?? 0) + (event.side === "white" ? 1 : -1)
      );
      if ([...balance.values()].some((value2) => value2 !== 0)) return;
    }
  }
  if (result.question === "observed_route_use") {
    const states = usedPaths.map((path) => Array.from({ length: path.moves.length + 1 }, (_, count) => trackedPieces(path, count))), roots = usedPaths.map((path, n) => states[n][0]?.find((p) => p.current.square === path.moves[0].uci.slice(0, 2))?.original);
    const validRoute = roots.some((focus) => focus && (() => {
      const routes = usedPaths.map((path, n) => path.moves.flatMap((move2, offset) => {
        const before = states[n][offset]?.find((p) => samePiece(p.original, focus)), after = states[n][offset + 1]?.find((p) => samePiece(p.original, focus));
        return before && after && before.current.square !== after.current.square ? [{ offset, square: after.current.square, uci: move2.uci }] : [];
      }));
      const meetings = routes[0].flatMap((left) => routes[1].filter((right) => left.square === right.square).map((right) => [left.offset, right.offset])), first = meetings.filter((pair) => !meetings.some((other) => other[0] <= pair[0] && other[1] <= pair[1] && (other[0] < pair[0] || other[1] < pair[1])));
      if (first.length !== 1) return false;
      const arrivals = first[0], prefixes = routes.map((route, n) => route.filter((step) => step.offset <= arrivals[n]));
      if (prefixes[0].map((s) => s.uci).join(" ") === prefixes[1].map((s) => s.uci).join(" ")) return false;
      const exchanged = usedPaths.map((path, n) => {
        const events = path.lineSummary.material.events, arrival = arrivals[n], gain = events.find((e) => e.ply_offset === arrival && e.capture), loss = events.find((e) => e.ply_offset === arrival + 1 && e.capture?.recapture === "proven");
        if (!gain?.capture || !loss?.capture || gain.side !== focus.side || gain.capture.role !== focus.role) return;
        const taken = states[n][arrival]?.find((p) => p.current.square === gain.capture.square)?.original, removed = states[n][arrival + 1]?.find((p) => p.current.square === loss.capture.square)?.original;
        return taken && removed && samePiece(removed, focus) ? taken : void 0;
      });
      const sameExchange = roots.every((root) => root && samePiece(root, focus)) && exchanged.every(Boolean) && samePiece(exchanged[0], exchanged[1]);
      const mover = (n, offset) => states[n][offset]?.find((p) => p.current.square === usedPaths[n].moves[offset]?.uci.slice(0, 2))?.original, control = (n, count, actor, target) => continuationSupportAt(observations, usedPaths[n], actor, target, count, states[n][count]).state;
      const notPinned = (n, count, piece = focus) => {
        const resource = observations.positions?.find((p) => p.id === usedPaths[n].positionIds[count]), current = states[n][count]?.find((p) => samePiece(p.original, piece))?.current;
        return !!current && !!resource?.rays.complete && !resource.rays.lines.some((ray2) => ray2.piece.side !== current.side && ray2.occupants[0]?.square === current.square && ray2.occupants[1]?.role === "king" && ray2.occupants[1].side === current.side);
      };
      const subjects = [];
      const own = (piece) => {
        if (piece && !subjects.some((p) => samePiece(p, piece))) subjects.push(piece);
      };
      roots.forEach(own);
      for (const [n, path] of usedPaths.entries()) {
        for (const { offset } of prefixes[n]) {
          const prior = mover(n, offset - 1), reply = mover(n, offset + 1);
          if (prior && prior.side !== focus.side && control(n, offset - 1, prior, focus) === "absent" && control(n, offset, prior, focus) === "present" && control(n, offset + 1, prior, focus) === "absent") own(prior);
          if (reply && reply.side !== focus.side && control(n, offset, focus, reply) === "absent" && control(n, offset + 1, focus, reply) === "present" && notPinned(n, offset + 1) && control(n, offset + 2, focus, reply) === "absent") own(reply);
        }
        const targets = (states[n][0] ?? []).map((p) => p.original).filter((p) => p.side !== focus.side && control(n, arrivals[n], focus, p) === "absent" && control(n, arrivals[n] + 1, focus, p) === "present" && notPinned(n, arrivals[n] + 1));
        if (targets.every((p) => p.role === "pawn")) targets.forEach(own);
        const next = routes[n].find((step) => step.offset > arrivals[n]), gain = path.lineSummary.material.events.find((e) => e.capture && e.ply_offset === next?.offset), taken = gain && states[n][gain.ply_offset]?.find((p) => p.current.square === gain.capture.square)?.original;
        if (taken && Array.from({ length: gain.ply_offset - arrivals[n] }, (_, i) => arrivals[n] + i + 1).every((count) => control(n, count, focus, taken) === "present" && notPinned(n, count))) own(taken);
      }
      return usedPaths.every((path, n) => {
        const visible = (offset) => mentioned.some((ref) => ref.line_id === path.id && ref.occurrence_id === path.occurrenceIds[offset]), captures = path.lineSummary.material.events.filter((event) => event.capture && event.ply_offset <= ends.get(path.id)), together = (...offsets) => result.units.some((unit) => offsets.every((offset) => accountRefs(unit).some((ref) => ref.line_id === path.id && ref.occurrence_id === path.occurrenceIds[offset]))), actor = (offset) => mover(n, offset), contact = (count, actor2, target2) => control(n, count, actor2, target2);
        const unpinned = (count) => notPinned(n, count);
        const interactionsKept = prefixes[n].every(({ offset }) => {
          if (!visible(offset)) return false;
          const prior = actor(offset - 1), reply = actor(offset + 1);
          if (prior && prior.side !== focus.side && contact(offset - 1, prior, focus) === "absent" && contact(offset, prior, focus) === "present" && contact(offset + 1, prior, focus) === "absent" && !together(offset - 1, offset)) return false;
          if (reply && reply.side !== focus.side && contact(offset, focus, reply) === "absent" && contact(offset + 1, focus, reply) === "present" && unpinned(offset + 1) && contact(offset + 2, focus, reply) === "absent" && !together(offset, offset + 1)) return false;
          return true;
        });
        const victim = (event) => states[n][event.ply_offset]?.find((p) => p.current.square === event.capture.square)?.original, stationary = (piece, from, through) => {
          const square = states[n][from]?.find((p) => samePiece(p.original, piece))?.current.square;
          return !!square && states[n].slice(from, through + 1).every((state) => state?.find((p) => samePiece(p.original, piece))?.current.square === square);
        }, laterLoss = path.lineSummary.material.events.find((event) => event.capture && event.ply_offset > arrivals[n] && victim(event) && samePiece(victim(event), focus) && stationary(focus, arrivals[n] + 1, event.ply_offset));
        if (laterLoss && laterLoss.ply_offset > ends.get(path.id)) return false;
        const groups = [];
        for (const event of captures) {
          const taken = victim(event), prior = groups.find((group) => {
            const last = group[group.length - 1], mover2 = actor(last.ply_offset);
            return taken && mover2 && samePiece(taken, mover2) && stationary(mover2, last.ply_offset + 1, event.ply_offset);
          });
          if (prior) prior.push(event);
          else groups.push([event]);
        }
        const independent = (group) => {
          if (group.length !== 2 || group.some((e) => visible(e.ply_offset)) || group[1].ply_offset !== group[0].ply_offset + 1 || group[0].side === group[1].side || group[0].capture.role !== group[1].capture.role || group[1].capture.recapture !== "proven" || usedPaths.some((p) => p.positionIds?.some((id2) => {
            const resource = observations.positions?.find((position) => position.id === id2);
            return !resource?.controls.complete || !resource.rays.complete;
          }))) return false;
          const pieces = (events) => events.flatMap((e) => [actor(e.ply_offset), victim(e)]).filter((p) => !!p), participants = pieces(group), owned = subjects.concat(pieces(path.lineSummary.material.events.filter((e) => e.capture && e.ply_offset >= group[0].ply_offset && !group.includes(e))));
          if (participants.length !== 4 || participants.some((p) => owned.some((q) => samePiece(p, q)))) return false;
          const squares = new Set(prefixes[n].flatMap(({ offset }) => {
            const from = states[n][offset]?.find((p) => samePiece(p.original, focus))?.current, to = states[n][offset + 1]?.find((p) => samePiece(p.original, focus))?.current.square, resource = observations.positions?.find((p) => p.id === path.positionIds[offset]);
            if (!from || !to || !resource) return [];
            return [from.square, to, ...resource.rays.lines.filter((ray2) => ray2.piece.square === from.square && ray2.piece.side === from.side && ray2.piece.role === from.role && ray2.squares.includes(to)).flatMap((ray2) => ray2.squares.slice(0, ray2.squares.indexOf(to)))];
          }));
          for (let count = group[0].ply_offset; count <= group[1].ply_offset + 1; count++) {
            const resource = observations.positions.find((p) => p.id === path.positionIds[count]), current = (piece) => states[n][count]?.find((p) => samePiece(p.original, piece))?.current;
            for (const p of participants) {
              const piece = current(p);
              if (!piece) continue;
              const controls = resource.controls.pieces.find((row) => row.piece.square === piece.square && row.piece.side === piece.side && row.piece.role === piece.role);
              if (squares.has(piece.square) || controls?.squares.some((square) => squares.has(square)) || owned.some((q) => current(q) && (contact(count, p, q) !== "absent" || contact(count, q, p) !== "absent"))) return false;
            }
            if (count <= group[1].ply_offset && owned.some((p) => owned.some((q) => !samePiece(p, q) && current(p) && current(q) && (contact(count, p, q) !== contact(count + 1, p, q) || notPinned(n, count, p) !== notPinned(n, count + 1, p))))) return false;
          }
          return true;
        };
        const chained = groups.every((group) => group.length >= 2 && (together(...group.map((event) => event.ply_offset)) || independent(group)));
        const next = prefixes[n].find((step) => step.offset > 0), use = captures.find((event) => event.ply_offset === next?.offset && event.capture.role === "pawn"), target = use && states[n][use.ply_offset]?.find((p) => p.current.square === use.capture.square)?.original, balance = /* @__PURE__ */ new Map();
        for (const event of captures) balance.set(
          event.capture.role,
          (balance.get(event.capture.role) ?? 0) + (event.side === focus.side ? 1 : -1)
        );
        const compound = sameExchange && !!use && !!target && contact(0, focus, target) === "absent" && Array.from({ length: use.ply_offset }, (_, i) => i + 1).every((count) => contact(count, focus, target) === "present" && unpinned(count)) && [...balance.values()].every((n2) => n2 === 0) && ends.get(path.id) <= arrivals[n] + 2 && together(...captures.map((event) => event.ply_offset)) && captures.every((event) => [arrivals[n], arrivals[n] + 1].includes(event.ply_offset) || event.capture.role === "pawn" && (event.ply_offset < arrivals[n] ? [focus, exchanged[n]].some((p) => {
          const mover2 = actor(event.ply_offset);
          return mover2 && samePiece(mover2, p);
        }) : event.ply_offset === arrivals[n] + 2 && event.side === focus.side));
        return arrivals[n] <= ends.get(path.id) && interactionsKept && (arrivals[n] === ends.get(path.id) || visible(arrivals[n] + 1)) && (chained || compound);
      });
    })());
    if (!validRoute) return;
  }
  if (result.question === "contested_pair_response") {
    const costs = result.units.filter((unit) => unit.role === "cost");
    if (!costs.length || costs.some((unit) => {
      if (unit.covered_moves.some((move2) => !proofRefs(unit).some((ref) => key(ref) === key(move2)))) return true;
      return usedPaths.some((path) => {
        const moves = unit.covered_moves.filter((ref) => ref.line_id === path.id);
        if (!moves.length) return false;
        if (moves.length !== 2) return true;
        const start = path.occurrenceIds.indexOf(moves[0].occurrence_id), end = path.occurrenceIds.indexOf(moves[1].occurrence_id);
        return end !== start + 1 || !path.lineSummary.material.events.some((event) => event.ply_offset === end && event.capture?.recapture === "proven");
      });
    })) return;
  }
  if (result.question === "deferred_pawn_attack") {
    const promotions = usedPaths.flatMap((path2) => path2.lineSummary.material.events.filter((event2) => event2.promotion_gain_cp).map((event2) => ({ path: path2, event: event2 })));
    if (promotions.length !== 1) return;
    const { path, event } = promotions[0], at = event.ply_offset, removal = path.lineSummary.material.events.find((row) => row.ply_offset === at + 1), actor = trackedPieces(path, at)?.find((piece) => piece.current.square === event.from), promoted = actor && trackedPieces(path, at + 1)?.find((piece) => samePiece(piece.original, actor.original)), remaining = trackedPieces(path, at + 2), peer = usedPaths.find((other) => other !== path), peerRoot = trackedPieces(peer, 0)?.find((piece) => piece.current.square === peer.moves[0].uci.slice(0, 2));
    const names = (ref, index) => ref.line_id === path.id && ref.occurrence_id === path.occurrenceIds[index];
    if (!actor || actor.original.role !== "pawn" || !promoted || promoted.current.role !== event.after_role || !remaining || remaining.some((piece) => samePiece(piece.original, actor.original)) || !peerRoot || !samePiece(peerRoot.original, actor.original) || !event.capture || event.before_role !== "pawn" || !removal?.capture || removal.capture.role !== event.after_role || removal.capture.recapture !== "proven" || !result.units.some((unit) => [at, at + 1].every((index) => accountRefs(unit).some((ref) => names(ref, index)) && unit.covered_moves.some((ref) => names(ref, index))))) return;
    const next = path.lineSummary.material.events.find((row) => row.ply_offset === at + 2 && row.capture);
    const through = next ? at + 2 : at + 1;
    if (path.lineSummary.material.events.filter((row) => row.capture && row.ply_offset <= through).some((row) => !mentioned.some((ref) => names(ref, row.ply_offset)) || !result.units.some((unit) => unit.covered_moves.some((ref) => names(ref, row.ply_offset))))) return;
    const captures = peer.lineSummary.material.events.filter((row) => row.capture), balance = /* @__PURE__ */ new Map();
    for (const row of captures) balance.set(row.capture.role, (balance.get(row.capture.role) ?? 0) + (row.side === "white" ? 1 : -1));
    if ([...balance.values()].some((count) => count !== 0) || captures.some((row) => !result.units.some((unit) => unit.covered_moves.some((ref) => ref.line_id === peer.id && ref.occurrence_id === row.occurrence_id)))) return;
  }
  if (result.question === "observed_arrangement_convergence") {
    const end = usedPaths.map((path) => ends.get(path.id)), boards = usedPaths.map((path) => path.moves.map((move2) => move2.fenAfter.split(" ").slice(0, 4).join(" "))), meetings = boards[0].flatMap((board, i) => boards[1].flatMap((other, j) => board === other ? [[i, j]] : []));
    const order = (a, b) => Math.max(...a) - Math.max(...b) || a[0] + a[1] - b[0] - b[1];
    const first = meetings.sort(order)[0];
    if (!first || order(first, end) !== 0 || meetings.filter((pair) => order(pair, first) === 0).length !== 1) return;
    if (usedPaths.some((path, n) => !mentioned.some((ref) => ref.line_id === path.id && ref.occurrence_id === path.occurrenceIds[end[n]])) || boards[0][end[0]] !== boards[1][end[1]]) return;
  }
  if (result.question === "observed_move_order") {
    for (const [n, path] of usedPaths.entries()) {
      const peer = usedPaths[1 - n], end = ends.get(path.id), other = path.moves.findIndex((move2, index) => index > 0 && move2.uci === peer.moves[0].uci), remaining = trackedPieces(path, end + 1);
      if (other < 1 || end !== other + 1 || !remaining || !mentioned.some((ref) => ref.line_id === path.id && ref.occurrence_id === path.occurrenceIds[other]) || !mentioned.some((ref) => ref.line_id === path.id && path.occurrenceIds.indexOf(ref.occurrence_id) % 2 === 1)) return;
      for (const root of usedPaths) {
        const actor = trackedPieces(root, 1)?.find((piece) => piece.original.square === root.moves[0].uci.slice(0, 2));
        const held = actor && remaining.find((piece) => samePiece(piece.original, actor.original));
        if (!actor || !held || actor.current.square !== held.current.square || actor.current.role !== held.current.role) return;
      }
    }
  }
  return result;
}
function decodeExchangeSummary(value, usedPaths, evidence) {
  if (!object(value) || !exactKeys(value, [
    "line_id",
    "retained_line_id",
    "role",
    "recapturer_role",
    "exchange_occurrence_ids",
    "retention_occurrence_ids"
  ]) || !id(value.line_id) || !id(value.retained_line_id) || value.line_id === value.retained_line_id || !["knight", "bishop", "rook", "queen"].includes(String(value.role)) || !ids(value.exchange_occurrence_ids) || !ids(value.retention_occurrence_ids)) return;
  const exchange = usedPaths.find((path) => path.id === value.line_id), retained = usedPaths.find((path) => path.id === value.retained_line_id);
  const neutral = (path) => {
    const summary = path.lineSummary, material = summary?.material;
    if (!material || summary?.ending.kind !== "line_end" || path.moves.length < 3 || !summary.premise_ids.every((id2) => evidence.includes(id2)) || material.events.some((event) => event.promotion_gain_cp)) return false;
    const captures2 = material.events.filter((event) => event.capture);
    return captures2.every((event, index) => index % 2 === 1 || !!captures2[index + 1] && captures2[index + 1].ply_offset === event.ply_offset + 1 && captures2[index + 1].side !== event.side && captures2[index + 1].capture.role === event.capture.role && captures2[index + 1].capture.recapture === "proven");
  };
  if (usedPaths.length !== 2 || !exchange || !retained || !neutral(exchange) || !neutral(retained) || exchange.startFen !== retained.startFen || exchange.positionIds?.[0] !== retained.positionIds?.[0] || exchange.moves[0].uci === retained.moves[0].uci || exchange.moves[0].uci.slice(0, 2) !== retained.moves[0].uci.slice(0, 2) || /[+#]$/.test(exchange.moves[2].label) || value.exchange_occurrence_ids.length !== 3 || value.retention_occurrence_ids.length !== 2 || !value.exchange_occurrence_ids.every((id2, index) => id2 === exchange.occurrenceIds[index] && evidence.includes(id2)) || value.retention_occurrence_ids[0] !== retained.occurrenceIds[0] || value.retention_occurrence_ids[1] !== retained.occurrenceIds[retained.occurrenceIds.length - 1] || !value.retention_occurrence_ids.every((id2) => evidence.includes(id2))) return;
  const captures = exchange.lineSummary.material.events.filter((event) => event.capture), [loss, recovery] = captures;
  if (loss?.ply_offset !== 1 || recovery?.ply_offset !== 2 || loss.before_role !== value.role || loss.capture.role !== value.role || recovery.before_role !== value.recapturer_role) return;
  const original = trackedPieces(exchange, 0), actor = original?.find((piece) => piece.original.square === exchange.moves[0].uci.slice(0, 2))?.original, target = original?.find((piece) => piece.original.square === exchange.moves[1].uci.slice(0, 2))?.original, afterLoss = trackedPieces(exchange, 2), afterRecovery = trackedPieces(exchange, 3), remaining = trackedPieces(retained, retained.moves.length);
  if (!actor || !target || actor.role !== value.role || target.role !== value.role || actor.side === target.side || !afterLoss || !afterRecovery || !remaining || afterLoss.some((piece) => samePiece(piece.original, actor)) || !afterLoss.some((piece) => samePiece(piece.original, target)) || [actor, target].some((witness) => afterRecovery.some((piece) => samePiece(piece.original, witness)) || !remaining.some((piece) => samePiece(piece.original, witness)))) return;
  return value;
}
function decodeRootSearches(value, observations, context) {
  if (!Array.isArray(value) || value.length > 1e4 || !context) return;
  const result = [];
  for (const raw of value) {
    if (!object(raw) || !exactKeys(raw, [
      "work_id",
      "execution_key_sha256",
      "engine_profile",
      "required_depth",
      "multi_pv",
      "purpose",
      "root_position_id",
      "root_occurrence_id",
      "root_restriction",
      "state",
      "stop_reason",
      "candidates"
    ]) || typeof raw.work_id !== "string" || !/^work:[0-9]+$/.test(raw.work_id) || typeof raw.execution_key_sha256 !== "string" || !/^[a-f0-9]{64}$/.test(raw.execution_key_sha256) || raw.engine_profile !== context.engineProfile || !integer(raw.required_depth, 1, 100) || !integer(raw.multi_pv, 1, 3) || !["root_search", "focus_comparison", "investigation_comparison"].includes(String(raw.purpose)) || !id(raw.root_position_id) || !id(raw.root_occurrence_id) || !object(raw.root_restriction) || !["awaiting_engine", "completed", "stopped"].includes(String(raw.state)) || (raw.state === "stopped" ? !inquiryStops.includes(String(raw.stop_reason)) : raw.stop_reason !== null) || !Array.isArray(raw.candidates) || raw.candidates.length > raw.multi_pv || raw.state === "awaiting_engine" && raw.candidates.length !== 0 || raw.state === "completed" && raw.candidates.length === 0)
      return;
    const root = observations.positions?.find((position) => position.id === raw.root_position_id);
    if (!root?.legal_moves.complete || root.fen !== context.rootFen || !observations.paths.some(
      (path) => path.kind !== "history" && path.startFen === context.rootFen && path.positionIds?.[0] === root.id && path.moves[0]?.uci === context.playedMove && path.occurrenceIds[0] === raw.root_occurrence_id
    ))
      return;
    const legal = root.legal_moves.moves.map((move) => move.uci), restriction = raw.root_restriction;
    if (restriction.kind === "unrestricted") {
      if (!exactKeys(restriction, ["kind"]) || raw.multi_pv > legal.length) return;
    } else if (restriction.kind !== "restricted" || !exactKeys(restriction, ["kind", "moves_uci"]) || !ids(restriction.moves_uci) || !restriction.moves_uci.length || restriction.moves_uci.length > 218 || !restriction.moves_uci.every((move) => legal.includes(move)) || raw.multi_pv > restriction.moves_uci.length)
      return;
    for (const candidate of raw.candidates) {
      if (!object(candidate) || !exactKeys(candidate, ["move_uci", "line_id", "occurrence_id"]) || !id(candidate.move_uci) || !legal.includes(candidate.move_uci) || restriction.kind === "restricted" && !restriction.moves_uci.includes(candidate.move_uci))
        return;
      if (candidate.line_id === null && candidate.occurrence_id === null && raw.state === "stopped") continue;
      if (!id(candidate.line_id) || !id(candidate.occurrence_id)) return;
      const path = observations.paths.find((path2) => path2.id === candidate.line_id);
      if (!path || path.kind === "history" || path.startFen !== context.rootFen || path.positionIds?.[0] !== root.id || path.moves[0]?.uci !== candidate.move_uci || path.occurrenceIds[0] !== candidate.occurrence_id || !legal.includes(candidate.move_uci) || restriction.kind === "restricted" && !restriction.moves_uci.includes(candidate.move_uci) || !path.evaluations?.some((evaluation) => evaluation.source === raw.purpose))
        return;
    }
    if (new Set(raw.candidates.map((candidate) => candidate.move_uci)).size !== raw.candidates.length) return;
    result.push(raw);
  }
  if (new Set(result.map((search) => search.work_id)).size !== result.length || new Set(result.map((search) => search.execution_key_sha256)).size !== result.length)
    return;
  return result;
}
function decodeResponseSearches(value, observations, context, proposals, rootSearches) {
  if (!Array.isArray(value) || value.length > 1829 || !context) return;
  const result = [];
  for (const raw of value) {
    if (!object(raw) || !exactKeys(
      raw,
      [
        "work_id",
        "execution_key_sha256",
        "engine_profile",
        "required_depth",
        "multi_pv",
        "root_move",
        "root_move_occurrence_id",
        "child_position_id",
        "root_restriction",
        "candidates"
      ],
      ["prefix_moves_uci", "ply_offset", "proposal_ownership"]
    ) || typeof raw.work_id !== "string" || !/^work:[0-9]+$/.test(raw.work_id) || typeof raw.execution_key_sha256 !== "string" || !/^[a-f0-9]{64}$/.test(raw.execution_key_sha256) || raw.engine_profile !== context.engineProfile || !integer(raw.required_depth, 1, 100) || !integer(raw.multi_pv, 1, 3) || !id(raw.root_move) || !id(raw.root_move_occurrence_id) || !id(raw.child_position_id) || !object(raw.root_restriction) || !Array.isArray(raw.candidates) || raw.candidates.length !== raw.multi_pv)
      return;
    const ownership = raw.proposal_ownership;
    if (ownership !== void 0 && (!object(ownership) || !exactKeys(ownership, ["work_id", "execution_key_sha256", "question_refs"]) || ownership.work_id !== raw.work_id || ownership.execution_key_sha256 !== raw.execution_key_sha256 || !Array.isArray(ownership.question_refs) || !ownership.question_refs.length || ownership.question_refs.length > 600 || !ownership.question_refs.every((ref) => object(ref) && exactKeys(ref, ["proposal_id", "requirement_id"]) && proposalId(ref.proposal_id) && proposalId(ref.requirement_id)) || new Set(ownership.question_refs.map((ref) => `${ref.proposal_id}/${ref.requirement_id}`)).size !== ownership.question_refs.length)) return;
    const prefix = raw.prefix_moves_uci === void 0 ? [raw.root_move] : raw.prefix_moves_uci;
    if (!Array.isArray(prefix) || !prefix.length || prefix.length > 79 || !prefix.every((move) => typeof move === "string" && /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(move)) || raw.prefix_moves_uci === void 0 !== (raw.ply_offset === void 0) || raw.ply_offset !== void 0 && raw.ply_offset !== prefix.length || !commentarySearchAnchorPath(
      observations,
      context.rootFen,
      raw.root_move,
      raw.root_move_occurrence_id,
      raw.child_position_id,
      prefix
    ))
      return;
    const offset = prefix.length;
    const child = observations.positions?.find((position) => position.id === raw.child_position_id);
    if (!child?.legal_moves.complete) return;
    const restriction = raw.root_restriction;
    const legal = child.legal_moves.moves.map((move) => move.uci);
    if (restriction.kind === "unrestricted") {
      if (!exactKeys(restriction, ["kind"]) || raw.multi_pv !== Math.min(3, legal.length)) return;
    } else if (restriction.kind !== "restricted" || !exactKeys(restriction, ["kind", "moves_uci"]) || !ids(restriction.moves_uci) || !restriction.moves_uci.length || restriction.moves_uci.length > 218 || !restriction.moves_uci.every((move) => legal.includes(move)) || raw.multi_pv !== Math.min(3, restriction.moves_uci.length))
      return;
    const mover = setupPosition("chess", parseFen(child.fen).unwrap()).unwrap().turn;
    const candidates = [];
    for (const candidate of raw.candidates) {
      if (!object(candidate) || !exactKeys(candidate, ["move_uci", "line_id", "occurrence_id", "evaluation"]) || !id(candidate.move_uci) || !id(candidate.line_id) || !id(candidate.occurrence_id))
        return;
      const path = observations.paths.find((path2) => path2.id === candidate.line_id);
      if (!path || path.kind === "history" || path.startFen !== context.rootFen || path.moves[0]?.uci !== raw.root_move || path.occurrenceIds[0] !== raw.root_move_occurrence_id || !prefix.every((move, index) => path.moves[index]?.uci === move) || path.positionIds?.[offset] !== child.id || path.moves[offset - 1]?.fenAfter !== child.fen || path.moves[offset]?.uci !== candidate.move_uci || path.occurrenceIds[offset] !== candidate.occurrence_id || !legal.includes(candidate.move_uci) || restriction.kind === "restricted" && !restriction.moves_uci.includes(candidate.move_uci))
        return;
      const evaluation = decodeCommentaryEvaluation(candidate.evaluation, path.moves.length - offset);
      if (!evaluation || evaluation.source !== "response_comparison" || evaluation.kind === "engine_search" && (evaluation.depth < raw.required_depth || evaluation.white_score.kind !== "mate" && evaluation.depth < 8) || !path.conditionalEvaluations?.some(
        (entry) => entry.searchPositionId === child.id && entry.plyOffset === offset && JSON.stringify(entry.evaluation) === JSON.stringify(evaluation)
      ))
        return;
      candidates.push({ ...candidate, evaluation });
    }
    if (new Set(candidates.map((candidate) => candidate.move_uci)).size !== candidates.length || new Set(
      candidates.flatMap(
        (candidate) => candidate.evaluation.kind === "engine_search" ? [candidate.evaluation.depth] : []
      )
    ).size > 1 || candidates.some((candidate, index) => {
      if (!index) return false;
      const previous = candidates[index - 1];
      const difference = rankingScore(previous.evaluation, mover) - rankingScore(candidate.evaluation, mover);
      return difference < 0 || difference === 0 && previous.move_uci > candidate.move_uci;
    }))
      return;
    result.push({ ...raw, candidates });
  }
  if (new Set(result.map((search) => search.work_id)).size !== result.length || new Set(result.map((search) => search.execution_key_sha256)).size !== result.length)
    return;
  if (!declaredFamilyReceiptCapacityMatches(result, proposals, rootSearches, observations, context)) return;
  return result;
}
function decodeResponseInquiries(value, observations, context, searches) {
  if (!Array.isArray(value) || value.length > 128 || !context) return;
  const result = [];
  const root = setupPosition("chess", parseFen(context.rootFen).unwrap()).unwrap();
  for (const raw of value) {
    if (!object(raw) || !exactKeys(
      raw,
      [
        "id",
        "scope",
        "source",
        "root_occurrence_id",
        "root_move",
        "root_move_occurrence_id",
        "child_position_id",
        "original_target",
        "related_inquiry_ids",
        "target",
        "pressure_source_ids",
        "capture_moves",
        "decline_moves",
        "move_source_ids",
        "reference_move",
        "alternative_move",
        "state",
        "stop_reason",
        "answer"
      ],
      ["reference_selection", "alternative_selection"]
    ) || !id(raw.id) || raw.scope !== "target_response" || raw.source !== "automatic_observation" || !id(raw.root_occurrence_id) || !id(raw.root_move_occurrence_id) || !id(raw.child_position_id) || !id(raw.root_move) || !id(raw.reference_move) || !id(raw.alternative_move) || !ids(raw.related_inquiry_ids) || !ids(raw.pressure_source_ids) || !ids(raw.capture_moves) || !raw.capture_moves.length || !ids(raw.decline_moves) || !raw.decline_moves.length || !object(raw.move_source_ids) || !["deferred", "awaiting_engine", "answered", "observed", "stopped"].includes(String(raw.state)) || raw.stop_reason !== null && !inquiryStops.includes(String(raw.stop_reason)) || raw.state === "answered" !== (raw.answer !== null) || raw.state === "answered" && raw.stop_reason !== null || raw.state === "observed" && raw.stop_reason !== null || raw.state === "awaiting_engine" && raw.stop_reason !== null || raw.state === "deferred" && raw.stop_reason !== null && raw.stop_reason !== "investigation_limit" || raw.state === "stopped" && raw.stop_reason === null)
      return;
    const anchor = observations.paths.find(
      (path) => path.kind !== "history" && path.startFen === context.rootFen && path.moves[0]?.uci === raw.root_move && path.occurrenceIds[0] === raw.root_move_occurrence_id && path.positionIds?.[1] === raw.child_position_id
    );
    if (!anchor) return;
    const position = observations.positions?.find((position2) => position2.id === anchor.positionIds?.[0]);
    const child = observations.positions?.find((position2) => position2.id === raw.child_position_id);
    if (!position || position.fen !== context.rootFen || !child || child.fen !== anchor.moves[0].fenAfter || !child.legal_moves.complete || !observations.paths.some(
      (path) => path.kind !== "history" && path.startFen === context.rootFen && path.positionIds?.[0] === position.id && path.occurrenceIds[0] === raw.root_occurrence_id && path.moves[0]?.uci === context.playedMove
    ))
      return;
    const original = raw.original_target, target = raw.target;
    if (!object(original) || !exactKeys(original, ["position_id", "side", "role", "square"]) || original.position_id !== position.id || original.side !== root.turn || original.role === "king" || typeof original.square !== "string")
      return;
    const square = parseSquare(original.square), occupant = square === void 0 ? void 0 : root.board.get(square);
    if (!occupant || occupant.color !== original.side || occupant.role !== original.role || !object(target) || !exactKeys(target, ["position_id", "side", "role", "square"]))
      return;
    const tracked = trackedPieces(anchor, 1)?.find(
      (piece) => samePiece(piece.original, original)
    );
    if (!tracked || !samePiece(tracked.current, target)) return;
    const pressureSources = [
      ...position.controls.pieces.flatMap((control) => control.piece.side === original.side ? [] : control.source_ids.filter((_, index) => control.squares[index] === original.square)),
      ...child.controls.pieces.flatMap((control) => control.piece.side === target.side ? [] : control.source_ids.filter((_, index) => control.squares[index] === target.square))
    ];
    const captures = child.legal_moves.moves.filter((move) => move.captured_square === target.square);
    const declines = child.legal_moves.moves.filter((move) => move.captured_square !== target.square);
    if (!sameIds(raw.pressure_source_ids, pressureSources) || !pressureSources.length && !captures.some((move) => move.captured_square !== move.destination))
      return;
    if (!sameIds(
      raw.capture_moves,
      captures.map((move) => move.uci)
    ) || !sameIds(
      raw.decline_moves,
      declines.map((move) => move.uci)
    ) || !raw.capture_moves.includes(raw.reference_move) || !raw.decline_moves.includes(raw.alternative_move) || !sameIds(
      Object.keys(raw.move_source_ids),
      child.legal_moves.moves.map((move) => move.uci)
    ) || !child.legal_moves.moves.every(
      (move) => raw.move_source_ids[move.uci] === move.source_id
    ))
      return;
    const answer = raw.answer === null ? null : decodeComparisonAnswer(
      raw.answer,
      observations,
      context,
      child.id,
      raw.reference_move,
      raw.alternative_move,
      { rootMove: raw.root_move, rootOccurrenceId: raw.root_move_occurrence_id }
    );
    if (answer === void 0) return;
    const selections = ["reference_selection", "alternative_selection"];
    if (selections.some((key) => key in raw)) {
      if (!selections.every((key) => key in raw)) return;
      for (const [index, key] of selections.entries()) {
        const selection = raw[key];
        const move = index === 0 ? raw.reference_move : raw.alternative_move;
        const family = index === 0 ? raw.capture_moves : raw.decline_moves;
        if (!object(selection) || !exactKeys(selection, ["source", "work_id", "line_id"])) return;
        if (selection.source === "legal_seed") {
          if (selection.work_id !== null || selection.line_id !== null) return;
          continue;
        }
        const path = observations.paths.find((path2) => path2.id === selection.line_id);
        if (!path || path.kind === "history" || path.startFen !== context.rootFen || path.moves[0]?.uci !== raw.root_move || path.occurrenceIds[0] !== raw.root_move_occurrence_id || path.positionIds?.[1] !== child.id || path.moves[1]?.uci !== move)
          return;
        if (selection.source === "child_search") {
          const ranked = searches?.filter(
            (search2) => responseSearchPrefix(search2).length === 1 && search2.root_move === raw.root_move && search2.root_move_occurrence_id === raw.root_move_occurrence_id && search2.child_position_id === child.id && search2.candidates.some((candidate) => family.includes(candidate.move_uci))
          ).sort((left, right) => {
            const covers = (search2) => search2.root_restriction.kind === "unrestricted" || family.every(
              (move2) => search2.root_restriction.kind === "restricted" && search2.root_restriction.moves_uci.includes(move2)
            );
            return Number(covers(right)) - Number(covers(left)) || Number(right.work_id.slice(5)) - Number(left.work_id.slice(5));
          });
          const search = ranked?.[0];
          const best = search?.candidates.find((candidate) => family.includes(candidate.move_uci));
          if (best?.move_uci !== move) return;
          const claimed = ranked?.find((search2) => search2.work_id === selection.work_id && (search2.root_restriction.kind === "unrestricted" || family.every((move2) => search2.root_restriction.kind === "restricted" && search2.root_restriction.moves_uci.includes(move2))));
          const originalChoice = claimed?.candidates.find((candidate) => family.includes(candidate.move_uci));
          if ((search?.work_id !== selection.work_id || best.line_id !== selection.line_id) && (originalChoice?.move_uci !== move || originalChoice.line_id !== selection.line_id)) return;
        } else if (selection.work_id !== null || !["root_pv_hint", "observed_line"].includes(String(selection.source)) || selection.source === "root_pv_hint" && !path.evaluations?.some((evaluation) => evaluation.source !== "direct_input"))
          return;
      }
    }
    if (answer && searches !== void 0) {
      const search = searches.find((search2) => search2.work_id === answer.work_id);
      if (!search || responseSearchPrefix(search).length !== 1 || search.execution_key_sha256 !== answer.execution_key_sha256 || search.engine_profile !== answer.engine_profile || search.required_depth !== answer.required_depth || search.child_position_id !== child.id || search.root_move !== raw.root_move || ![
        [answer.reference_line_id, answer.reference_evaluation],
        [answer.alternative_line_id, answer.alternative_evaluation]
      ].every(
        ([line, evaluation]) => search.candidates.some(
          (candidate) => candidate.line_id === line && JSON.stringify(candidate.evaluation) === JSON.stringify(evaluation)
        )
      ))
        return;
    }
    result.push({ ...raw, answer });
  }
  if (new Set(result.map((inquiry) => inquiry.id)).size !== result.length || new Set(result.map((inquiry) => `${inquiry.root_move_occurrence_id}:${inquiry.target.square}`)).size !== result.length)
    return;
  for (const inquiry of result) {
    const peers = result.filter(
      (peer) => peer.root_occurrence_id === inquiry.root_occurrence_id && peer.root_move !== inquiry.root_move && samePiece(peer.original_target, inquiry.original_target)
    );
    if (!sameIds(
      inquiry.related_inquiry_ids,
      peers.map((peer) => peer.id)
    ) || !peers.every((peer) => peer.related_inquiry_ids.includes(inquiry.id)))
      return;
  }
  return result;
}
function routeChallengeShape(value) {
  if (value === void 0 || value === null) return true;
  if (!object(value) || !exactKeys(value, [
    "state",
    "stop_reason",
    "reference_work_id",
    "reference_move",
    "reference_line_id",
    "move_classes"
  ]) || !["not_returned", "awaiting_engine", "sampled", "compared", "stopped"].includes(String(value.state)) || !id(value.reference_work_id) || !id(value.reference_move) || !id(value.reference_line_id) || value.stop_reason !== null && !inquiryStops.includes(String(value.stop_reason)) || value.state === "stopped" && value.stop_reason === null || value.stop_reason !== null && value.state !== "stopped" && !(["sampled", "not_returned"].includes(String(value.state)) && value.stop_reason === "investigation_limit") || !Array.isArray(value.move_classes) || !value.move_classes.length || value.move_classes.length > 1e4)
    return false;
  return value.move_classes.every(
    (group) => object(group) && exactKeys(
      group,
      ["moves_uci", "premise_occurrence_ids", "source_line_ids", "sampled_work_ids", "comparison"],
      ["kind"]
    ) && (group.kind === void 0 || ["recovery_route", "replacement_recapture", "exposed_capture"].includes(String(group.kind))) && ids(group.moves_uci) && group.moves_uci.length > 0 && ids(group.premise_occurrence_ids) && group.premise_occurrence_ids.length > 0 && ids(group.source_line_ids) && group.source_line_ids.length > 0 && ids(group.sampled_work_ids) && (group.comparison === null || object(group.comparison) && exactKeys(group.comparison, ["work_id", "reference_line_id", "challenge_line_id"]) && id(group.comparison.work_id) && id(group.comparison.reference_line_id) && id(group.comparison.challenge_line_id))
  );
}
function continuationComparisonSourcesShape(value) {
  return Array.isArray(value) && value.length <= 1e4 && value.every(
    (source) => object(source) && exactKeys(source, ["work_id", "donor_line_id", "peer_line_id"], ["kind", "observation_line_id"]) && id(source.work_id) && id(source.donor_line_id) && id(source.peer_line_id) && (source.kind === void 0 || ["material_recovery", "support_application"].includes(String(source.kind))) && ((source.kind ?? "material_recovery") === "support_application" ? id(source.observation_line_id) : source.observation_line_id === void 0 || source.observation_line_id === null)
  ) && new Set(value.map(continuationComparisonSourceKey)).size === value.length;
}
function continuationPremisesShape(value) {
  return Array.isArray(value) && value.length > 0 && value.length <= 1e4 && value.every(
    (premise) => object(premise) && exactKeys(premise, [
      "id",
      "kind",
      "trigger_occurrence_ids",
      "source_line_ids",
      "comparison_source_indices",
      "requirement_id",
      "witness_line_ids",
      "unresolved_source_line_ids",
      "observation_state"
    ]) && id(premise.id) && continuationKinds.includes(premise.kind) && ids(premise.trigger_occurrence_ids) && premise.trigger_occurrence_ids.length > 0 && ids(premise.source_line_ids) && premise.source_line_ids.length > 0 && Array.isArray(premise.comparison_source_indices) && premise.comparison_source_indices.length <= 1e4 && premise.comparison_source_indices.every((index) => Number.isSafeInteger(index) && index >= 0) && new Set(premise.comparison_source_indices).size === premise.comparison_source_indices.length && (premise.requirement_id === null || id(premise.requirement_id)) && ids(premise.witness_line_ids) && ids(premise.unresolved_source_line_ids) && ["observed", "unobserved", "unavailable", "not_applicable"].includes(
      String(premise.observation_state)
    )
  ) && new Set(value.map((premise) => premise.id)).size === value.length && new Set(
    value.map(
      (premise) => JSON.stringify([
        premise.kind,
        [...premise.trigger_occurrence_ids].sort(),
        [...premise.comparison_source_indices].sort((a, b) => a - b),
        premise.requirement_id
      ])
    )
  ).size === value.length;
}
function decodeContinuationInquiries(value, observations, context, searches) {
  if (!Array.isArray(value) || value.length > 1e4 || !context) return;
  const result = [];
  for (const raw of value) {
    if (!object(raw) || !exactKeys(
      raw,
      [
        "id",
        "scope",
        "source",
        "root_occurrence_id",
        "root_position_id",
        "position_id",
        "prefix_moves_uci",
        "prefix_occurrence_ids",
        "trigger_occurrence_ids",
        "observed_moves",
        "source_line_ids",
        "kinds",
        "premises",
        "legal_moves",
        "move_source_ids",
        "state",
        "stop_reason",
        "search_work_ids",
        "explanation_candidate_ids"
      ],
      ["comparison_sources", "unresolved_source_line_ids", "followup_question_ids", "route_challenge"]
    ) || !id(raw.id) || raw.scope !== "line_continuation" || raw.source !== "automatic_observation" || !id(raw.root_occurrence_id) || !id(raw.root_position_id) || !id(raw.position_id) || !Array.isArray(raw.prefix_moves_uci) || !raw.prefix_moves_uci.length || raw.prefix_moves_uci.length > 79 || !raw.prefix_moves_uci.every(
      (move) => typeof move === "string" && /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(move)
    ) || !ids(raw.prefix_occurrence_ids) || raw.prefix_occurrence_ids.length !== raw.prefix_moves_uci.length || !ids(raw.trigger_occurrence_ids) || !raw.trigger_occurrence_ids.length || !ids(raw.observed_moves) || !ids(raw.source_line_ids) || !raw.source_line_ids.length || !ids(raw.kinds) || !raw.kinds.length || !ids(raw.legal_moves) || !raw.legal_moves.length || !raw.kinds.every((kind) => continuationKinds.includes(kind)) || !continuationPremisesShape(raw.premises) || !object(raw.move_source_ids) || !ids(raw.search_work_ids) || !ids(raw.explanation_candidate_ids) || raw.unresolved_source_line_ids !== void 0 && !ids(raw.unresolved_source_line_ids) || raw.followup_question_ids !== void 0 && !ids(raw.followup_question_ids) || raw.unresolved_source_line_ids === void 0 !== (raw.followup_question_ids === void 0) || !routeChallengeShape(raw.route_challenge) || !["deferred", "awaiting_engine", "surveyed", "stopped", "forced", "observed"].includes(
      String(raw.state)
    ) || raw.stop_reason !== null && !inquiryStops.includes(String(raw.stop_reason)) || ["awaiting_engine", "surveyed", "forced", "observed"].includes(String(raw.state)) && raw.stop_reason !== null || raw.state === "stopped" && raw.stop_reason === null || raw.state === "deferred" && raw.stop_reason !== null && raw.stop_reason !== "investigation_limit")
      return;
    const prefix = raw.prefix_moves_uci;
    const path = commentarySearchAnchorPath(
      observations,
      context.rootFen,
      prefix[0],
      raw.prefix_occurrence_ids[0],
      raw.position_id,
      prefix
    );
    const position = observations.positions?.find((position2) => position2.id === raw.position_id);
    if (!path || !position?.legal_moves.complete || path.positionIds?.[0] !== raw.root_position_id || !raw.prefix_occurrence_ids.every((occurrence, index) => path.occurrenceIds[index] === occurrence) || !observations.paths.some(
      (actual) => actual.kind !== "history" && actual.startFen === context.rootFen && actual.positionIds?.[0] === raw.root_position_id && actual.moves[0]?.uci === context.playedMove && actual.occurrenceIds[0] === raw.root_occurrence_id
    ) || !sameIds(
      raw.legal_moves,
      position.legal_moves.moves.map((move) => move.uci)
    ) || !sameIds(Object.keys(raw.move_source_ids), raw.legal_moves) || !position.legal_moves.moves.every(
      (move) => raw.move_source_ids[move.uci] === move.source_id
    ))
      return;
    const prefixIds = raw.prefix_occurrence_ids, legalMoves = raw.legal_moves, sourceLineIds = raw.source_line_ids;
    const comparisonSources = raw.comparison_sources ?? [];
    if (!continuationComparisonSourcesShape(comparisonSources) || !sameIds(
      raw.kinds,
      raw.premises.map((premise) => premise.kind)
    ) || !sameIds(
      raw.trigger_occurrence_ids,
      raw.premises.flatMap((premise) => premise.trigger_occurrence_ids)
    ) || raw.premises.some(
      (premise) => premise.comparison_source_indices.some((index) => index >= comparisonSources.length)
    ) || !sameIds(
      comparisonSources.map((_, index) => String(index)),
      raw.premises.flatMap((premise) => premise.comparison_source_indices.map(String))
    ) || raw.premises.some(
      (premise) => [...premise.source_line_ids, ...premise.witness_line_ids, ...premise.unresolved_source_line_ids].some(
        (line) => !sourceLineIds.includes(line)
      )
    ) || comparisonSources.some((source) => (source.kind ?? "material_recovery") === "material_recovery") !== raw.kinds.includes("continuation_not_observed") || comparisonSources.some((source) => source.kind === "support_application") !== raw.kinds.includes("support_application_not_observed"))
      return;
    const donorPaths = comparisonSources.flatMap(
      (source) => [source.donor_line_id, source.observation_line_id].flatMap(
        (id2) => observations.paths.find((path2) => path2.id === id2) ?? []
      )
    );
    const sourcePaths = raw.source_line_ids.map((id2) => observations.paths.find((path2) => path2.id === id2));
    if (sourcePaths.some(
      (source) => !source || source.kind === "history" || source.startFen !== context.rootFen || source.positionIds?.[0] !== raw.root_position_id || !prefix.every((move, index) => source.moves[index]?.uci === move) || !prefixIds.every((occurrence, index) => source.occurrenceIds[index] === occurrence)
    ) || !raw.trigger_occurrence_ids.every(
      (occurrence) => sourcePaths.some((source) => source.occurrenceIds.includes(occurrence)) || donorPaths.some((source) => source?.occurrenceIds.includes(occurrence))
    ) || !sameIds(
      raw.observed_moves,
      sourcePaths.flatMap((source) => source.moves[prefix.length]?.uci ?? [])
    ) || !raw.observed_moves.every((move) => legalMoves.includes(move)))
      return;
    const inquiry = raw;
    const matching = searches.filter((search) => responseSearchMatchesContinuation(search, inquiry));
    const surveyed = matching.some(
      (search) => search.root_restriction.kind === "unrestricted" || legalMoves.every(
        (move) => search.root_restriction.kind === "restricted" && search.root_restriction.moves_uci.includes(move)
      )
    );
    if (!sameIds(
      raw.search_work_ids,
      matching.map((search) => search.work_id)
    ) || raw.state === "surveyed" !== surveyed || raw.state === "forced" && raw.legal_moves.length !== 1 || raw.state === "awaiting_engine" && raw.legal_moves.length < 2)
      return;
    result.push(inquiry);
  }
  if (new Set(result.map((inquiry) => inquiry.id)).size !== result.length || new Set(result.map((inquiry) => JSON.stringify(inquiry.prefix_occurrence_ids))).size !== result.length)
    return;
  return result;
}
function decodeInquiries(value, observations, context, candidates) {
  if (!Array.isArray(value) || value.length > 436 || !context || !isMoveReviewEngineProfile(context.engineProfile))
    return;
  const root = setupPosition("chess", parseFen(context.rootFen).unwrap()).unwrap();
  const paths = new Map(observations.paths.map((path) => [path.id, path]));
  const inquiries = [];
  for (const raw of value) {
    if (!object(raw) || !exactKeys(
      raw,
      [
        "id",
        "scope",
        "source",
        "root_occurrence_id",
        "anchor_occurrence_ids",
        "ordering_source_ids",
        "position_id",
        "reference_move",
        "alternative_move",
        "reasons",
        "state",
        "stop_reason",
        "answer"
      ],
      ["assessment_effect", "ordering_candidate_ids", "explanation_candidate_ids"]
    ) || !id(raw.id) || raw.scope !== "root_choice" || raw.source !== "automatic_observation" || !id(raw.root_occurrence_id) || !id(raw.position_id) || !id(raw.reference_move) || !id(raw.alternative_move) || !ids(raw.anchor_occurrence_ids) || !raw.anchor_occurrence_ids.includes(raw.root_occurrence_id) || raw.anchor_occurrence_ids.length > 2 || !ids(raw.ordering_source_ids) || raw.ordering_source_ids.length > 8 || raw.reference_move === raw.alternative_move || raw.alternative_move === context.playedMove || !["deferred", "awaiting_engine", "answered", "stopped"].includes(String(raw.state)) || raw.assessment_effect !== void 0 && !["unchanged", "refreshed", "needs_refresh"].includes(String(raw.assessment_effect)) || raw.stop_reason !== null && !inquiryStops.includes(String(raw.stop_reason)) && !(raw.state === "deferred" && raw.stop_reason === "comparison_not_current") || !Array.isArray(raw.reasons) || !raw.reasons.length || raw.reasons.length > 218)
      return;
    if (raw.state === "answered" !== (raw.answer !== null) || raw.state === "stopped" && raw.stop_reason === null || raw.state === "awaiting_engine" && raw.stop_reason !== null || raw.state === "deferred" && raw.stop_reason !== null && !["investigation_limit", "comparison_not_current"].includes(String(raw.stop_reason)) || raw.stop_reason === "reference_changed" && raw.state !== "stopped" || raw.state === "answered" && raw.stop_reason !== null && (raw.assessment_effect !== "needs_refresh" || ["reference_changed", "investigation_limit"].includes(String(raw.stop_reason))))
      return;
    const position = observations.positions?.find((position2) => position2.id === raw.position_id);
    if (!position || position.fen !== context.rootFen || !position.legal_moves.complete || !observations.paths.some(
      (path) => path.kind !== "history" && path.startFen === context.rootFen && path.positionIds?.[0] === raw.position_id && path.occurrenceIds[0] === raw.root_occurrence_id && path.moves[0]?.uci === context.playedMove
    ))
      return;
    if (!raw.anchor_occurrence_ids.every(
      (occurrence) => observations.paths.some(
        (path) => path.kind !== "history" && path.startFen === context.rootFen && path.positionIds?.[0] === position.id && path.occurrenceIds[0] === occurrence && [context.playedMove, raw.reference_move].includes(path.moves[0]?.uci)
      )
    ))
      return;
    const legal = new Map(position.legal_moves.moves.map((move) => [move.uci, move]));
    const reference = legal.get(raw.reference_move);
    const alternative = legal.get(raw.alternative_move);
    if (!reference || !alternative) return;
    if (raw.ordering_source_ids.length && (alternative.captured_square !== void 0 || !raw.ordering_source_ids.every(
      (source) => position.controls.pieces.some(
        (control) => control.piece.side !== root.turn && control.piece.role === "pawn" && control.source_ids.some(
          (id2, index) => id2 === source && control.squares[index] === alternative.destination
        )
      )
    )))
      return;
    const validPiece = (value2) => {
      if (!object(value2) || !exactKeys(value2, ["position_id", "side", "role", "square"]) || value2.position_id !== position.id || typeof value2.square !== "string")
        return false;
      const square = parseSquare(value2.square);
      const piece = square === void 0 ? void 0 : root.board.get(square);
      return !!piece && piece.color === value2.side && piece.role === value2.role;
    };
    const reasons = [];
    for (const reason of raw.reasons) {
      if (!object(reason) || !exactKeys(
        reason,
        [
          "kind",
          "evidence_id",
          "source_id",
          "source_line_id",
          "anchor_move",
          "actor",
          "capture",
          "promotion_role",
          "responds_to_check"
        ],
        ["source_name", "target", "pressure_source_ids"]
      ) || ![
        "engine_alternative",
        "capture_option",
        "same_destination",
        "same_actor_choice",
        "target_relocation",
        "attacker_capture",
        "target_support"
      ].includes(String(reason.kind)) || reason.evidence_id !== position.premise_id || reason.source_id !== alternative.source_id || ![raw.reference_move, context.playedMove].includes(String(reason.anchor_move)) || !validPiece(reason.actor) || reason.actor.side !== root.turn || reason.actor.square !== raw.alternative_move.slice(0, 2) || reason.responds_to_check !== root.isCheck())
        return;
      const parsed = parseUci(raw.alternative_move);
      if (!parsed || !("from" in parsed) || !root.isLegal(parsed) || reason.promotion_role !== (parsed.promotion ?? null))
        return;
      if (alternative.captured_square ? !validPiece(reason.capture) || reason.capture.square !== alternative.captured_square || reason.capture.side === root.turn || reason.capture.role === "king" : reason.capture !== null)
        return;
      const anchor = legal.get(String(reason.anchor_move));
      if (!anchor) return;
      if (reason.kind === "engine_alternative") {
        if (!id(reason.source_line_id)) return;
        const path = paths.get(reason.source_line_id);
        if (!path || path.startFen !== context.rootFen || path.positionIds?.[0] !== position.id || path.moves[0]?.uci !== raw.alternative_move || !path.evaluations?.some((e) => e.source !== "direct_input"))
          return;
      } else if (reason.source_line_id !== null) return;
      if (reason.kind === "capture_option" && reason.capture === null) return;
      const targeted = ["target_relocation", "attacker_capture", "target_support"].includes(
        String(reason.kind)
      );
      const extensions = ["source_name", "target", "pressure_source_ids"];
      if (targeted || extensions.some((key) => key in reason)) {
        if (!extensions.every((key) => key in reason) || !ids(reason.pressure_source_ids)) return;
        if (!targeted) {
          if (reason.source_name !== (reason.kind === "engine_alternative" ? "engine_pv" : "legal_root") || reason.target !== null || reason.pressure_source_ids.length)
            return;
        } else {
          if (reason.source_name !== "attacked_target" || !validPiece(reason.target) || reason.target.side !== root.turn || reason.target.role === "king" || !reason.pressure_source_ids.length)
            return;
          const target = reason.target;
          const pressureIds = reason.pressure_source_ids;
          const pressures = position.controls.pieces.filter(
            (control) => control.piece.side !== target.side && control.source_ids.some(
              (source, index) => pressureIds.includes(source) && control.squares[index] === target.square
            )
          );
          if (!reason.pressure_source_ids.every(
            (source) => pressures.some(
              (control) => control.source_ids.some(
                (entry, index) => entry === source && control.squares[index] === target.square
              )
            )
          ))
            return;
          if (reason.kind === "target_relocation" && reason.actor.square !== target.square) return;
          if (reason.kind === "attacker_capture" && (!reason.capture || !pressures.some(
            (control) => control.piece.square === reason.capture.square
          )))
            return;
          if (reason.kind === "target_support") {
            const targetSquare = parseSquare(target.square);
            const actorSquare = parseSquare(reason.actor.square);
            if (!position.controls.complete || actorSquare === targetSquare || attacks(root.board.get(actorSquare), actorSquare, root.board.occupied).has(targetSquare))
              return;
            const after = root.clone();
            after.play(parsed);
            const destination = parseSquare(alternative.destination);
            const provider = after.board.get(destination);
            const survivor = after.board.get(targetSquare);
            if (!provider || provider.color !== root.turn || survivor?.color !== target.side || survivor.role !== target.role || !attacks(provider, destination, after.board.occupied).has(targetSquare))
              return;
          }
        }
      }
      const anchorSquare = parseSquare(String(reason.anchor_move).slice(0, 2));
      const anchorActor = anchorSquare === void 0 ? void 0 : root.board.get(anchorSquare);
      if (reason.kind === "same_destination" && (alternative.destination !== anchor.destination || reason.actor.square === String(reason.anchor_move).slice(0, 2) || anchorActor?.role !== reason.actor.role))
        return;
      if (reason.kind === "same_actor_choice" && (reason.actor.square !== String(reason.anchor_move).slice(0, 2) || reason.actor.role === "pawn" || reason.capture !== null))
        return;
      reasons.push(reason);
    }
    if (new Set(reasons.map((reason) => JSON.stringify(reason))).size !== reasons.length) return;
    const answer = raw.answer === null ? null : decodeComparisonAnswer(
      raw.answer,
      observations,
      context,
      position.id,
      raw.reference_move,
      raw.alternative_move
    );
    if (answer === void 0) return;
    const extras = ["ordering_candidate_ids", "explanation_candidate_ids"];
    if (extras.some((key) => key in raw)) {
      if (!extras.every((key) => key in raw) || !ids(raw.ordering_candidate_ids) || !ids(raw.explanation_candidate_ids))
        return;
      const sameRoot = (candidate) => candidate.rootOccurrenceId === raw.root_occurrence_id;
      if (!raw.ordering_candidate_ids.every((candidateId) => {
        const candidate = candidates.find((candidate2) => candidate2.id === candidateId && sameRoot(candidate2));
        const detail = candidate && pvComparisonDetail(candidate);
        return detail?.material_relation === "equal" && detail.quality_band === "close" && detail.root_observation_relation === "different" && reasons.some(
          (reason) => ["same_actor_choice", "same_destination"].includes(reason.kind) && reason.capture === null && detail.root_participants.some(
            (piece) => piece.position_id === reason.actor.position_id && piece.side === reason.actor.side && piece.role === reason.actor.role && piece.square === reason.actor.square
          )
        );
      }))
        return;
      const matching = candidates.filter((candidate) => {
        const detail = pvComparisonDetail(candidate);
        return sameRoot(candidate) && answer && detail && detail.answer.reference_line_id === answer.reference_line_id && detail.answer.alternative_line_id === answer.alternative_line_id && detail.answer.work_id === answer.work_id && detail.answer.execution_key_sha256 === answer.execution_key_sha256;
      });
      if (!raw.explanation_candidate_ids.every(
        (candidateId) => matching.some((candidate) => candidate.id === candidateId)
      ))
        return;
    }
    inquiries.push({ ...raw, reasons, answer });
  }
  if (new Set(inquiries.map((inquiry) => inquiry.id)).size !== inquiries.length || new Set(inquiries.map((inquiry) => inquiry.reference_move)).size > 2 || new Set(inquiries.map((inquiry) => `${inquiry.reference_move}:${inquiry.alternative_move}`)).size !== inquiries.length)
    return;
  return inquiries;
}
function rootFactSignature(observations, occurrence) {
  const piece = (value) => value && [value.side, value.role, value.square];
  return uniqueSorted(
    observations.statements.flatMap((statement) => {
      if (statement.occurrenceId !== occurrence) return [];
      if (statement.kind === "development")
        return [
          JSON.stringify([
            "development",
            statement.side,
            statement.role,
            statement.from,
            uniqueSorted(statement.centralSquares)
          ])
        ];
      if (statement.kind !== "piece_control" || statement.before.state === "unknown" || statement.after.state === "unknown" || statement.before.state !== "present" && statement.after.state !== "present")
        return [];
      const move = observations.paths.find((path) => path.occurrenceIds[0] === occurrence)?.moves[0];
      const parsed = move && parseUci(move.uci);
      const afterRole = parsed && "from" in parsed ? parsed.promotion ?? statement.role : statement.role;
      const isMover = (value, phase) => value?.side === statement.side && value.role === (phase === "before" ? statement.role : afterRole) && value.square === (phase === "before" ? statement.from : statement.to);
      if (![statement.before.controller, statement.before.target].some((piece2) => isMover(piece2, "before")) && ![statement.after.controller, statement.after.target].some((piece2) => isMover(piece2, "after")))
        return [];
      const normalizeAfter = (value) => isMover(value, "after") ? [statement.side, statement.role, statement.from] : piece(value);
      return [
        JSON.stringify([
          "control",
          [piece(statement.before.controller), piece(statement.before.target), statement.before.state],
          [
            normalizeAfter(statement.after.controller),
            normalizeAfter(statement.after.target),
            statement.after.state
          ]
        ])
      ];
    })
  );
}
function eventSignature(summary) {
  return JSON.stringify(
    summary.material.events.map((event) => [
      event.ply_offset,
      [event.side, event.from, event.to, event.before_role, event.after_role],
      event.capture ? [event.side, event.before_role, event.capture.role, event.capture.square] : null,
      event.promotion_gain_cp
    ])
  );
}
function qualityBand(left, right, mover) {
  const winPercent = (evaluation) => {
    if (evaluation.kind === "exact_automatic_terminal")
      return evaluation.terminal.kind === "checkmate" ? evaluation.terminal.winner === mover ? 100 : 0 : 50;
    if (evaluation.white_score.kind === "mate")
      return evaluation.white_score.value > 0 === (mover === "white") ? 100 : 0;
    return rankingScore(evaluation, mover);
  };
  const difference = Math.abs(winPercent(left) - winPercent(right));
  const cpException = difference > 0 && left.kind === "engine_search" && right.kind === "engine_search" && left.white_score.kind === "cp" && right.white_score.kind === "cp" && Math.abs(left.white_score.value - right.white_score.value) >= 500;
  return difference >= 2.5 || cpException ? "separated" : "close";
}
function decodePvComparison(raw, observations, context) {
  const detail = raw.detail;
  if (!context || !object(detail) || !exactKeys(
    detail,
    [
      "type",
      "scope",
      "answer",
      "material_relation",
      "event_sequence_relation",
      "root_observation_relation",
      "root_difference_occurrence_ids",
      "root_participants",
      "quality_band",
      "text"
    ],
    ["continuation_candidate_ids", "continuation_comparison_ids", "effects"]
  ) || detail.type !== "pv_comparison" || detail.scope !== "observed_lines" || raw.selection !== "context" || !object(detail.answer) || !ids(raw.line_ids) || raw.line_ids.length !== 2 || !ids(detail.root_difference_occurrence_ids) || !Array.isArray(detail.root_participants) || typeof detail.text !== "string" || !detail.text.trim() || detail.text.length > 1e3)
    return;
  const paths = raw.line_ids.map((lineId) => observations.paths.find((path) => path.id === lineId));
  const [left, right] = paths;
  const positionId = left.positionIds?.[0];
  const rootPath = observations.paths.find(
    (path) => path.kind !== "history" && path.occurrenceIds[0] === raw.root_occurrence_id && path.moves[0]?.uci === context.playedMove && path.positionIds?.[0] === positionId && path.startFen === context.rootFen
  );
  if (!rootPath || !positionId) return;
  const answer = decodeComparisonAnswer(
    detail.answer,
    observations,
    context,
    positionId,
    left.moves[0]?.uci,
    right.moves[0]?.uci
  );
  if (!answer || answer.reference_line_id !== left.id || answer.alternative_line_id !== right.id) return;
  const available = new Set(observations.positions?.map((position) => position.id));
  const material = paths.map(
    (path) => path.positionIds?.length === path.moves.length + 1 && path.positionIds.every((position) => position !== null && available.has(position)) ? path.lineSummary?.material : void 0
  );
  const materialRelation = material.every(Boolean) ? exchangeSignature(left.lineSummary) === exchangeSignature(right.lineSummary) ? "equal" : "different" : "unavailable";
  const eventRelation = material.every(Boolean) ? eventSignature(left.lineSummary) === eventSignature(right.lineSummary) ? "same" : "different" : "unavailable";
  const signatures = [answer.reference_occurrence_id, answer.alternative_occurrence_id].map(
    (occurrence) => rootFactSignature(observations, occurrence)
  );
  const rootRelation = signatures.every((signature) => signature.length) ? JSON.stringify(signatures[0]) === JSON.stringify(signatures[1]) ? "same" : "different" : "unavailable";
  const differenceIds = rootRelation === "different" ? [answer.reference_occurrence_id, answer.alternative_occurrence_id] : [];
  const root = setupPosition("chess", parseFen(context.rootFen).unwrap()).unwrap();
  const participants = differenceIds.map((_, index) => {
    const square = paths[index].moves[0].uci.slice(0, 2);
    const piece = root.board.get(parseSquare(square));
    return piece && { position_id: positionId, side: piece.color, role: piece.role, square };
  });
  if (participants.some((piece) => !piece)) return;
  const expectedParticipants = [
    ...new Map(participants.map((piece) => [JSON.stringify(piece), piece])).values()
  ];
  if (detail.material_relation !== materialRelation || detail.event_sequence_relation !== eventRelation || detail.root_observation_relation !== rootRelation || JSON.stringify(detail.root_difference_occurrence_ids) !== JSON.stringify(differenceIds) || detail.root_participants.length !== expectedParticipants.length || !detail.root_participants.every((piece, index) => {
    const expected = expectedParticipants[index];
    return object(piece) && exactKeys(piece, ["position_id", "side", "role", "square"]) && Object.keys(expected).every((key) => piece[key] === expected[key]);
  }) || detail.quality_band !== qualityBand(answer.reference_evaluation, answer.alternative_evaluation, root.turn))
    return;
  const sourceRefs = raw.source_refs;
  if (sourceRefs.length !== 2 || !paths.every(
    (path, index) => sourceRefs.some(
      (source) => source.line_id === path.id && source.kind === "evaluation" && source.stop === null && source.accepted_ply_count === path.moves.length && source.source === [answer.reference_evaluation, answer.alternative_evaluation][index].source
    )
  ) || !sameIds(
    raw.evidence_ids,
    paths.flatMap((path) => path.lineSummary?.premise_ids ?? [])
  ))
    return;
  return { ...detail, answer, root_participants: expectedParticipants };
}
function decodeTargetResponse(raw, observations, inquiries) {
  const detail = raw.detail;
  if (!object(detail) || !exactKeys(
    detail,
    ["type", "scope", "response_inquiry_id", "original_target", "branches", "text"],
    ["continuation_candidate_ids", "continuation_comparison_ids"]
  ) || detail.scope !== "observed_lines" || raw.selection !== "context" || !Array.isArray(detail.branches) || detail.branches.length !== 2)
    return;
  const inquiry = inquiries.find((inquiry2) => inquiry2.id === detail.response_inquiry_id);
  if (!inquiry || raw.root_occurrence_id !== inquiry.root_occurrence_id || !object(detail.original_target) || !exactKeys(detail.original_target, ["position_id", "side", "role", "square"]) || !samePiece(detail.original_target, inquiry.original_target))
    return;
  const equalPiece = (value, expected) => expected === null ? value === null : object(value) && exactKeys(value, ["position_id", "side", "role", "square"]) && samePiece(value, expected);
  const equalPairs = (value, expected) => Array.isArray(value) && value.length === expected.length && value.every(
    (piece) => object(piece) && exactKeys(piece, ["original", "current"]) && expected.some(
      (other) => equalPiece(piece.original, other.original) && equalPiece(piece.current, other.current)
    )
  ) && expected.every(
    (other) => value.some(
      (piece) => equalPiece(piece.original, other.original) && equalPiece(piece.current, other.current)
    )
  );
  const piecesAt = (path, ply) => trackedPieces(path, ply) ?? [];
  const used = [];
  for (const [index, branch] of detail.branches.entries()) {
    if (!object(branch) || !exactKeys(branch, [
      "line_id",
      "reply_move",
      "reply_occurrence_id",
      "position_id",
      "target_state",
      "target",
      "providers",
      "capturer",
      "recaptures",
      "observed_recapture"
    ]))
      return;
    const path = observations.paths.find((path2) => path2.id === branch.line_id);
    const reply = branch.reply_move;
    if (!path || path.kind === "history" || path.moves[0]?.uci !== inquiry.root_move || path.occurrenceIds[0] !== inquiry.root_move_occurrence_id || path.positionIds?.[1] !== inquiry.child_position_id || typeof reply !== "string" || !(index === 0 ? inquiry.capture_moves : inquiry.decline_moves).includes(reply) || path.moves[1]?.uci !== reply || branch.reply_move !== reply || path.occurrenceIds[1] !== branch.reply_occurrence_id || path.positionIds?.[2] !== branch.position_id)
      return;
    used.push(path);
    const pieces = piecesAt(path, 2), childPieces = piecesAt(path, 1);
    const position = observations.positions?.find((position2) => position2.id === branch.position_id);
    const target = pieces.find((piece) => samePiece(piece.original, inquiry.original_target))?.current ?? null;
    const targetState = target ? "present" : "captured";
    if (branch.target_state !== targetState || !equalPiece(branch.target, target)) return;
    const providers = branch.providers;
    if (!object(providers) || !exactKeys(providers, ["state", "pieces", "source_ids"]) || !ids(providers.source_ids))
      return;
    const providerState = !target ? "not_applicable" : position?.controls.complete ? "complete" : "unknown";
    const providerPairs = [], providerSources = [];
    if (target && providerState === "complete")
      for (const control of position.controls.pieces) {
        if (control.piece.side !== target.side) continue;
        const pair = pieces.find(
          (piece) => piece.current.square === control.piece.square && piece.current.side === control.piece.side && piece.current.role === control.piece.role
        );
        if (!pair) return;
        control.squares.forEach((square, index2) => {
          if (square === target.square) {
            providerPairs.push(pair);
            providerSources.push(control.source_ids[index2]);
          }
        });
      }
    if (providers.state !== providerState || !equalPairs(providers.pieces, providerPairs) || !sameIds(providers.source_ids, providerSources))
      return;
    const actorBefore = childPieces.find((piece) => piece.current.square === reply.slice(0, 2));
    const capturer = inquiry.capture_moves.includes(reply) && actorBefore ? pieces.find((piece) => samePiece(piece.original, actorBefore.original))?.current ?? null : null;
    if (!equalPiece(branch.capturer, capturer)) return;
    const recaptures = branch.recaptures;
    if (!object(recaptures) || !exactKeys(recaptures, ["state", "moves"]) || !Array.isArray(recaptures.moves))
      return;
    const recaptureState = capturer ? position?.legal_moves.complete ? "complete" : "unknown" : "not_applicable";
    const moves = recaptureState === "complete" ? position.legal_moves.moves.filter((move) => move.captured_square === capturer.square) : [];
    if (recaptures.state !== recaptureState || recaptures.moves.length !== moves.length || !sameIds(
      recaptures.moves.map((move) => object(move) ? String(move.move_uci) : ""),
      moves.map((move) => move.uci)
    ) || !recaptures.moves.every(
      (move) => object(move) && exactKeys(move, ["move_uci", "source_id", "actor"]) && moves.some(
        (legal) => legal.uci === move.move_uci && legal.source_id === move.source_id && equalPiece(
          move.actor,
          pieces.find((piece) => piece.current.square === legal.uci.slice(0, 2))?.current ?? null
        )
      )
    ))
      return;
    const observed = branch.observed_recapture;
    if (!object(observed) || !exactKeys(observed, ["state", "occurrence_id", "actor", "supported_targets", "source_ids"]) || !ids(observed.source_ids))
      return;
    const next = path.moves[2]?.uci;
    const wasObserved = !!next && moves.some((move) => move.uci === next);
    if (!wasObserved) {
      if (observed.state !== (recaptureState === "unknown" ? "unknown" : "not_observed") || observed.occurrence_id !== null || observed.actor !== null || !equalPairs(observed.supported_targets, []) || observed.source_ids.length)
        return;
    } else {
      const after = piecesAt(path, 3), afterPosition = observations.positions?.find((position2) => position2.id === path.positionIds?.[3]);
      const beforeActor = pieces.find((piece) => piece.current.square === next.slice(0, 2));
      const actor = beforeActor && after.find((piece) => samePiece(piece.original, beforeActor.original));
      const expectedState = actor && afterPosition?.controls.complete ? "complete" : "unknown";
      const targets = [], sources2 = [];
      if (expectedState === "complete")
        for (const control of afterPosition.controls.pieces) {
          if (control.piece.square !== actor.current.square || control.piece.side !== actor.current.side || control.piece.role !== actor.current.role)
            continue;
          control.squares.forEach((square, index2) => {
            const supported = after.find(
              (piece) => piece.current.square === square && piece.current.side === actor.current.side && piece.current.role !== "king" && !samePiece(piece.original, actor.original)
            );
            if (supported) {
              targets.push(supported);
              sources2.push(control.source_ids[index2]);
            }
          });
        }
      if (observed.state !== expectedState || observed.occurrence_id !== path.occurrenceIds[2] || (actor ? !equalPairs([observed.actor], [actor]) : observed.actor !== null) || !equalPairs(observed.supported_targets, targets) || !sameIds(observed.source_ids, sources2))
        return;
    }
  }
  if (!sameIds(
    raw.line_ids,
    used.map((path) => path.id)
  ) || !sameIds(
    raw.evidence_ids,
    used.flatMap((path) => path.lineSummary?.premise_ids ?? [])
  ))
    return;
  const sources = raw.source_refs;
  if (sources.length !== 2 || !used.every(
    (path) => sources.some(
      (source) => source.line_id === path.id && source.kind === "admitted" && source.source === "legal_replay" && source.stop === null && source.accepted_ply_count === path.moves.length
    )
  ))
    return;
  return detail;
}
function continuationSupportAt(observations, path, actor, target, offset, pieces = trackedPieces(path, offset)) {
  if (!pieces) return { state: "unknown", source_ids: [] };
  const currentActor = pieces.find((piece) => samePiece(piece.original, actor))?.current;
  const currentTarget = pieces.find((piece) => samePiece(piece.original, target))?.current;
  if (!currentActor) return { state: "actor_removed", source_ids: [] };
  if (!currentTarget) return { state: "target_removed", source_ids: [] };
  const position = observations.positions?.find((position2) => position2.id === path.positionIds[offset]);
  const controls = position?.controls.pieces.find(
    (control) => control.piece.side === currentActor.side && control.piece.role === currentActor.role && control.piece.square === currentActor.square
  );
  const sources = controls?.source_ids.filter((_source, index) => controls.squares[index] === currentTarget.square) ?? [];
  return {
    state: sources.length ? "present" : position?.controls.complete ? "absent" : "unknown",
    source_ids: sources
  };
}
function kingCaptureAt(observations, path, provider, originalTarget, originalKing, count, pieces) {
  const position = observations.positions?.find((position2) => position2.id === path.positionIds[count]);
  if (!position?.legal_moves.complete || parseFen(position.fen).unwrap().turn !== originalKing.side) return;
  const king = pieces.find((piece) => samePiece(piece.original, originalKing))?.current;
  const target = pieces.find((piece) => samePiece(piece.original, originalTarget))?.current;
  if (!king || !target) return;
  const contact = continuationSupportAt(observations, path, originalKing, originalTarget, count, pieces);
  const support = continuationSupportAt(observations, path, provider, originalTarget, count, pieces);
  if (contact.state !== "present" || support.state === "unknown") return;
  const rows = position.legal_moves.moves.filter(
    (move) => move.uci.slice(0, 2) === king.square && move.captured_square === target.square
  );
  return {
    support,
    application: {
      kind: "king_capture",
      original_attacker: originalKing,
      attacker: king,
      target,
      contact_source_ids: contact.source_ids,
      moves_uci: rows.map((move) => move.uci),
      source_ids: rows.map((move) => move.source_id),
      legal_inventory_complete: true
    }
  };
}
function kingCaptureKey(application) {
  const original = application.original_attacker, actor = application.attacker, target = application.target;
  return [
    original.position_id,
    original.side,
    original.role,
    original.square,
    actor.side,
    actor.role,
    actor.square,
    target.side,
    target.role,
    target.square
  ].join(":");
}
function decodeKingCaptureApplication(value, observations, path, comparison, originalTarget, count, piecesAt) {
  const isOriginal = (value2) => object(value2) && exactKeys(value2, ["position_id", "side", "role", "square"]) && piecesAt(0).some((piece) => samePiece(piece.original, value2));
  if (!object(value) || !exactKeys(value, [
    "kind",
    "original_attacker",
    "attacker",
    "target",
    "contact_source_ids",
    "moves_uci",
    "source_ids",
    "legal_inventory_complete"
  ]) || value.kind !== "king_capture" || !isOriginal(value.original_attacker) || value.original_attacker.role !== "king" || value.original_attacker.side === originalTarget.side || !object(value.attacker) || !exactKeys(value.attacker, ["position_id", "side", "role", "square"]) || !object(value.target) || !exactKeys(value.target, ["position_id", "side", "role", "square"]) || !ids(value.contact_source_ids) || !value.contact_source_ids.length || !ids(value.moves_uci) || !ids(value.source_ids) || value.legal_inventory_complete !== true)
    return;
  const base = path.positionIds.indexOf(comparison.after_position_id);
  if (base < 0 || count < base) return;
  const point = kingCaptureAt(
    observations,
    path,
    comparison.after_actor,
    originalTarget,
    value.original_attacker,
    count,
    piecesAt(count)
  );
  if (!point || !samePiece(point.application.attacker, value.attacker) || !samePiece(point.application.target, value.target) || !sameIds(value.contact_source_ids, point.application.contact_source_ids) || !sameIds(value.moves_uci, point.application.moves_uci) || !sameIds(value.source_ids, point.application.source_ids))
    return;
  for (let at = base; at <= count; at++) {
    const earlier = kingCaptureAt(
      observations,
      path,
      comparison.after_actor,
      originalTarget,
      value.original_attacker,
      at,
      piecesAt(at)
    );
    if (earlier && kingCaptureKey(earlier.application) === kingCaptureKey(point.application) && earlier.support.state === point.support.state && earlier.application.moves_uci.length > 0 === point.application.moves_uci.length > 0)
      return at === count ? value : void 0;
  }
  return;
}
function decodeLineContinuation(raw, observations) {
  const detail = raw.detail;
  if (!object(detail) || !exactKeys(
    detail,
    [
      "type",
      "scope",
      "line_id",
      "events",
      "capture_links",
      "other_target_gains",
      "support_comparisons",
      "text"
    ],
    [
      "open_loss_event_ids",
      "recovery_losses",
      "support_applications",
      "capture_exposures",
      "direct_support_recaptures"
    ]
  ) || detail.type !== "line_continuation" || detail.scope !== "observed_line" || raw.selection !== "context" || !ids(raw.line_ids) || raw.line_ids.length !== 1 || raw.line_ids[0] !== detail.line_id || !Array.isArray(detail.events) || !Array.isArray(detail.capture_links) || !Array.isArray(detail.other_target_gains) || !Array.isArray(detail.support_comparisons) || detail.open_loss_event_ids === void 0 !== (detail.recovery_losses === void 0) || typeof detail.text !== "string" || !detail.text.trim() || detail.text.length > 1e3)
    return;
  const path = observations.paths.find((path2) => path2.id === detail.line_id);
  const material = path?.lineSummary?.material;
  if (!path || path.kind === "history" || !material || !path.positionIds || detail.events.length !== material.events.length)
    return;
  const snapshots = /* @__PURE__ */ new Map();
  const at = (offset) => {
    if (!snapshots.has(offset)) snapshots.set(offset, trackedPieces(path, offset));
    return snapshots.get(offset);
  };
  const equalPiece = (value, expected) => expected === null ? value === null : object(value) && exactKeys(value, ["position_id", "side", "role", "square"]) && samePiece(value, expected);
  const origins = at(0);
  if (!origins) return;
  const isOrigin = (value) => origins.some((piece) => equalPiece(value, piece.original));
  const events = [];
  for (const [index, value] of detail.events.entries()) {
    const physical = material.events[index];
    const before = at(physical.ply_offset);
    const legal = observations.positions?.find((position) => position.id === path.positionIds[physical.ply_offset])?.legal_moves.moves.find((move) => move.uci === physical.move_uci);
    const actor = before?.find((piece) => piece.current.square === physical.from)?.original ?? null;
    const victim = physical.capture ? before?.find((piece) => piece.current.square === physical.capture.square)?.original ?? null : null;
    if (!object(value) || !exactKeys(value, [
      "id",
      "ply_offset",
      "occurrence_id",
      "source_id",
      "original_actor",
      "original_victim",
      "actor_end"
    ]) || !id(value.id) || value.ply_offset !== physical.ply_offset || value.occurrence_id !== physical.occurrence_id || !legal || value.source_id !== legal.source_id || !equalPiece(value.original_actor, actor) || !equalPiece(value.original_victim, victim) || !object(value.actor_end) || !exactKeys(value.actor_end, ["state", "position_id", "piece", "removed_by_event_id"]) || value.actor_end.position_id !== path.positionIds[path.moves.length])
      return;
    events.push(value);
  }
  if (new Set(events.map((event) => event.id)).size !== events.length) return;
  for (const event of events) {
    const current2 = event.original_actor && at(path.moves.length)?.find((piece) => samePiece(piece.original, event.original_actor));
    const removed = event.original_actor && events.find(
      (later) => later.ply_offset > event.ply_offset && later.original_victim && samePiece(later.original_victim, event.original_actor)
    );
    const expected = current2 ? "present" : removed ? "captured" : "unknown";
    if (event.actor_end.state !== expected || !equalPiece(event.actor_end.piece, current2?.current ?? null) || event.actor_end.removed_by_event_id !== (removed?.id ?? null))
      return;
  }
  const byId = new Map(events.map((event) => [event.id, event]));
  for (const link of detail.capture_links) {
    if (!object(link) || !exactKeys(link, ["loss_event_id", "capture_event_id", "elapsed_plies"]) || !id(link.loss_event_id) || !id(link.capture_event_id))
      return;
    const loss = byId.get(link.loss_event_id), capture = byId.get(link.capture_event_id);
    if (!loss?.original_actor || !loss.original_victim || !capture?.original_victim || capture.ply_offset <= loss.ply_offset || link.elapsed_plies !== capture.ply_offset - loss.ply_offset || !samePiece(loss.original_actor, capture.original_victim))
      return;
  }
  const removedCapturers = events.filter(
    (event) => event.original_victim && event.actor_end.state === "captured"
  );
  const captureLinks = detail.capture_links;
  if (captureLinks.length !== removedCapturers.length || removedCapturers.some(
    (loss) => !captureLinks.some(
      (link) => link.loss_event_id === loss.id && link.capture_event_id === loss.actor_end.removed_by_event_id
    )
  ))
    return;
  for (const link of detail.other_target_gains) {
    if (!object(link) || !exactKeys(link, ["loss_event_id", "gain_event_id"]) || !id(link.loss_event_id) || !id(link.gain_event_id))
      return;
    const loss = byId.get(link.loss_event_id), gain = byId.get(link.gain_event_id);
    if (!loss?.original_actor || !loss.original_victim || !gain?.original_victim || gain.ply_offset <= loss.ply_offset || gain.original_victim.side === loss.original_victim.side || samePiece(loss.original_actor, gain.original_victim))
      return;
    const interval = material.events.filter(
      (event) => event.ply_offset >= loss.ply_offset && event.ply_offset < gain.ply_offset
    );
    const sign = loss.original_victim.side === path.lineSummary.perspective ? 1 : -1;
    if (!interval.length || interval.some((event) => event.balance_cp * sign >= 0)) return;
  }
  if (detail.open_loss_event_ids !== void 0) {
    if (!ids(detail.open_loss_event_ids) || !Array.isArray(detail.recovery_losses) || detail.open_loss_event_ids.some((id2) => {
      const loss = byId.get(id2);
      return !loss?.original_actor || !continuationLossIsOpen(path, loss);
    }))
      return;
    if (new Set(detail.open_loss_event_ids.map((id2) => byId.get(id2).original_victim.side)).size !== detail.open_loss_event_ids.length)
      return;
    const gainLinks = detail.other_target_gains;
    const expected = [
      ...captureLinks.map((link) => [link.loss_event_id, link.capture_event_id]),
      ...gainLinks.map((link) => [link.loss_event_id, link.gain_event_id])
    ].flatMap(([lossId, recoveryId]) => {
      const recovery = byId.get(recoveryId);
      return recovery.actor_end.removed_by_event_id ? [JSON.stringify([lossId, recoveryId, recovery.actor_end.removed_by_event_id])] : [];
    });
    const received = detail.recovery_losses.map((link) => {
      if (!object(link) || !exactKeys(link, ["loss_event_id", "recovery_event_id", "later_loss_event_id"]) || !id(link.loss_event_id) || !id(link.recovery_event_id) || !id(link.later_loss_event_id))
        return null;
      return JSON.stringify([link.loss_event_id, link.recovery_event_id, link.later_loss_event_id]);
    });
    if (received.some((link) => link === null) || new Set(received).size !== received.length || !sameIds(received, expected))
      return;
  }
  const supportState = (actor, target, offset) => continuationSupportAt(observations, path, actor, target, offset, at(offset));
  for (const comparison of detail.support_comparisons) {
    if (!object(comparison) || !exactKeys(comparison, [
      "id",
      "kind",
      "state",
      "before_actor",
      "after_actor",
      "before_position_id",
      "after_position_id",
      "trigger_occurrence_ids",
      "targets"
    ]) || !id(comparison.id) || !["actor_continuation", "replacement_after_capture"].includes(String(comparison.kind)) || !["complete", "unknown"].includes(String(comparison.state)) || !isOrigin(comparison.before_actor) || !isOrigin(comparison.after_actor) || !id(comparison.before_position_id) || !id(comparison.after_position_id) || !ids(comparison.trigger_occurrence_ids) || !comparison.trigger_occurrence_ids.length || !comparison.trigger_occurrence_ids.every((occurrence) => path.occurrenceIds.includes(occurrence)) || !Array.isArray(comparison.targets))
      return;
    const before = path.positionIds.indexOf(comparison.before_position_id), after = path.positionIds.indexOf(comparison.after_position_id);
    if (before < 0 || after < before) return;
    const complete = [before, after].every(
      (offset) => observations.positions?.find((position) => position.id === path.positionIds[offset])?.controls.complete
    );
    if (comparison.state !== (complete ? "complete" : "unknown")) return;
    if (comparison.kind === "actor_continuation" && (!samePiece(comparison.before_actor, comparison.after_actor) || after !== path.moves.length || !(before === 0 && comparison.before_actor.square === path.moves[0].uci.slice(0, 2) && sameIds(comparison.trigger_occurrence_ids, [path.occurrenceIds[0]]) || events.some(
      (event) => event.original_actor && samePiece(event.original_actor, comparison.before_actor) && before === event.ply_offset + 1 && sameIds(comparison.trigger_occurrence_ids, [event.occurrence_id])
    ))))
      return;
    if (comparison.kind === "replacement_after_capture" && !detail.capture_links.some((value) => {
      const link = value;
      const loss = byId.get(link.loss_event_id), recovery = byId.get(link.capture_event_id);
      return loss.original_victim && recovery.original_actor && loss.original_victim.side === recovery.original_actor.side && samePiece(loss.original_victim, comparison.before_actor) && samePiece(recovery.original_actor, comparison.after_actor) && before === loss.ply_offset && after === recovery.ply_offset + 1 && sameIds(comparison.trigger_occurrence_ids, [loss.occurrence_id, recovery.occurrence_id]);
    }))
      return;
    const expectedTargets = origins.filter(
      (piece) => piece.original.side === comparison.before_actor.side && piece.original.role !== "king" && !samePiece(piece.original, comparison.before_actor) && !samePiece(piece.original, comparison.after_actor)
    ).filter(
      (piece) => supportState(comparison.before_actor, piece.original, before).state === "present" || supportState(comparison.after_actor, piece.original, after).state === "present"
    );
    if (comparison.targets.length !== expectedTargets.length) return;
    for (const target of comparison.targets) {
      if (!object(target) || !exactKeys(target, ["original_target", "before", "after"]) || !isOrigin(target.original_target) || !expectedTargets.some(
        (piece) => samePiece(piece.original, target.original_target)
      ))
        return;
      for (const [key, actor, offset] of [
        ["before", comparison.before_actor, before],
        ["after", comparison.after_actor, after]
      ]) {
        const value = target[key], expected = supportState(actor, target.original_target, offset);
        if (!object(value) || !exactKeys(value, ["state", "source_ids"]) || !ids(value.source_ids) || value.state !== expected.state || !sameIds(value.source_ids, expected.source_ids))
          return;
      }
    }
    if (new Set(
      comparison.targets.map((target) => JSON.stringify(target.original_target))
    ).size !== comparison.targets.length)
      return;
  }
  if ([detail.capture_links, detail.other_target_gains, detail.support_comparisons].some(
    (values) => new Set(values.map((value) => JSON.stringify(value))).size !== values.length
  ))
    return;
  if (detail.support_applications !== void 0) {
    if (!Array.isArray(detail.support_applications) || detail.support_applications.length > 1e4 || new Set(detail.support_applications.map((value) => JSON.stringify(value))).size !== detail.support_applications.length)
      return;
    for (const value of detail.support_applications) {
      if (!object(value) || !exactKeys(value, [
        "requirement_id",
        "comparison_id",
        "original_target",
        "original_provider",
        "ply_count",
        "position_id",
        "preceding_occurrence_id",
        "support",
        "application"
      ]) || !isOrigin(value.original_target) || !isOrigin(value.original_provider) || !integer(value.ply_count, 1, path.moves.length) || value.position_id !== path.positionIds[value.ply_count] || value.preceding_occurrence_id !== path.occurrenceIds[value.ply_count - 1] || !object(value.support) || !exactKeys(value.support, ["state", "source_ids"]) || value.support.state !== "present" || !ids(value.support.source_ids))
        return;
      const comparison = detail.support_comparisons.find((comparison2) => comparison2.id === value.comparison_id);
      if (!comparison || (comparison.kind === "replacement_after_capture" ? !id(value.requirement_id) : value.requirement_id !== null) || !samePiece(comparison.after_actor, value.original_provider) || !comparison.targets.some(
        (target) => samePiece(target.original_target, value.original_target)
      ))
        return;
      const application = decodeKingCaptureApplication(
        value.application,
        observations,
        path,
        comparison,
        value.original_target,
        value.ply_count,
        (count) => at(count) ?? []
      );
      const support = continuationSupportAt(
        observations,
        path,
        value.original_provider,
        value.original_target,
        value.ply_count,
        at(value.ply_count)
      );
      if (!application || application.moves_uci.length || support.state !== "present" || !sameIds(value.support.source_ids, support.source_ids))
        return;
    }
  }
  const current = (original, count) => at(count)?.find((piece) => samePiece(piece.original, original))?.current ?? null;
  for (const name of ["capture_exposures", "direct_support_recaptures"]) {
    const values = detail[name];
    if (values !== void 0 && (!Array.isArray(values) || values.length > 1e4 || new Set(values.map((value) => JSON.stringify(value))).size !== values.length))
      return;
  }
  for (const value of detail.capture_exposures ?? []) {
    if (!object(value) || !exactKeys(value, [
      "kind",
      "prefix_moves_uci",
      "occurrence_id",
      "before_position_id",
      "position_id",
      "original_attacker",
      "attacker",
      "original_target",
      "target",
      "vacated_blockers",
      "ray_source_id",
      "control_source_ids",
      "moves_uci",
      "source_ids",
      "legal_inventory_complete"
    ]) || value.kind !== "capture_exposure" || !Array.isArray(value.prefix_moves_uci) || !integer(value.prefix_moves_uci.length, 1, path.moves.length) || !value.prefix_moves_uci.every((move, index) => move === path.moves[index].uci) || !isOrigin(value.original_attacker) || !isOrigin(value.original_target) || !Array.isArray(value.vacated_blockers) || !value.vacated_blockers.length || !ids(value.control_source_ids) || !ids(value.moves_uci) || !ids(value.source_ids) || value.legal_inventory_complete !== true)
      return;
    const count = value.prefix_moves_uci.length;
    const before = observations.positions?.find((position) => position.id === path.positionIds[count - 1]);
    const after = observations.positions?.find((position) => position.id === path.positionIds[count]);
    if (!before || !after) return;
    const attacker = current(value.original_attacker, count), target = current(value.original_target, count);
    const oldAttacker = current(value.original_attacker, count - 1), oldTarget = current(value.original_target, count - 1);
    const ray2 = before.rays.lines.find((ray3) => ray3.source_id === value.ray_source_id);
    if (!attacker || !target || !oldAttacker || !oldTarget || !ray2 || value.occurrence_id !== path.occurrenceIds[count - 1] || value.before_position_id !== before.id || value.position_id !== after.id || !equalPiece(value.attacker, attacker) || !equalPiece(value.target, target) || !equalPiece({ ...oldAttacker, position_id: after.id }, attacker) || !equalPiece({ ...oldTarget, position_id: after.id }, target) || ray2.piece.side !== attacker.side || ray2.piece.role !== attacker.role || ray2.piece.square !== attacker.square || attacker.side !== parseFen(after.fen).unwrap().turn || target.side !== parseFen(before.fen).unwrap().turn || target.role === "king" || !after.legal_moves.complete)
      return;
    const targetIndex = ray2.occupants.findIndex(
      (piece) => piece.side === target.side && piece.role === target.role && piece.square === target.square
    );
    const blockers = ray2.occupants.slice(0, targetIndex);
    if (targetIndex < 1 || blockers.length !== value.vacated_blockers.length || !value.vacated_blockers.every(
      (blocker, index) => object(blocker) && exactKeys(blocker, ["original", "before"]) && isOrigin(blocker.original) && equalPiece(blocker.before, current(blocker.original, count - 1)) && object(blocker.before) && blocker.before.side === blockers[index].side && blocker.before.role === blockers[index].role && blocker.before.square === blockers[index].square && !at(count)?.some((piece) => piece.current.square === blockers[index].square)
    ))
      return;
    const controls = continuationSupportAt(
      observations,
      path,
      value.original_attacker,
      value.original_target,
      count,
      at(count)
    );
    const captures = after.legal_moves.moves.filter(
      (move) => move.uci.slice(0, 2) === attacker.square && move.captured_square === target.square
    );
    if (controls.state !== "present" || !sameIds(value.control_source_ids, controls.source_ids) || !captures.length || !sameIds(
      value.moves_uci,
      captures.map((move) => move.uci)
    ) || !sameIds(
      value.source_ids,
      captures.map((move) => move.source_id)
    ))
      return;
  }
  for (const value of detail.direct_support_recaptures ?? []) {
    if (!object(value) || !exactKeys(value, [
      "kind",
      "requirement_id",
      "comparison_id",
      "original_provider",
      "original_target",
      "original_capturer",
      "ply_count",
      "position_id",
      "provider",
      "target",
      "capturer",
      "support",
      "loss_event_id",
      "recapture_event_id",
      "loss_occurrence_id",
      "recapture_occurrence_id",
      "elapsed_plies"
    ]) || value.kind !== "direct_support_recapture" || !id(value.requirement_id) || !isOrigin(value.original_provider) || !isOrigin(value.original_target) || !isOrigin(value.original_capturer) || !integer(value.ply_count, 1, path.moves.length) || !object(value.support) || !exactKeys(value.support, ["state", "source_ids"]) || value.support.state !== "present" || !ids(value.support.source_ids))
      return;
    const comparison = detail.support_comparisons.find((row) => row.id === value.comparison_id);
    const loss = events.find((event) => event.id === value.loss_event_id), recovery = events.find((event) => event.id === value.recapture_event_id);
    const count = value.ply_count;
    if (!comparison || comparison.kind !== "replacement_after_capture" || !samePiece(comparison.after_actor, value.original_provider) || !comparison.targets.some(
      (target2) => samePiece(target2.original_target, value.original_target)
    ) || count < path.positionIds.indexOf(comparison.after_position_id) || !loss || !recovery || loss.ply_offset !== count || recovery.ply_offset <= count || !equalPiece(loss.original_actor, value.original_capturer) || !equalPiece(loss.original_victim, value.original_target) || !equalPiece(recovery.original_actor, value.original_provider) || !equalPiece(recovery.original_victim, value.original_capturer) || value.loss_occurrence_id !== loss.occurrence_id || value.recapture_occurrence_id !== recovery.occurrence_id || value.elapsed_plies !== recovery.ply_offset - count || !detail.capture_links.some(
      (link) => link.loss_event_id === loss.id && link.capture_event_id === recovery.id
    ) || value.position_id !== path.positionIds[count] || !equalPiece(value.provider, current(value.original_provider, count)) || !equalPiece(value.target, current(value.original_target, count)) || !equalPiece(value.capturer, current(value.original_capturer, count)))
      return;
    const provider = current(value.original_provider, count), target = current(value.original_target, count), capturer = current(value.original_capturer, count + 1);
    const support = continuationSupportAt(
      observations,
      path,
      value.original_provider,
      value.original_target,
      count,
      at(count)
    );
    if (!provider || !target || !capturer || capturer.square !== target.square || support.state !== "present" || !sameIds(value.support.source_ids, support.source_ids) || !Array.from({ length: recovery.ply_offset - count + 1 }, (_, index) => count + index).every(
      (at2) => equalPiece(current(value.original_provider, at2), {
        ...provider,
        position_id: path.positionIds[at2]
      })
    ) || !Array.from({ length: recovery.ply_offset - count }, (_, index) => count + index + 1).every(
      (at2) => equalPiece(current(value.original_capturer, at2), {
        ...capturer,
        position_id: path.positionIds[at2]
      })
    ))
      return;
  }
  return detail;
}
function validContinuationComparison(candidate, candidates, observations) {
  const detail = candidate.detail;
  if (!exactKeys(detail, ["type", "scope", "continuation_candidate_ids", "differences", "text"]) || detail.scope !== "observed_line_pair" || candidate.selection !== "context" || candidate.lineIds.length !== 2 || !ids(detail.continuation_candidate_ids) || detail.continuation_candidate_ids.length !== 2 || !Array.isArray(detail.differences) || !detail.differences.length || detail.differences.length > 1e4 || typeof detail.text !== "string" || !detail.text.trim() || detail.text.length > 1e3)
    return false;
  const profiles = detail.continuation_candidate_ids.map((id2) => candidates.get(id2)).map((value) => value && lineContinuationDetail(value));
  if (profiles.some((value, index) => !value || value.line_id !== candidate.lineIds[index])) return false;
  const paths = candidate.lineIds.map((id2) => observations.paths.find((path) => path.id === id2));
  if (paths[0].startFen !== paths[1].startFen || paths[0].positionIds?.[0] !== paths[1].positionIds?.[0])
    return false;
  const originalPieces = trackedPieces(paths[0], 0);
  const isOriginal = (value) => object(value) && exactKeys(value, ["position_id", "side", "role", "square"]) && originalPieces.some((piece) => samePiece(piece.original, value));
  for (const difference of detail.differences) {
    if (!object(difference) || !object(difference.left) || !object(difference.right)) return false;
    const sides = [difference.left, difference.right];
    if (difference.kind === "recapturer_support") {
      if (!exactKeys(difference, [
        "kind",
        "original_subject",
        "original_target",
        "matched_support_comparison_ids",
        "left",
        "right"
      ]) || !isOriginal(difference.original_subject) || !isOriginal(difference.original_target) || difference.original_subject.side !== difference.original_target.side || difference.original_target.role === "king" || samePiece(difference.original_subject, difference.original_target) || !ids(difference.matched_support_comparison_ids) || difference.matched_support_comparison_ids.length !== 2)
        return false;
      const anchorIds = difference.matched_support_comparison_ids;
      const anchors = profiles.map(
        (profile, index) => profile.support_comparisons.find((row) => row.id === anchorIds[index])
      );
      if (anchors.some((row) => !row || row.kind !== "replacement_after_capture") || !samePiece(anchors[0].before_actor, anchors[1].before_actor) || !anchors.some(
        (row) => samePiece(row.after_actor, difference.original_subject)
      ))
        return false;
      const counts = anchors.map((row, index) => paths[index].positionIds.indexOf(row.after_position_id));
      if (counts[0] % 2 !== counts[1] % 2) return false;
      const transitions = [];
      for (const [index, side] of sides.entries()) {
        if (!exactKeys(side, ["before", "after"])) return false;
        const states = [];
        for (const [step, point] of [side.before, side.after].entries()) {
          const count = counts[index] - 1 + step;
          if (!object(point) || !exactKeys(point, [
            "line_id",
            "ply_count",
            "position_id",
            "preceding_occurrence_id",
            "support"
          ]) || count < 1 || point.line_id !== paths[index].id || point.ply_count !== count || point.position_id !== paths[index].positionIds[count] || point.preceding_occurrence_id !== paths[index].occurrenceIds[count - 1] || !object(point.support) || !exactKeys(point.support, ["state", "source_ids"]) || !ids(point.support.source_ids))
            return false;
          const actual = continuationSupportAt(
            observations,
            paths[index],
            difference.original_subject,
            difference.original_target,
            count,
            trackedPieces(paths[index], count)
          );
          if (actual.state === "unknown" || point.support.state !== actual.state || !sameIds(point.support.source_ids, actual.source_ids))
            return false;
          states.push(actual.state);
        }
        transitions.push(states);
      }
      if (!transitions.flat().includes("present") || !transitions.some((states) => states[0] !== states[1]) || transitions[0].join(":") === transitions[1].join(":"))
        return false;
      continue;
    }
    if (sides.some(
      (side, index) => !integer(side.ply_count, 1, paths[index].moves.length) || side.line_id !== paths[index].id || side.position_id !== paths[index].positionIds?.[side.ply_count] || side.preceding_occurrence_id !== paths[index].occurrenceIds[side.ply_count - 1]
    ))
      return false;
    if (difference.kind !== "loss_followup" && sides[0].ply_count % 2 !== sides[1].ply_count % 2)
      return false;
    const pointKeys = ["line_id", "ply_count", "position_id", "preceding_occurrence_id"];
    if (difference.kind === "loss_followup") {
      if (!exactKeys(
        difference,
        ["kind", "original_actor", "original_victim", "left", "right"],
        ["shared_attackers"]
      ) || !isOriginal(difference.original_actor) || !isOriginal(difference.original_victim))
        return false;
      const signatures = [];
      for (const [index, side] of sides.entries()) {
        if (!exactKeys(side, [
          ...pointKeys,
          "loss_event_id",
          "loss_ply_offset",
          "observed_followup_plies",
          "capturer_end",
          "capturer_removal_state",
          "capturer_removal_event_id",
          "other_target_gain_state",
          "other_target_gain_event_ids"
        ]) || side.ply_count !== paths[index].moves.length || !id(side.loss_event_id) || !ids(side.other_target_gain_event_ids))
          return false;
        const profile = profiles[index], loss = profile.events.find((event) => event.id === side.loss_event_id);
        if (!loss?.original_actor || !loss.original_victim || !samePiece(loss.original_actor, difference.original_actor) || !samePiece(loss.original_victim, difference.original_victim) || side.loss_ply_offset !== loss.ply_offset || side.observed_followup_plies !== paths[index].moves.length - loss.ply_offset - 1 || JSON.stringify(side.capturer_end) !== JSON.stringify(loss.actor_end) || loss.actor_end.state === "unknown" || profile.events.some(
          (event, offset) => !event.original_actor || paths[index].lineSummary.material.events[offset].capture && !event.original_victim
        ))
          return false;
        const removals = profile.capture_links.filter((link) => link.loss_event_id === loss.id).map((link) => link.capture_event_id);
        const gains = profile.other_target_gains.filter((link) => link.loss_event_id === loss.id).map((link) => link.gain_event_id);
        if (removals.length > 1 || side.capturer_removal_event_id !== (removals[0] ?? null) || side.capturer_removal_state !== (removals.length ? "observed" : "not_observed_through_line_end") || side.other_target_gain_state !== (gains.length ? "observed" : "not_observed_through_line_end") || !sameIds(side.other_target_gain_event_ids, gains) || loss.actor_end.state === "captured" !== removals.length > 0 || loss.actor_end.removed_by_event_id !== (removals[0] ?? null))
          return false;
        const physical = (ids2) => ids2.map((id2) => {
          const event = profile.events.find((event2) => event2.id === id2);
          return JSON.stringify([event.original_actor, event.original_victim]);
        }).sort();
        signatures.push(JSON.stringify([physical(removals), physical(gains)]));
      }
      if (signatures[0] === signatures[1]) return false;
      if (difference.shared_attackers !== void 0) {
        const shared = difference.shared_attackers;
        if (!Array.isArray(shared) || shared.length > originalPieces.length || new Set(shared.map((row) => JSON.stringify(row))).size !== shared.length)
          return false;
        let common = 0;
        while (common < paths[0].moves.length && paths[0].occurrenceIds[common] === paths[1].occurrenceIds[common])
          common++;
        const at = paths.map((path) => trackedPieces(path, common) ?? []);
        for (const row of shared) {
          if (!object(row) || !exactKeys(row, ["original_actor", "actor", "position_id", "ply_count", "left", "right"]) || !isOriginal(row.original_actor) || !object(row.actor) || !exactKeys(row.actor, ["position_id", "side", "role", "square"]) || row.ply_count !== common || common >= Math.min(...paths.map((path) => path.moves.length)) || row.position_id !== paths[0].positionIds[common])
            return false;
          const current = at[0].find(
            (piece) => samePiece(piece.original, row.original_actor)
          )?.current;
          if (!current || !samePiece(current, row.actor)) return false;
          const targets = [];
          for (const [index, key] of ["left", "right"].entries()) {
            const branch = row[key], profile = profiles[index];
            if (!object(branch) || !exactKeys(branch, ["event_id", "target", "source_ids"]) || !id(branch.event_id) || !object(branch.target) || !exactKeys(branch.target, ["position_id", "side", "role", "square"]) || !ids(branch.source_ids) || !branch.source_ids.length)
              return false;
            const event = continuationRecoveries(profile, sides[index].loss_event_id).filter(
              (event2) => event2.ply_offset >= common && event2.original_actor && samePiece(event2.original_actor, row.original_actor)
            )[0];
            const target = event?.original_victim && at[index].find((piece) => samePiece(piece.original, event.original_victim))?.current;
            if (!event?.original_victim || event.id !== branch.event_id || !target || target.side === current.side || !samePiece(target, branch.target))
              return false;
            targets.push(event.original_victim);
            for (let offset = common; offset <= event.ply_offset; offset++) {
              const pieces = trackedPieces(paths[index], offset) ?? [];
              for (const [original, expected] of [
                [row.original_actor, current],
                [event.original_victim, target]
              ]) {
                const actual = pieces.find((piece) => samePiece(piece.original, original))?.current;
                if (!actual || actual.side !== expected.side || actual.role !== expected.role || actual.square !== expected.square)
                  return false;
              }
            }
            const control = continuationSupportAt(
              observations,
              paths[index],
              row.original_actor,
              event.original_victim,
              common,
              at[index]
            );
            if (control.state !== "present" || !sameIds(branch.source_ids, control.source_ids)) return false;
          }
          if (samePiece(targets[0], targets[1])) return false;
        }
        if (new Set(shared.map((row) => JSON.stringify(row.original_actor))).size !== shared.length)
          return false;
      }
    } else if (difference.kind === "capture_timing" || difference.kind === "legal_capture_availability") {
      if (!exactKeys(
        difference,
        ["kind", "original_actor", "original_victim", "left", "right"],
        difference.kind === "legal_capture_availability" ? ["matched_capture_event_ids", "matched_support_comparison_ids"] : []
      ) || !isOriginal(difference.original_actor) || !isOriginal(difference.original_victim))
        return false;
      const events = sides.map(
        (side, index) => profiles[index].events.find((event) => event.ply_offset + 1 === side.ply_count)
      );
      const supportAnchors = difference.matched_support_comparison_ids;
      if (!supportAnchors && (events.some((event) => !event?.original_actor || !event.original_victim) || !samePiece(events[0].original_actor, events[1].original_actor) || !samePiece(events[0].original_victim, events[1].original_victim)))
        return false;
      if (supportAnchors !== void 0) {
        if (difference.matched_capture_event_ids !== void 0 || !ids(supportAnchors) || supportAnchors.length !== 2)
          return false;
        const anchors = profiles.map(
          (profile, index) => profile.support_comparisons.find((row) => row.id === supportAnchors[index])
        );
        if (anchors.some(
          (row, index) => !row || row.kind !== "replacement_after_capture" || row.after_position_id !== sides[index].position_id
        ) || !samePiece(anchors[0].before_actor, anchors[1].before_actor) || !profiles.some(
          (profile, index) => profile.capture_exposures?.some(
            (exposure) => exposure.position_id === sides[index].position_id && samePiece(exposure.original_attacker, difference.original_actor) && samePiece(exposure.original_target, difference.original_victim)
          )
        ))
          return false;
      }
      if (difference.kind === "capture_timing") {
        if (sides[0].ply_count === sides[1].ply_count || !samePiece(events[0].original_actor, difference.original_actor) || !samePiece(events[0].original_victim, difference.original_victim) || sides.some(
          (side, index) => !exactKeys(side, [...pointKeys, "event_id", "source_id"]) || side.event_id !== events[index].id || side.source_id !== events[index].source_id
        ))
          return false;
      } else {
        if (!supportAnchors && (!ids(difference.matched_capture_event_ids) || !sameIds(
          difference.matched_capture_event_ids,
          events.map((event) => event.id)
        )) || sides[0].available === sides[1].available)
          return false;
        for (const [index, side] of sides.entries()) {
          if (!exactKeys(side, [
            ...pointKeys,
            "available",
            "moves_uci",
            "source_ids",
            "position_occurrence_id",
            "legal_inventory_complete"
          ]) || typeof side.available !== "boolean" || !ids(side.moves_uci) || !ids(side.source_ids) || side.legal_inventory_complete !== true)
            return false;
          const position = observations.positions?.find((position2) => position2.id === side.position_id);
          const pieces = trackedPieces(paths[index], side.ply_count);
          const actor = pieces?.find(
            (piece) => samePiece(piece.original, difference.original_actor)
          )?.current;
          const victim = pieces?.find(
            (piece) => samePiece(piece.original, difference.original_victim)
          )?.current;
          if (!position?.legal_moves.complete || side.position_occurrence_id !== position.premise_id || !actor || !victim)
            return false;
          const rows = position.legal_moves.moves.filter(
            (move) => move.uci.slice(0, 2) === actor.square && move.captured_square === victim.square
          );
          if (side.available !== rows.length > 0 || !sameIds(
            side.moves_uci,
            rows.map((move) => move.uci)
          ) || !sameIds(
            side.source_ids,
            rows.map((move) => move.source_id)
          ))
            return false;
        }
      }
    } else if (difference.kind === "replacement_support" || difference.kind === "root_actor_support") {
      if (!exactKeys(difference, [
        "kind",
        "original_subject",
        "original_target",
        "relation",
        "left",
        "right"
      ]) || !isOriginal(difference.original_subject) || !isOriginal(difference.original_target))
        return false;
      const supportStates = [];
      const applications = [];
      const comparisons = [];
      for (const [index, side] of sides.entries()) {
        if (!exactKeys(
          side,
          [...pointKeys, "original_provider", "support", "comparison_id", "trigger_occurrence_ids"],
          ["application", "target_capture_event_id", "direct_recapture"]
        ) || !isOriginal(side.original_provider) || !ids(side.trigger_occurrence_ids) || !object(side.support) || !exactKeys(side.support, ["state", "source_ids"]) || !ids(side.support.source_ids))
          return false;
        const comparison = profiles[index].support_comparisons.find((row) => row.id === side.comparison_id);
        if (!comparison || comparison.kind !== (difference.kind === "root_actor_support" ? "actor_continuation" : "replacement_after_capture") || !samePiece(comparison.before_actor, difference.original_subject) || !samePiece(comparison.after_actor, side.original_provider) || side.application === void 0 && side.target_capture_event_id === void 0 && comparison.after_position_id !== side.position_id || !sameIds(comparison.trigger_occurrence_ids, side.trigger_occurrence_ids) || difference.kind === "root_actor_support" && comparison.before_position_id !== paths[index].positionIds?.[0])
          return false;
        comparisons.push(comparison);
        if (side.target_capture_event_id !== void 0) {
          const event = profiles[index].events.find((event2) => event2.id === side.target_capture_event_id);
          if (difference.kind !== "replacement_support" || side.application !== void 0 || !event?.original_victim || !event.original_actor || event.ply_offset !== side.ply_count || !samePiece(event.original_victim, difference.original_target) || event.ply_offset < paths[index].positionIds.indexOf(comparison.after_position_id))
            return false;
        }
        if (side.direct_recapture !== void 0) {
          if (!object(side.direct_recapture) || !exactKeys(side.direct_recapture, ["loss_event_id", "recapture_event_id"]) || side.target_capture_event_id !== side.direct_recapture.loss_event_id || !profiles[index].direct_support_recaptures?.some(
            (use) => use.comparison_id === comparison.id && use.loss_event_id === side.direct_recapture.loss_event_id && use.recapture_event_id === side.direct_recapture.recapture_event_id
          ))
            return false;
        }
        const snapshots = /* @__PURE__ */ new Map();
        const piecesAt = (at) => {
          if (!snapshots.has(at)) snapshots.set(at, trackedPieces(paths[index], at) ?? []);
          return snapshots.get(at);
        };
        if (side.application !== void 0) {
          const application = decodeKingCaptureApplication(
            side.application,
            observations,
            paths[index],
            comparison,
            difference.original_target,
            side.ply_count,
            piecesAt
          );
          if (!application) return false;
          applications.push(application);
        }
        const support = continuationSupportAt(
          observations,
          paths[index],
          side.original_provider,
          difference.original_target,
          side.ply_count,
          piecesAt(side.ply_count)
        );
        if (support.state === "unknown" || side.support.state !== support.state || !sameIds(side.support.source_ids, support.source_ids))
          return false;
        supportStates.push(support);
      }
      const sameState = supportStates[0].state === supportStates[1].state;
      if (sides.some((side) => side.target_capture_event_id !== void 0)) {
        const losses = sides.map(
          (side, index) => profiles[index].events.find((event) => event.id === side.target_capture_event_id)
        );
        if (!losses[0]?.original_actor || !losses[1]?.original_actor || !samePiece(losses[0].original_actor, losses[1].original_actor) || !sides.some((side) => side.direct_recapture))
          return false;
      }
      if (!comparisons.some(
        (comparison) => comparison.targets.some(
          (target) => samePiece(target.original_target, difference.original_target)
        )
      ) || applications.length > 0 && (applications.length !== 2 || sameState || applications.some(
        (application, index) => supportStates[index].state === "present" && application.moves_uci.length > 0
      ) || !samePiece(applications[0].original_attacker, applications[1].original_attacker) || applications[0].attacker.square !== applications[1].attacker.square || applications[0].attacker.role !== applications[1].attacker.role || applications[0].target.square !== applications[1].target.square || applications[0].target.role !== applications[1].target.role || applications[0].moves_uci.length > 0 === applications[1].moves_uci.length > 0) || !supportStates.some((state) => state.state === "present") || sameState && samePiece(
        sides[0].original_provider,
        sides[1].original_provider
      ) || difference.relation !== (sameState ? "preserved_with_different_provider" : "different_support"))
        return false;
    } else return false;
  }
  return new Set(detail.differences.map((value) => JSON.stringify(value))).size === detail.differences.length;
}
function factPoint(value) {
  if (!object(value)) return false;
  if (value.kind === "ply") return exactKeys(value, ["kind", "ply_count"]) && factPly(value.ply_count);
  return value.kind === "event" && exactKeys(value, ["kind", "event", "ordinal", "phase", "from_ply", "through_ply"], ["actor", "target", "square"]) && ["move", "capture", "promotion", "check", "castling"].includes(String(value.event)) && factPly(value.ordinal) && value.ordinal > 0 && ["before", "after"].includes(String(value.phase)) && factPly(value.from_ply) && factPly(value.through_ply) && value.through_ply > value.from_ply && (value.actor === void 0 || factPiece(value.actor)) && (value.target === void 0 || value.event === "capture" && factPiece(value.target)) && (value.square === void 0 || value.event === "move" && typeof value.square === "string" && /^[a-h][1-8]$/.test(value.square));
}
function factValues(kind) {
  switch (kind) {
    case "presence":
      return ["present", "removed"];
    case "location":
      return ["removed", ...Array.from({ length: 64 }, (_, i) => makeSquare(i))];
    case "role":
      return ["pawn", "knight", "bishop", "rook", "queen", "king", "removed"];
    case "control":
      return ["present", "absent", "actor_removed"];
    case "support":
      return ["present", "absent", "actor_removed", "target_removed"];
    case "legal_move":
      return ["legal", "illegal", "not_turn", "actor_removed"];
    case "legal_capture":
      return ["legal", "illegal", "not_turn", "actor_removed", "target_removed"];
    case "check":
      return ["present", "absent"];
    case "pawn_property":
      return ["true", "false", "not_pawn", "actor_removed"];
    case "pawn_advance":
      return ["present", "absent", "not_pawn", "actor_removed"];
    case "file_occupancy":
      return ["open", "white_pawns_only", "black_pawns_only", "both_sides"];
    case "direct_support_use":
      return ["true", "false"];
    default:
      return [];
  }
}
function factPredicate(value) {
  if (!object(value) || typeof value.kind !== "string") return false;
  const fields = ["presence", "location", "role"].includes(value.kind) ? ["subject"] : ["control", "legal_move", "pawn_advance"].includes(value.kind) ? ["subject", "square"] : ["support", "legal_capture", "direct_support_use"].includes(value.kind) ? ["subject", "target"] : value.kind === "check" ? ["side"] : value.kind === "pawn_property" ? ["subject", "property"] : value.kind === "file_occupancy" ? ["property"] : void 0;
  if (!fields || !exactKeys(value, ["kind", ...fields], value.kind === "legal_move" ? ["property"] : []))
    return false;
  if (value.subject !== void 0 && !factPiece(value.subject) || value.target !== void 0 && !factPiece(value.target) || value.square !== void 0 && (typeof value.square !== "string" || !/^[a-h][1-8]$/.test(value.square)) || value.side !== void 0 && !["white", "black"].includes(String(value.side)))
    return false;
  if (value.kind === "legal_move" && value.property !== void 0 && !["queen", "rook", "bishop", "knight"].includes(String(value.property)))
    return false;
  if (value.kind === "pawn_property" && !["passed", "isolated", "doubled"].includes(String(value.property)))
    return false;
  if (value.kind === "file_occupancy" && (typeof value.property !== "string" || !/^[a-h]$/.test(value.property)))
    return false;
  if (factPiece(value.subject) && factPiece(value.target)) {
    if (value.kind === "legal_capture") return value.subject.side !== value.target.side;
    return value.subject.side === value.target.side && (value.subject.role !== value.target.role || value.subject.square !== value.target.square);
  }
  return true;
}
function factRequirementValid(value, prior) {
  if (value.kind === "fact") {
    if (!object(value.path) || !exactKeys(value.path, ["binding", "source", "extend"]) || !proposalId(value.path.binding) || typeof value.path.extend !== "boolean" || !object(value.path.source) || !factPredicate(value.predicate) || !factPoint(value.at) || value.through !== void 0 && (!factPoint(value.through) || value.expected === void 0) || value.expected !== void 0 && !factValues(value.predicate.kind).includes(String(value.expected)))
      return false;
    const source = value.path.source;
    if (source.kind === "declared")
      return exactKeys(source, ["kind", "moves_uci"]) && factMoves(source.moves_uci);
    if (source.kind === "comparison")
      return exactKeys(source, ["kind", "requirement_id", "arm"]) && ["reference", "alternative"].includes(String(source.arm)) && prior.some((row) => row.kind === "compare_moves" && row.id === source.requirement_id);
    return source.kind === "premise" && exactKeys(source, ["kind", "inquiry_id", "premise_id"]) && [source.inquiry_id, source.premise_id].every(
      (v) => typeof v === "string" && v.length > 0 && v.length <= 512
    );
  }
  if (value.kind === "fact_comparison") {
    const left = prior.find((row) => row.id === value.left_requirement_id);
    const right = prior.find((row) => row.id === value.right_requirement_id);
    return left?.kind === "fact" && right?.kind === "fact" && left !== right && !left.through && !right.through && (["same", "different"].includes(String(value.relation)) ? left.predicate.kind === right.predicate.kind : ["before", "after", "same_time"].includes(String(value.relation)) && left.path.binding === right.path.binding);
  }
  return value.kind === "fact_group" && ["all", "any"].includes(String(value.mode)) && ids(value.members) && value.members.length > 0 && value.members.length <= 600 && value.members.every(
    (member) => prior.some(
      (row) => row.id === member && (row.kind === "fact_comparison" || row.kind === "fact_group" || row.kind === "fact" && row.expected !== void 0)
    )
  );
}
function factSampleMoves(sample, observations) {
  return sample.moves_uci ?? observations.paths.find((path) => path.id === sample.line_id).moves.slice(0, sample.prefix_ply_count).map((move) => move.uci);
}
function qualifiedPositionFactSources(position) {
  const suffix = `:evidence:position-occurrence:${position.id}`;
  if (!position.premise_id.endsWith(suffix)) return [];
  const namespace = position.premise_id.slice(0, -suffix.length);
  const rows = [
    ["geometric_control", position.controls.pieces.flatMap((p) => p.source_ids)],
    ["ray_barrier", position.rays.lines.map((p) => p.source_id)],
    ["legal_move", position.legal_moves.moves.map((p) => p.source_id)],
    ["pawn_file_group", position.pawn_files.files.flatMap((p) => p.source_ids)],
    ["pawn_advance_affordance", position.pawn_advances.paths.map((p) => p.source_id)]
  ];
  return rows.flatMap(([kind, refs]) => refs.filter((ref) => /^[a-f0-9]{64}$/.test(ref)).map((ref) => `${namespace}:evidence:relation:position:${position.id}:${kind}:${ref}`));
}
function factQualifiedPositionIds(sample, predicate, path, observations) {
  const positions = new Set(path.positionIds?.slice(sample.from_ply, sample.through_ply + 1));
  if (predicate.kind !== "direct_support_use" || sample.value !== "true" || !path.lineSummary?.material)
    return positions;
  const providerOrigin = { ...predicate.subject, position_id: path.positionIds[0] }, targetOrigin = { ...predicate.target, position_id: path.positionIds[0] };
  const snapshots = /* @__PURE__ */ new Map();
  const at = (count) => {
    if (!snapshots.has(count)) snapshots.set(count, trackedPieces(path, count));
    return snapshots.get(count);
  };
  const current = (original, count) => at(count)?.find((piece) => samePiece(piece.original, original))?.current;
  const captures = path.lineSummary.material.events.filter((event) => event.capture && event.ply_offset < sample.through_ply);
  for (const loss of captures) {
    const target = current(targetOrigin, loss.ply_offset), provider = current(providerOrigin, loss.ply_offset), capturer = at(loss.ply_offset)?.find((piece) => piece.current.square === loss.from)?.original;
    if (!target || !provider || !capturer || loss.capture.square !== target.square) continue;
    const takenBy = current(capturer, loss.ply_offset + 1);
    const lossPosition = observations.positions?.find((position) => position.id === path.positionIds[loss.ply_offset]);
    if (!takenBy || takenBy.square !== target.square || !lossPosition?.controls.complete || !lossPosition.legal_moves.complete || continuationSupportAt(
      observations,
      path,
      providerOrigin,
      targetOrigin,
      loss.ply_offset,
      at(loss.ply_offset)
    ).state !== "present") continue;
    for (const recovery of captures.filter((event) => event.ply_offset > loss.ply_offset)) {
      const actor = at(recovery.ply_offset)?.find((piece) => piece.current.square === recovery.from)?.original, victim = at(recovery.ply_offset)?.find((piece) => piece.current.square === recovery.capture.square)?.original;
      if (!actor || !victim || !samePiece(actor, providerOrigin) || !samePiece(victim, capturer) || !observations.positions?.find((position) => position.id === path.positionIds[recovery.ply_offset])?.legal_moves.complete || !Array.from({ length: recovery.ply_offset - loss.ply_offset + 1 }, (_, index) => loss.ply_offset + index).every((count) => {
        const piece = current(providerOrigin, count);
        return piece && samePiece(piece, { ...provider, position_id: path.positionIds[count] });
      }) || !Array.from({ length: recovery.ply_offset - loss.ply_offset }, (_, index) => loss.ply_offset + index + 1).every((count) => {
        const piece = current(capturer, count);
        return piece && samePiece(piece, { ...takenBy, position_id: path.positionIds[count] });
      })) continue;
      positions.add(path.positionIds[loss.ply_offset]);
      positions.add(path.positionIds[recovery.ply_offset]);
    }
  }
  return positions;
}
function factResultValid(value, reading, prior, observations, context) {
  if (!object(value) || !exactKeys(value, ["state", "samples", "needs", "proofs", "reason"]) || ![
    "observed",
    "supported",
    "refuted",
    "partial",
    "unavailable_input",
    "not_applicable",
    "invalid_input"
  ].includes(String(value.state)) || value.reason !== null && !factText(value.reason) || !Array.isArray(value.samples) || value.samples.length > (reading.kind === "fact" ? 600 : 0) || !Array.isArray(value.needs) || value.needs.length > 36e4 || !Array.isArray(value.proofs) || value.proofs.length > 600 || !["stopped", "awaiting_engine"].includes(reading.state) && reading.state !== value.state)
    return false;
  const samples = value.samples;
  const all = [...prior, reading];
  const dependencies = /* @__PURE__ */ new Set();
  const pending = [reading.id];
  while (pending.length) {
    const next = pending.pop();
    if (dependencies.has(next)) continue;
    dependencies.add(next);
    const row = all.find((row2) => row2.id === next);
    if (row?.kind === "fact_group") pending.push(...row.members);
    if (row?.kind === "fact_comparison") pending.push(row.left_requirement_id, row.right_requirement_id);
  }
  if (reading.state === "awaiting_engine" && reading.kind !== "fact" && !prior.some(
    (row) => dependencies.has(row.id) && row.kind === "fact" && row.state === "awaiting_engine" && row.work_id === reading.work_id && row.result?.needs.some(
      (child) => (child.kind === "continuation" || child.kind === "comparison" && row.path.source.kind === "comparison" && row.path.source.requirement_id === child.requirement_id && prior.some((pair) => pair.kind === "compare_moves" && pair.id === child.requirement_id && pair.state === "awaiting_engine" && pair.work_id === reading.work_id)) && value.needs.some(
        (need) => need.kind === child.kind && need.reason === child.reason && need.requirement_id === child.requirement_id && need.horizon === child.horizon && JSON.stringify(need.prefix_moves_uci) === JSON.stringify(child.prefix_moves_uci)
      )
    )
  ))
    return false;
  const sampleIndex = new Map(
    prior.flatMap((row) => row.result?.samples.map((sample) => [sample.id, sample]) ?? [])
  );
  for (const sample of samples) {
    const compact = object(sample) && Object.prototype.hasOwnProperty.call(sample, "prefix_ply_count");
    if (!object(sample) || !exactKeys(sample, [
      "id",
      "line_id",
      "binding",
      ...compact ? ["prefix_ply_count"] : ["moves_uci", "position_ids", "occurrence_ids"],
      "from_ply",
      "through_ply",
      "value",
      "state",
      "source_ids",
      "reason"
    ]) || !id(sample.id) || !proposalId(sample.binding) || (compact ? !factPly(sample.prefix_ply_count) : !factMoves(sample.moves_uci)) || !factPly(sample.from_ply) || !factPly(sample.through_ply) || sample.from_ply > sample.through_ply || Number(compact ? sample.prefix_ply_count : sample.moves_uci.length) < sample.through_ply || !compact && (!ids(sample.position_ids) || !ids(sample.occurrence_ids)) || !ids(sample.source_ids) || !["known", "unavailable_input", "not_applicable"].includes(String(sample.state)) || (sample.state === "known" ? typeof sample.value !== "string" || sample.reason !== null : sample.value !== null || !factText(sample.reason)))
      return false;
    const owner = reading.kind === "fact" ? reading : prior.find(
      (row) => dependencies.has(row.id) && row.kind === "fact" && row.result?.samples.some((s) => s.id === sample.id)
    );
    if (owner?.kind !== "fact" || sample.binding !== owner.path.binding || sample.state === "known" && !factValues(owner.predicate.kind).includes(sample.value))
      return false;
    if (owner.at.kind === "ply" && (sample.from_ply < owner.at.ply_count || !owner.through && sample.from_ply !== owner.at.ply_count))
      return false;
    if (owner.through?.kind === "ply" && sample.through_ply > owner.through.ply_count) return false;
    const path = observations.paths.find((path2) => path2.id === sample.line_id);
    const prefixLength = Number(compact ? sample.prefix_ply_count : sample.moves_uci.length);
    if (!path || !context || path.kind === "history" || path.startFen !== context.rootFen || prefixLength > path.moves.length || !ids(path.positionIds?.slice(sample.from_ply, sample.through_ply + 1)) || !compact && (!factPrefix(sample.moves_uci, path.moves.map((move) => move.uci)) || JSON.stringify(sample.position_ids) !== JSON.stringify(path.positionIds?.slice(sample.from_ply, sample.through_ply + 1))))
      return false;
    const usedOccurrences = path.occurrenceIds.slice(0, prefixLength);
    if (!ids(usedOccurrences) || !compact && JSON.stringify(sample.occurrence_ids) !== JSON.stringify(usedOccurrences))
      return false;
    const usedPositionIds = path.positionIds?.slice(0, prefixLength + 1);
    const resources = observations.positions?.filter((position) => usedPositionIds?.includes(position.id)) ?? [];
    const sources = /* @__PURE__ */ new Set([
      ...usedOccurrences.filter((v) => v !== null),
      ...path.lineSummary?.premise_ids ?? []
    ]);
    for (const position of resources) {
      sources.add(position.premise_id);
      for (const ref of [
        ...position.controls.pieces.flatMap((p) => p.source_ids),
        ...position.rays.lines.map((p) => p.source_id),
        ...position.legal_moves.moves.map((p) => p.source_id),
        ...position.pawn_states.pawns.flatMap((p) => p.source_ids),
        ...position.pawn_files.files.flatMap((p) => p.source_ids),
        ...position.pawn_advances.paths.map((p) => p.source_id)
      ])
        sources.add(ref);
    }
    const qualifiedPositions = factQualifiedPositionIds(
      sample,
      owner.predicate,
      path,
      observations
    );
    for (const position of resources.filter((position2) => qualifiedPositions.has(position2.id)))
      for (const ref of qualifiedPositionFactSources(position)) sources.add(ref);
    if (!sample.source_ids.every((ref) => sources.has(ref))) return false;
    if (sampleIndex.has(sample.id)) return false;
    sampleIndex.set(sample.id, sample);
  }
  if (new Set(samples.map((s) => s.id)).size !== samples.length) return false;
  for (const need of value.needs) {
    if (!object(need) || !exactKeys(need, ["kind", "reason", "prefix_moves_uci", "requirement_id", "horizon"]) || !["input", "comparison", "continuation"].includes(String(need.kind)) || !factText(need.reason) || !factMoves(need.prefix_moves_uci) || need.horizon !== null && !factPly(need.horizon) || need.requirement_id !== null && !all.some((row) => row.id === need.requirement_id) || need.kind === "comparison" && !prior.some((row) => row.kind === "compare_moves" && row.id === need.requirement_id) || need.kind === "continuation" && (need.prefix_moves_uci.length === 0 || need.prefix_moves_uci.length >= 80 || !factPly(need.horizon) || need.horizon <= need.prefix_moves_uci.length || !observations.paths.some(
      (path) => path.kind !== "history" && path.startFen === context?.rootFen && factPrefix(
        need.prefix_moves_uci,
        path.moves.map((move) => move.uci)
      )
    )))
      return false;
  }
  for (const proof of value.proofs) {
    if (!object(proof) || !exactKeys(proof, ["bindings", "sample_ids", "requirement_ids"]) || !object(proof.bindings) || Object.keys(proof.bindings).length > 600 || !Object.entries(proof.bindings).every(([key, moves]) => proposalId(key) && factMoves(moves)) || !factSampleIds(proof.sample_ids) || !proof.sample_ids.length || !ids(proof.requirement_ids) || !proof.requirement_ids.includes(reading.id) || !proof.requirement_ids.every((ref) => dependencies.has(ref)))
      return false;
    const bindings = proof.bindings;
    const selected = proof.sample_ids.map((ref) => sampleIndex.get(ref));
    if (selected.some(
      (sample) => !sample || sample.state !== "known" || !Object.prototype.hasOwnProperty.call(bindings, sample.binding) || !factPrefix(factSampleMoves(sample, observations), bindings[sample.binding])
    ))
      return false;
    if (!Object.entries(bindings).every(
      ([name, moves]) => selected.some(
        (sample) => sample?.binding === name && JSON.stringify(factSampleMoves(sample, observations)) === JSON.stringify(moves)
      )
    ))
      return false;
    if (reading.kind === "fact" && (selected.some(
      (sample) => !samples.some((s) => s.id === sample?.id) || reading.expected !== void 0 && sample?.value !== reading.expected
    ) || proof.requirement_ids.length !== 1))
      return false;
    if (reading.kind === "fact" && reading.at.kind === "ply" && (!reading.through || reading.through.kind === "ply")) {
      const start = reading.at.ply_count, end = reading.through?.ply_count ?? start;
      if (end < start || Array.from({ length: end - start + 1 }, (_, index) => start + index).some(
        (ply) => !selected.some((sample) => sample && sample.from_ply <= ply && sample.through_ply >= ply)
      ))
        return false;
    }
    if (reading.kind === "fact_comparison") {
      const left = prior.find((row) => row.id === reading.left_requirement_id)?.result?.samples ?? [];
      const right = prior.find((row) => row.id === reading.right_requirement_id)?.result?.samples ?? [];
      if (selected.length !== 2 || !selected.some(
        (a) => left.some((s) => s.id === a?.id) && selected.some(
          (b) => right.some((s) => s.id === b?.id) && a && b && (reading.relation === "same" ? a.value === b.value : reading.relation === "different" ? a.value !== b.value : reading.relation === "before" ? a.from_ply < b.from_ply : reading.relation === "after" ? a.from_ply > b.from_ply : a.from_ply === b.from_ply)
        )
      ))
        return false;
    }
    if (reading.kind === "fact_group") {
      const memberSupported = (member) => prior.find((row) => row.id === member && row.result?.state === "supported")?.result?.proofs.some(
        (child) => child.requirement_ids.every((ref) => proof.requirement_ids.includes(ref)) && child.sample_ids.every((ref) => proof.sample_ids.includes(ref)) && Object.entries(child.bindings).every(
          ([name, moves]) => bindings[name] && factPrefix(moves, bindings[name])
        )
      );
      if (!(reading.mode === "all" ? reading.members.every(memberSupported) : reading.members.some(memberSupported)))
        return false;
    }
  }
  if (value.state === "refuted" && value.proofs.length) return false;
  if (["supported", "observed"].includes(String(value.state)) && !value.proofs.length)
    return false;
  if (reading.kind === "fact") {
    if (value.state === "observed" && reading.expected !== void 0 || value.state === "supported" && reading.expected === void 0)
      return false;
    if (value.state === "refuted" && (reading.path.extend || reading.expected === void 0 || !samples.some((s) => object(s) && s.state === "known" && s.value !== reading.expected)))
      return false;
  } else if (value.state === "observed") return false;
  if (value.state === "refuted" && reading.kind === "fact_group") {
    const children = reading.members.map((member) => prior.find((row) => row.id === member)?.result);
    if (!(reading.mode === "any" ? children.every((child) => child?.state === "refuted") : children.some((child) => child?.state === "refuted") || children.every((child) => child?.state === "supported") && value.reason === "incompatible_paths"))
      return false;
  }
  if (value.state === "refuted" && reading.kind === "fact_comparison" && ![reading.left_requirement_id, reading.right_requirement_id].every((member) => {
    const row = prior.find((row2) => row2.id === member);
    return row?.kind === "fact" && !row.path.extend && row.result && ["observed", "supported", "refuted"].includes(row.result.state) && !row.result.needs.some((need) => need.reason === "witness_limit");
  }))
    return false;
  return true;
}
function decodeProposals(value, observations, context) {
  if (!Array.isArray(value) || value.length > 600) return;
  const requestId = (value2) => typeof value2 === "string" && /^[A-Za-z0-9._:-]{1,128}$/.test(value2);
  const boundedText = (value2, maximum) => typeof value2 === "string" && value2.length > 0 && value2.length <= maximum;
  const uci2 = (value2) => typeof value2 === "string" && /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(value2);
  const nullableId = (value2) => value2 === null || id(value2);
  const source = (value2) => object(value2) && exactKeys(value2, ["kind", "producer", "source_refs"], ["version"]) && ["user", "author", "model", "generator", "none"].includes(String(value2.kind)) && boundedText(value2.producer, 128) && (value2.version === void 0 || boundedText(value2.version, 128)) && Array.isArray(value2.source_refs) && value2.source_refs.length <= 64 && value2.source_refs.every((ref) => boundedText(ref, 256));
  const proposals = [];
  let requirementCount = 0;
  for (const raw of value) {
    if (!object(raw) || !exactKeys(raw, ["id", "admission", "origin", "requirements"], ["question_text", "answer_text"]) || !requestId(raw.id) || !["submitted", "internal", "generated"].includes(String(raw.admission)) || ("question_text" in raw || "answer_text" in raw) && (raw.admission !== "generated" || !boundedText(raw.question_text, 16e3) || !boundedText(raw.answer_text, 16e3)) || !object(raw.origin) || !exactKeys(raw.origin, ["question", "candidates", "priority", "evidence"]) || !Object.values(raw.origin).every(source) || !Array.isArray(raw.requirements) || !raw.requirements.length || (requirementCount += raw.requirements.length) > 600)
      return;
    const requirements = [];
    for (const reading of raw.requirements) {
      if (!object(reading)) return;
      const semantic = ["fact", "fact_comparison", "fact_group"].includes(String(reading.kind));
      let decodedAnswer = null;
      const operationKeys = reading.kind === "observe_move" ? ["prefix_moves_uci", "move_uci"] : reading.kind === "compare_moves" ? ["prefix_moves_uci", "reference_move", "alternative_move"] : reading.kind === "uninterpreted" ? ["text"] : reading.kind === "fact" ? ["path", "predicate", "at"] : reading.kind === "fact_comparison" ? ["left_requirement_id", "right_requirement_id", "relation"] : reading.kind === "fact_group" ? ["mode", "members"] : void 0;
      if (!operationKeys || !exactKeys(
        reading,
        [
          "id",
          "kind",
          "state",
          "stop_reason",
          "answer",
          "line_id",
          "occurrence_id",
          "position_id",
          "work_id",
          ...operationKeys
        ],
        reading.kind === "compare_moves" ? ["expected_relation"] : semantic ? ["result", ...reading.kind === "fact" ? ["through", "expected"] : []] : []
      ) || !requestId(reading.id) || ![
        "deferred",
        "awaiting_engine",
        "observed",
        "answered",
        "supported",
        "refuted",
        "partial",
        "not_applicable",
        "invalid_input",
        "unavailable_input",
        "unsupported_reading",
        "stopped"
      ].includes(String(reading.state)) || reading.stop_reason !== null && !boundedText(reading.stop_reason, 256) || ![reading.line_id, reading.occurrence_id, reading.position_id].every(nullableId) || reading.work_id !== null && (typeof reading.work_id !== "string" || !/^work:[0-9]+$/.test(reading.work_id)))
        return;
      if (reading.line_id !== null && !observations.paths.some((path) => path.id === reading.line_id) || reading.occurrence_id !== null && !observations.paths.some((path) => path.occurrenceIds.includes(reading.occurrence_id)) || reading.position_id !== null && !observations.positions?.some((position) => position.id === reading.position_id))
        return;
      const resolvedPair = reading.kind === "compare_moves" && ["answered", "supported", "refuted"].includes(String(reading.state));
      if (reading.kind === "observe_move" && !["deferred", "observed", "invalid_input", "unavailable_input", "stopped"].includes(
        String(reading.state)
      ))
        return;
      if (reading.kind === "compare_moves" && ![
        "deferred",
        "awaiting_engine",
        "answered",
        "supported",
        "refuted",
        "invalid_input",
        "unavailable_input",
        "stopped"
      ].includes(String(reading.state)))
        return;
      if (resolvedPair !== (reading.answer !== null) || !semantic && ["observed", "answered", "supported", "refuted", "awaiting_engine"].includes(
        String(reading.state)
      ) && reading.stop_reason !== null || (!semantic || reading.state === "stopped" || reading.result === void 0) && ["invalid_input", "unavailable_input", "unsupported_reading", "stopped"].includes(
        String(reading.state)
      ) && reading.stop_reason === null)
        return;
      if (semantic) {
        if (!factRequirementValid(reading, requirements) || reading.state === "answered" || reading.state === "unsupported_reading" || reading.state === "awaiting_engine" && reading.work_id === null || reading.state === "awaiting_engine" && reading.stop_reason !== null || (reading.result === void 0 ? !["deferred", "invalid_input", "stopped"].includes(String(reading.state)) : !factResultValid(
          reading.result,
          reading,
          requirements,
          observations,
          context
        )))
          return;
      } else if (reading.kind === "uninterpreted") {
        if (!boundedText(reading.text, 2e3) || reading.state !== "unsupported_reading" || [reading.answer, reading.line_id, reading.occurrence_id, reading.position_id, reading.work_id].some(
          (value2) => value2 !== null
        ))
          return;
      } else {
        const prefix = reading.prefix_moves_uci;
        if (!Array.isArray(prefix) || prefix.length > 79 || !prefix.every(uci2)) return;
        if (reading.kind === "observe_move") {
          if (!uci2(reading.move_uci) || resolvedPair || reading.state === "awaiting_engine" || reading.work_id !== null)
            return;
          if (reading.state === "observed") {
            const path = observations.paths.find((path2) => path2.id === reading.line_id);
            if (!path || !context || path.kind === "history" || path.startFen !== context.rootFen || !prefix.every((move, index) => path.moves[index]?.uci === move) || path.moves[prefix.length]?.uci !== reading.move_uci || path.occurrenceIds[prefix.length] !== reading.occurrence_id || path.positionIds?.[prefix.length + 1] !== reading.position_id)
              return;
          }
        } else {
          if (!uci2(reading.reference_move) || !uci2(reading.alternative_move) || reading.reference_move === reading.alternative_move || reading.state === "observed" || reading.expected_relation !== void 0 && !["better", "equal", "worse"].includes(String(reading.expected_relation)) || reading.state === "awaiting_engine" && reading.work_id === null)
            return;
          if (resolvedPair) {
            if (!object(reading.answer)) return;
            const rawAnswer = reading.answer;
            const path = observations.paths.find((path2) => path2.id === rawAnswer.reference_line_id);
            const positionId = path?.positionIds?.[prefix.length];
            if (!path || !positionId || !prefix.every((move, index) => path.moves[index]?.uci === move) || reading.position_id !== null && reading.position_id !== positionId)
              return;
            const rootOccurrenceId = path.occurrenceIds[0];
            if (!rootOccurrenceId) return;
            const answer = decodeComparisonAnswer(
              reading.answer,
              observations,
              context,
              positionId,
              reading.reference_move,
              reading.alternative_move,
              prefix.length ? {
                rootMove: prefix[0],
                rootOccurrenceId,
                prefixMoves: prefix,
                scopeFields: false
              } : void 0
            );
            const expectedState = reading.expected_relation === void 0 ? "answered" : reading.expected_relation === answer?.evaluation_relation ? "supported" : "refuted";
            if (!answer || answer.work_id !== reading.work_id || reading.state !== expectedState) return;
            decodedAnswer = answer;
          }
        }
      }
      requirements.push({ ...reading, answer: decodedAnswer });
    }
    if (new Set(requirements.map((reading) => reading.id)).size !== requirements.length) return;
    proposals.push({ ...raw, requirements });
  }
  return new Set(proposals.map((proposal) => proposal.id)).size === proposals.length ? proposals : void 0;
}
function proposalFactSourcesValid(proposals, observations, continuations) {
  return proposals.every(
    (proposal) => proposal.requirements.every((reading) => {
      if (reading.kind !== "fact") return true;
      const source = reading.path.source;
      const supplied = source.kind === "declared" ? [source.moves_uci] : source.kind === "comparison" ? (() => {
        const pair = proposal.requirements.find((row) => row.id === source.requirement_id);
        const answer = pair?.kind === "compare_moves" ? pair.answer : void 0;
        const line = observations.paths.find(
          (path) => path.id === (source.arm === "reference" ? answer?.reference_line_id : answer?.alternative_line_id)
        );
        return line ? [line.moves.map((move) => move.uci)] : [];
      })() : (() => {
        const premise = continuations.find((row) => row.id === source.inquiry_id)?.premises.find((row) => row.id === source.premise_id);
        return observations.paths.filter((path) => premise?.witness_line_ids.includes(path.id)).map((path) => path.moves.map((move) => move.uci));
      })();
      const sourcePrefix = source.kind === "premise" && !supplied.length ? continuations.find((row) => row.id === source.inquiry_id)?.prefix_moves_uci : void 0;
      return (reading.result?.samples ?? []).every(
        (sample) => supplied.some(
          (moves) => factPrefix(moves, factSampleMoves(sample, observations)) && (reading.path.extend || factPrefix(factSampleMoves(sample, observations), moves)) || factPrefix(factSampleMoves(sample, observations), moves) && reading.result?.needs.some((need) => need.reason === "declared_path_unavailable") && !proposal.requirements.some(
            (row) => row.result?.proofs.some((proof) => proof.sample_ids.includes(sample.id))
          )
        )
      ) && (reading.result?.needs ?? []).filter((need) => need.kind === "continuation").every(
        (need) => reading.path.extend && [...supplied, ...sourcePrefix ? [sourcePrefix] : []].some(
          (moves) => factCompatible(moves, need.prefix_moves_uci)
        )
      );
    })
  );
}
function reserveResponsePoolMatches(proposal, reading, pool, observations, positionId) {
  if (proposal.admission !== "generated" || reading.kind !== "compare_moves") return false;
  const hold = proposal.origin.question.producer === "C-reserve-hold" && reading.id === "reserve_hold";
  const counter = proposal.origin.question.producer === "C-reserve-entry" && reading.id === "reserve_counter";
  if (!hold && !counter) return false;
  const position = observations.positions?.find((position2) => position2.id === positionId);
  if (!position?.legal_moves.complete) return false;
  const side = parseFen(position.fen).unwrap().turn;
  const pieces = position.controls.pieces.map((control) => control.piece);
  const king = pieces.find((piece) => piece.side === side && piece.role === "king");
  const pawn = pieces.find((piece) => piece.side === side && piece.role === "pawn" && piece.square === reading.alternative_move.slice(0, 2));
  if (!king || !pawn || reading.reference_move.slice(0, 2) !== king.square || ![reading.reference_move, reading.alternative_move].every((uci2) => position.legal_moves.moves.some((move) => move.uci === uci2))) return false;
  const members = new Set(pieces.filter((piece) => piece.side === side && piece.role === (hold ? "king" : "pawn")).map((piece) => piece.square));
  const expected = /* @__PURE__ */ new Set([hold ? reading.alternative_move : reading.reference_move, ...position.legal_moves.moves.filter((move) => members.has(move.uci.slice(0, 2))).map((move) => move.uci)]);
  return expected.size === pool.length && pool.every((move) => expected.has(move));
}
function functionalResponseSurveyMatches(proposal, reading, prefix, rootOccurrenceId) {
  if (proposal.admission !== "generated" || proposal.origin.question.kind !== "generator" || proposal.origin.question.producer !== "C-reply-function" || prefix.length !== 2 && prefix.length !== 3 || reading.kind !== "compare_moves" || !reading.id.startsWith("function_value_") || !factPrefix(prefix, reading.prefix_moves_uci) || reading.prefix_moves_uci.length !== prefix.length)
    return false;
  const members = [
    "function_before",
    "function_root_reference",
    "function_root_alternative",
    "function_owned",
    "function_changed",
    "function_live",
    "function_resource"
  ];
  const task = proposal.requirements.find((row) => row.id === "function_task_context");
  const root = proposal.requirements.find((row) => row.id === "function_root");
  const resource = proposal.requirements.find((row) => row.id === "function_resource");
  if (task?.kind !== "fact_group" || task.mode !== "all" || task.state !== "supported" || task.members.length !== members.length || !task.members.every((id2, index) => id2 === members[index]) || !members.every((id2) => proposal.requirements.some((row) => row.id === id2 && row.state === "supported")) || root?.kind !== "compare_moves" || root.state !== "answered" || !root.answer || root.prefix_moves_uci.length !== 0 || ![root.reference_move, root.alternative_move].includes(prefix[0]) || (prefix[0] === root.reference_move ? root.answer.reference_occurrence_id : root.answer.alternative_occurrence_id) !== rootOccurrenceId || resource?.kind !== "fact" || resource.predicate.kind !== "legal_move" || !resource.predicate.subject || !resource.predicate.square) return false;
  const actor = resource.predicate.subject, square = resource.predicate.square;
  return proposal.requirements.some((row) => row.kind === "fact" && row.state === "supported" && row.at.kind === "ply" && row.at.ply_count === prefix.length && row.path.source.kind === "declared" && row.path.source.moves_uci.length === prefix.length && factPrefix(prefix, row.path.source.moves_uci) && row.predicate.subject?.side === actor.side && row.predicate.subject?.role === actor.role && row.predicate.subject?.square === actor.square && (prefix.length === 2 ? row.id.startsWith("function_value_legal:") && row.predicate.kind === "legal_move" && row.predicate.square === square && row.expected === "legal" : row.id.startsWith("function_value_present:") && row.predicate.kind === "presence" && row.expected === "present"));
}
function anchoredResponseSurveyMatches(proposal, reading, prefix, rootOccurrenceId) {
  const family = proposal.origin.question.producer === "C-reserve-use";
  if (proposal.admission !== "generated" || proposal.origin.question.kind !== "generator" || !family && proposal.origin.question.producer !== "C-reserve-timing" || reading.kind !== "compare_moves" || !reading.id.startsWith("anchored_value_") || prefix.length < (family ? 1 : 2) || prefix.length !== reading.prefix_moves_uci.length || !factPrefix(prefix, reading.prefix_moves_uci)) return false;
  const root = proposal.requirements.find((row) => row.id === "reserve_root");
  const timing = proposal.requirements.find((row) => row.id === "reserve_timing");
  const context = proposal.requirements.find((row) => row.id === (family ? "reserve_context" : "timing_context"));
  const before = proposal.requirements.find((row) => row.id === "reserve_before");
  const rootReply = family && prefix.length === 1 && ["anchored_value_response:", "anchored_value_reply:", "anchored_value_capture:"].some((role) => reading.id.startsWith(role));
  const expected = family ? ["reserve_before", "reserve_after", "reserve_kept"] : [
    "reserve_before",
    "reserve_after",
    "reserve_kept",
    "timing_available",
    "timing_kept",
    "timing_current",
    "timing_common_reply"
  ];
  if (root?.kind !== "compare_moves" || root.state !== "answered" || !root.answer || root.prefix_moves_uci.length || root.answer.evaluation_relation !== "better" || root.answer.reference_depth === null || root.answer.reference_depth !== root.answer.alternative_depth || root.answer.reference_depth < root.answer.required_depth || (rootReply ? ![root.reference_move, root.alternative_move].includes(prefix[0]) : prefix[0] !== root.alternative_move) || (rootReply && prefix[0] === root.reference_move ? root.answer.reference_occurrence_id : root.answer.alternative_occurrence_id) !== rootOccurrenceId || before?.kind !== "fact" || before.predicate.subject?.role !== "pawn" || before.predicate.subject.square !== root.reference_move.slice(0, 2) || qualityBand(
    root.answer.reference_evaluation,
    root.answer.alternative_evaluation,
    before.predicate.subject.side
  ) !== "separated" || !family && (timing?.kind !== "compare_moves" || timing.prefix_moves_uci.length !== 2 || timing.prefix_moves_uci[0] !== root.alternative_move || timing.reference_move !== root.reference_move) || context?.kind !== "fact_group" || context.mode !== "all" || context.state !== "supported" || !sameIds(context.members, expected) || !expected.every((id2) => proposal.requirements.some((row) => row.id === id2 && row.state === "supported")))
    return false;
  const samePawn = (a, b) => !!b && a.side === b.side && a.role === b.role && a.square === b.square;
  const own = family ? reading.id.startsWith("anchored_value_own:") && prefix.length % 2 === 0 : timing?.kind === "compare_moves" && prefix.length === timing.prefix_moves_uci.length && factPrefix(prefix, timing.prefix_moves_uci);
  const prior = family ? prefix.slice(0, -1) : timing?.kind === "compare_moves" ? timing.prefix_moves_uci : [];
  const response = rootReply || prefix.length === prior.length + 1 && prefix.length % 2 === 1 && factPrefix(prior, prefix) && proposal.requirements.some((row) => row.kind === "compare_moves" && row.id.startsWith("anchored_value_own:") && row.state === "answered" && !!row.answer && row.prefix_moves_uci.length === prior.length && factPrefix(prior, row.prefix_moves_uci) && [row.reference_move, row.alternative_move].includes(prefix[prefix.length - 1]));
  if (!own && !response) return false;
  return proposal.requirements.some((group) => {
    if (group.kind !== "fact_group" || !group.id.startsWith("anchored_value_context:") || group.mode !== "all" || group.state !== "supported" || group.members.length !== 3) return false;
    const facts = group.members.map((id2) => proposal.requirements.find((row) => row.id === id2));
    if (!facts.every((row) => row?.kind === "fact" && row.state === "supported" && row.at.kind === "ply" && row.at.ply_count === prefix.length && row.path.source.kind === "declared" && row.path.source.moves_uci.length === prefix.length && factPrefix(prefix, row.path.source.moves_uci)))
      return false;
    const presence = facts.find((row) => row?.kind === "fact" && row.id.startsWith("anchored_value_present:"));
    const location2 = facts.find((row) => row?.kind === "fact" && row.id.startsWith("anchored_value_location:"));
    const legal = facts.find((row) => row?.kind === "fact" && row.id.startsWith("anchored_value_legal:"));
    if (presence?.kind !== "fact" || presence.predicate.kind !== "presence" || presence.expected !== "present" || presence.predicate.subject?.role !== "pawn" || presence.predicate.subject.square !== root.reference_move.slice(0, 2) || !samePawn(presence.predicate.subject, before.predicate.subject) || location2?.kind !== "fact" || location2.predicate.kind !== "location" || !location2.expected || !samePawn(presence.predicate.subject, location2.predicate.subject) || legal?.kind !== "fact" || legal.predicate.kind !== "legal_move" || legal.expected !== "legal" || legal.predicate.square !== reading.reference_move.slice(2, 4) || !legal.predicate.subject) return false;
    if (rootReply && (location2.expected !== (prefix[0] === root.reference_move ? root.reference_move.slice(2, 4) : before.predicate.subject.square) || legal.predicate.subject.side === before.predicate.subject.side || legal.predicate.subject.square !== reading.reference_move.slice(0, 2))) return false;
    return !own || samePawn(legal.predicate.subject, presence.predicate.subject) && reading.reference_move === root.reference_move && location2.expected === reading.reference_move.slice(0, 2);
  });
}
function ownedChoiceSurveyMatches(proposal, reading, prefix, rootOccurrenceId) {
  return functionalResponseSurveyMatches(proposal, reading, prefix, rootOccurrenceId) || anchoredResponseSurveyMatches(proposal, reading, prefix, rootOccurrenceId);
}
function ownedChoiceConflictReceiptMatches(child, searches, proposals, observations, accept) {
  const completedDepth = (search) => {
    const depths = search.candidates.map((candidate) => candidate.evaluation.kind === "engine_search" ? candidate.evaluation.depth : void 0);
    const first = depths[0];
    return typeof first === "number" && depths.every((depth) => depth === first) ? first : void 0;
  };
  return child.proposal_ownership?.question_refs.some((ref) => {
    const proposal = proposals.find((row) => row.id === ref.proposal_id);
    const reading = proposal?.requirements.find((row) => row.id === ref.requirement_id);
    if (!proposal || proposal.admission !== "generated" || proposal.origin.question.kind !== "generator" || proposal.origin.question.producer !== "C-comparison-conflict" || reading?.kind !== "compare_moves" || reading.id !== "resolve_comparison_conflict" || !["answered", "supported", "refuted"].includes(reading.state) || reading.work_id !== child.work_id || !reading.answer || reading.answer.work_id !== child.work_id || reading.answer.execution_key_sha256 !== child.execution_key_sha256 || child.root_restriction.kind !== "restricted" || !sameIds(child.root_restriction.moves_uci, [reading.reference_move, reading.alternative_move]) || !factPrefix(reading.prefix_moves_uci, responseSearchPrefix(child)) || reading.prefix_moves_uci.length !== responseSearchPrefix(child).length) return false;
    const refs = proposal.origin.question.source_refs;
    if (refs.length !== 2 || new Set(refs).size !== 2 || ![proposal.origin.candidates, proposal.origin.evidence].every((source) => source.kind === "generator" && source.producer === "C-comparison-conflict" && source.source_refs.length === refs.length && source.source_refs.every((id2, index) => id2 === refs[index])))
      return false;
    const sources = refs.map((id2) => searches.find((search) => search.work_id === id2));
    if (!sources.every((search) => !!search)) return false;
    if (sources.some((source) => Number(source.work_id.slice(5)) >= Number(child.work_id.slice(5)))) return false;
    const pool = sources.find((search) => search.root_restriction.kind === "unrestricted");
    const pair = sources.find((search) => search.root_restriction.kind === "restricted");
    if (!pool || !pair || pair.root_restriction.kind !== "restricted" || pair.root_restriction.moves_uci.length !== 2 || !pair.root_restriction.moves_uci.includes(pool.candidates[0].move_uci)) return false;
    const pairMoves = pair.root_restriction.moves_uci;
    const prefix = responseSearchPrefix(pool), level = completedDepth(pool);
    if (level === void 0 || child.required_depth < level || sources.some((search) => search.engine_profile !== child.engine_profile || search.root_move !== child.root_move || search.root_move_occurrence_id !== child.root_move_occurrence_id || search.child_position_id !== pool.child_position_id || completedDepth(search) !== level || responseSearchPrefix(search).length !== prefix.length || !factPrefix(prefix, responseSearchPrefix(search))))
      return false;
    const parentOwned = pair.proposal_ownership?.question_refs.some((parentRef) => {
      const parent = proposals.find((row) => row.id === parentRef.proposal_id);
      const question = parent?.requirements.find((row) => row.id === parentRef.requirement_id);
      return !!parent && question?.kind === "compare_moves" && sameIds(pairMoves, [question.reference_move, question.alternative_move]) && ownedChoiceSurveyMatches(parent, question, prefix, pool.root_move_occurrence_id) && pool.proposal_ownership?.question_refs.some((poolRef) => {
        const seed = parent.requirements.find((row) => row.id === poolRef.requirement_id);
        return poolRef.proposal_id === parent.id && !!seed && ownedChoiceSurveyMatches(parent, seed, prefix, pool.root_move_occurrence_id);
      });
    });
    if (!parentOwned) return false;
    const divergent = sources[0].candidates.some((first) => {
      const second = sources[1].candidates.find((candidate) => candidate.move_uci === first.move_uci);
      if (!second || !pairMoves.includes(first.move_uci) || qualityBand(first.evaluation, second.evaluation, "white") !== "separated") return false;
      const left = observations.paths.find((path) => path.id === first.line_id);
      const right = observations.paths.find((path) => path.id === second.line_id);
      if (!left || !right) return false;
      let shared = 0;
      while (shared < Math.min(left.moves.length, right.moves.length) && left.moves[shared].uci === right.moves[shared].uci) shared++;
      return shared > prefix.length && shared === reading.prefix_moves_uci.length && factPrefix(reading.prefix_moves_uci, left.moves.map((move) => move.uci)) && left.occurrenceIds.slice(0, shared).every((id2, index) => id2 === right.occurrenceIds[index]) && left.positionIds?.[shared] === child.child_position_id && right.positionIds?.[shared] === child.child_position_id && left.moves[shared]?.uci === reading.reference_move && right.moves[shared]?.uci === reading.alternative_move;
    });
    return divergent && (!accept || accept(proposal, reading, pool, pair));
  }) ?? false;
}
function declaredFamilyReceiptCapacityMatches(searches, proposals, roots, observations, context) {
  const familyKeys = /* @__PURE__ */ new Map();
  const familyKey = (proposal) => {
    if (familyKeys.has(proposal)) return familyKeys.get(proposal);
    const root = proposal.requirements.find((row) => row.id === "reserve_root");
    const before = proposal.requirements.find((row) => row.id === "reserve_before");
    const answer = root?.kind === "compare_moves" ? root.answer : void 0;
    const receipt = answer && roots.find((row) => row.work_id === answer.work_id && row.execution_key_sha256 === answer.execution_key_sha256 && row.state === "completed" && row.engine_profile === answer.engine_profile && row.required_depth === answer.required_depth);
    const reference = answer && observations.paths.find((path) => path.id === answer.reference_line_id);
    const alternative = answer && observations.paths.find((path) => path.id === answer.alternative_line_id);
    let key;
    if (proposal.admission === "generated" && proposal.origin.question.kind === "generator" && proposal.origin.question.producer === "C-reserve-use" && root?.kind === "compare_moves" && root.state === "answered" && !root.prefix_moves_uci.length && answer && receipt && before?.kind === "fact" && before.state === "supported" && before.at.kind === "ply" && before.at.ply_count === 0 && before.path.source.kind === "declared" && sameIds(before.path.source.moves_uci, [root.reference_move]) && before.predicate.kind === "location" && before.predicate.subject?.role === "pawn" && before.expected === before.predicate.subject.square && reference && alternative && reference.startFen === context.rootFen && alternative.startFen === context.rootFen && reference.positionIds?.[0] === receipt.root_position_id && alternative.positionIds?.[0] === receipt.root_position_id && reference.moves[0]?.uci === root.reference_move && alternative.moves[0]?.uci === root.alternative_move && reference.occurrenceIds[0] === answer.reference_occurrence_id && alternative.occurrenceIds[0] === answer.alternative_occurrence_id && [reference, alternative].every((path) => receipt.candidates.some((candidate) => candidate.line_id === path.id && candidate.occurrence_id === path.occurrenceIds[0] && candidate.move_uci === path.moves[0]?.uci))) {
      key = JSON.stringify([
        receipt.work_id,
        receipt.execution_key_sha256,
        receipt.root_position_id,
        root.reference_move,
        root.alternative_move,
        answer.reference_occurrence_id,
        answer.alternative_occurrence_id,
        before.predicate.subject.side,
        before.predicate.subject.role,
        before.predicate.subject.square
      ]);
    }
    familyKeys.set(proposal, key);
    return key;
  };
  const owners = /* @__PURE__ */ new Map();
  for (const search of searches) {
    const prefix = responseSearchPrefix(search);
    const path = commentarySearchAnchorPath(
      observations,
      context.rootFen,
      search.root_move,
      search.root_move_occurrence_id,
      search.child_position_id,
      prefix
    );
    if (!path) return false;
    const options = [];
    for (const ref of search.proposal_ownership?.question_refs ?? []) {
      const proposal = proposals.find((row) => row.id === ref.proposal_id);
      const reading = proposal?.requirements.find((row) => row.id === ref.requirement_id);
      if (proposal?.origin.question.producer !== "C-reserve-use" || reading?.kind !== "compare_moves") continue;
      const family = familyKey(proposal);
      if (!family || !anchoredResponseSurveyMatches(
        proposal,
        reading,
        prefix,
        search.root_move_occurrence_id
      )) return false;
      options.push({ family, question: JSON.stringify([
        family,
        prefix,
        path.occurrenceIds.slice(0, prefix.length),
        path.positionIds?.slice(0, prefix.length + 1),
        [reading.reference_move, reading.alternative_move].sort()
      ]) });
    }
    owners.set(search, options);
  }
  const dependencies = /* @__PURE__ */ new Set();
  const conflictSlots = /* @__PURE__ */ new Set();
  for (const child of searches) {
    const valid = ownedChoiceConflictReceiptMatches(
      child,
      searches,
      proposals,
      observations,
      (_proposal, reading, pool, pair) => {
        if (reading.kind !== "compare_moves") return false;
        const common = owners.get(pair)?.find((owner) => owners.get(pool)?.some((row) => row.family === owner.family));
        if (!common) return false;
        const path = commentarySearchAnchorPath(
          observations,
          context.rootFen,
          child.root_move,
          child.root_move_occurrence_id,
          child.child_position_id,
          responseSearchPrefix(child)
        );
        if (!path) return false;
        const slot = JSON.stringify([
          common.family,
          [pool, pair].map((row) => [row.work_id, row.execution_key_sha256]),
          responseSearchPrefix(child),
          path.occurrenceIds.slice(0, responseSearchPrefix(child).length),
          path.positionIds?.slice(0, responseSearchPrefix(child).length + 1),
          [reading.reference_move, reading.alternative_move].sort()
        ]);
        if (conflictSlots.has(slot)) return false;
        conflictSlots.add(slot);
        dependencies.add(pool);
        dependencies.add(pair);
        dependencies.add(child);
        return true;
      }
    );
    if (!valid && child.proposal_ownership?.question_refs.some((ref) => {
      const proposal = proposals.find((row) => row.id === ref.proposal_id);
      return proposal?.origin.question.producer === "C-comparison-conflict" && proposal.origin.question.source_refs.some((id2) => {
        const source = searches.find((row) => row.work_id === id2);
        return !!source && !!owners.get(source)?.length;
      });
    })) return false;
  }
  const normal = searches.filter((search) => !dependencies.has(search) && owners.get(search).length);
  const assigned = /* @__PURE__ */ new Map();
  const assign = (search, seen) => {
    for (const owner of owners.get(search)) {
      const slot = `${owner.question}/${search.root_restriction.kind}`;
      if (seen.has(slot)) continue;
      seen.add(slot);
      const previous = assigned.get(slot);
      if (!previous || assign(previous, seen)) {
        assigned.set(slot, search);
        return true;
      }
    }
    return false;
  };
  if (!normal.every((search) => assign(search, /* @__PURE__ */ new Set()))) return false;
  const other = searches.filter((search) => !dependencies.has(search) && !owners.get(search).length);
  const generic = other.filter((search) => search.proposal_ownership?.question_refs.some((ref) => {
    const proposal = proposals.find((row) => row.id === ref.proposal_id);
    const reading = proposal?.requirements.find((row) => row.id === ref.requirement_id);
    return !!proposal && !!reading && ownedChoiceSurveyMatches(
      proposal,
      reading,
      responseSearchPrefix(search),
      search.root_move_occurrence_id
    );
  }) || ownedChoiceConflictReceiptMatches(search, searches, proposals, observations));
  return generic.length <= 24 && other.length - generic.length <= 5 && (normal.length > 0 || dependencies.size > 0 || searches.length <= 29);
}
function proposalContainsResponsePool(proposals, search, observations) {
  if (search.root_restriction.kind === "unrestricted") {
    const ownership = search.proposal_ownership, prefix2 = responseSearchPrefix(search);
    const position = observations?.positions?.find((position2) => position2.id === search.child_position_id);
    const choiceOwner = ownership?.question_refs.some((ref) => {
      const proposal = proposals.find((proposal2) => proposal2.id === ref.proposal_id);
      const reading = proposal?.requirements.find((row) => row.id === ref.requirement_id);
      return !!proposal && !!reading && ownedChoiceSurveyMatches(
        proposal,
        reading,
        prefix2,
        search.root_move_occurrence_id
      );
    });
    return !!ownership && ownership.work_id === search.work_id && ownership.execution_key_sha256 === search.execution_key_sha256 && !!position?.legal_moves.complete && position.legal_moves.moves.length >= 2 && search.multi_pv === Math.min(3, position.legal_moves.moves.length) && ownership.question_refs.length > 0 && new Set(ownership.question_refs.map((ref) => `${ref.proposal_id}/${ref.requirement_id}`)).size === ownership.question_refs.length && ownership.question_refs.every((ref) => {
      const proposal = proposals.find((proposal2) => proposal2.id === ref.proposal_id);
      const reading = proposal?.requirements.find((reading2) => reading2.id === ref.requirement_id);
      return proposal?.admission === "generated" && reading?.kind === "compare_moves" && reading.prefix_moves_uci.length === prefix2.length && factPrefix(prefix2, reading.prefix_moves_uci) && (prefix2.length === 1 || choiceOwner) && reading.reference_move !== reading.alternative_move && [reading.reference_move, reading.alternative_move].every((move) => position.legal_moves.moves.some((row) => row.uci === move));
    });
  }
  if (search.root_restriction.kind !== "restricted") return false;
  const pool = search.root_restriction.moves_uci;
  const prefix = responseSearchPrefix(search);
  if (search.proposal_ownership !== void 0) {
    const ownership = search.proposal_ownership;
    const issued = ownership.question_refs.flatMap((ref) => {
      const reading = proposals.find((proposal) => proposal.id === ref.proposal_id)?.requirements.find((reading2) => reading2.id === ref.requirement_id);
      return reading?.kind === "compare_moves" ? [reading] : [];
    });
    return ownership.work_id === search.work_id && ownership.execution_key_sha256 === search.execution_key_sha256 && issued.length > 0 && issued.length === ownership.question_refs.length && new Set(ownership.question_refs.map((ref) => `${ref.proposal_id}/${ref.requirement_id}`)).size === issued.length && issued.every((reading) => reading.prefix_moves_uci.length === prefix.length && reading.prefix_moves_uci.every((move, index) => move === prefix[index]) && reading.reference_move === issued[0].reference_move) && (pool.length >= 2 && pool.length <= 3 && sameIds(pool, [...new Set(issued.flatMap((reading) => [reading.reference_move, reading.alternative_move]))]) || !!observations && ownership.question_refs.every((ref) => {
      const proposal = proposals.find((proposal2) => proposal2.id === ref.proposal_id);
      const reading = proposal.requirements.find((reading2) => reading2.id === ref.requirement_id);
      return reserveResponsePoolMatches(proposal, reading, pool, observations, search.child_position_id);
    }));
  }
  const pairs = proposals.flatMap(
    (proposal) => proposal.requirements.filter(
      (reading) => reading.kind === "compare_moves" && reading.prefix_moves_uci.length === prefix.length && reading.prefix_moves_uci.every((move, index) => move === prefix[index])
    )
  );
  const owned = pairs.filter((reading) => reading.work_id === search.work_id);
  if (owned.length) {
    const moves = [...new Set(owned.flatMap((reading) => [reading.reference_move, reading.alternative_move]))];
    return owned.every((reading) => ["answered", "supported", "refuted"].includes(reading.state) && reading.stop_reason === null && reading.answer?.work_id === search.work_id) && moves.length >= 2 && moves.length <= 3 && sameIds(pool, moves);
  }
  return pairs.some((reading) => sameIds(pool, [reading.reference_move, reading.alternative_move]));
}
function decodeDiscovery(value, observations, searches) {
  if (!object(value) || !exactKeys(value, ["version", "input_key", "scans"]) || value.version !== 1 || !factText(value.input_key) || !Array.isArray(value.scans) || value.scans.length > 600) return;
  const moves = (value2) => Array.isArray(value2) && value2.length <= 218 && value2.every((move) => factMoves([move])) && new Set(value2).size === value2.length;
  const anchors = /* @__PURE__ */ new Set();
  for (const scan of value.scans) {
    if (!object(scan) || !exactKeys(scan, [
      "prefix_moves_uci",
      "reference_move",
      "legal_moves",
      "examined_moves",
      "deferred_request_ids",
      "pending_replay_prefixes",
      "state",
      "reason"
    ])) return;
    const prefix = scan.prefix_moves_uci, legal = scan.legal_moves, examined = scan.examined_moves;
    if (!factMoves(prefix) || prefix.length >= 80 || !factMoves([scan.reference_move]) || !moves(legal) || !moves(examined) || !examined.every((move) => legal.includes(move)) || !Array.isArray(scan.deferred_request_ids) || !scan.deferred_request_ids.every(proposalId) || new Set(scan.deferred_request_ids).size !== scan.deferred_request_ids.length || !Array.isArray(scan.pending_replay_prefixes) || !scan.pending_replay_prefixes.every((pending) => factMoves(pending) && pending.length > prefix.length && factPrefix(prefix, pending)) || new Set(scan.pending_replay_prefixes.map((pending) => pending.join(" "))).size !== scan.pending_replay_prefixes.length || !["complete", "partial", "unavailable", "not_applicable"].includes(String(scan.state)) || !(scan.reason === null || factText(scan.reason)) || scan.state === "complete" && (!sameIds(examined, legal) || scan.deferred_request_ids.length > 0 || scan.pending_replay_prefixes.length > 0)) return;
    if (anchors.has(prefix.join(" "))) return;
    anchors.add(prefix.join(" "));
    if (prefix.length && !searches.some((search) => {
      const searched = responseSearchPrefix(search);
      return searched.length === prefix.length && factPrefix(prefix, searched);
    })) return;
    const path = observations.paths.find((path2) => path2.kind !== "history" && factPrefix(prefix, path2.moves.map((move) => move.uci)));
    const position = observations.positions?.find((position2) => position2.id === path?.positionIds?.[prefix.length]);
    if ((legal.length || scan.state === "complete") && (!position?.legal_moves.complete || !sameIds(legal, position.legal_moves.moves.map((move) => move.uci)) || !legal.includes(scan.reference_move))) return;
  }
  return value;
}
function decodeCommentarySelection(value, observations, context) {
  if (!object(value) || !exactKeys(
    value,
    ["version", "candidates", "scenes"],
    [
      "inquiries",
      "response_inquiries",
      "response_searches",
      "root_searches",
      "continuation_inquiries",
      "proposals",
      "local_expansions_used",
      "discovery"
    ]
  ) || value.version !== 2 || !Array.isArray(value.candidates) || value.candidates.length > 1e4 || !Array.isArray(value.scenes) || value.scenes.length > 1e4)
    return;
  const paths = new Map(observations.paths.map((p) => [p.id, p]));
  const occurrences = new Set(observations.paths.flatMap((p) => p.occurrenceIds).filter(id));
  const positions = new Map(observations.positions?.map((p) => [p.id, p]));
  let responseSearches;
  let rootSearches;
  let responseInquiries;
  let continuationInquiries;
  let proposals;
  let discovery;
  if (value.discovery !== void 0 && (value.proposals === void 0 || value.local_expansions_used === void 0)) return;
  if (value.proposals !== void 0 || value.local_expansions_used !== void 0) {
    if (!integer(value.local_expansions_used, 0, 600)) return;
    try {
      proposals = decodeProposals(value.proposals, observations, context);
    } catch (_) {
      return;
    }
    if (!proposals) return;
  }
  if (value.root_searches !== void 0) {
    rootSearches = decodeRootSearches(value.root_searches, observations, context);
    if (!rootSearches) return;
  }
  if (value.response_searches !== void 0) {
    try {
      responseSearches = decodeResponseSearches(value.response_searches, observations, context, proposals ?? [], rootSearches ?? []);
    } catch (_) {
      return;
    }
    if (!responseSearches) return;
  }
  if (value.discovery !== void 0) {
    discovery = decodeDiscovery(value.discovery, observations, responseSearches ?? []);
    if (!discovery) return;
  }
  if (value.response_inquiries !== void 0) {
    try {
      responseInquiries = decodeResponseInquiries(
        value.response_inquiries,
        observations,
        context,
        responseSearches
      );
    } catch (_) {
      return;
    }
    if (!responseInquiries) return;
  }
  if (value.continuation_inquiries !== void 0) {
    try {
      continuationInquiries = decodeContinuationInquiries(
        value.continuation_inquiries,
        observations,
        context,
        responseSearches ?? []
      );
    } catch (_) {
      return;
    }
    if (!continuationInquiries) return;
  }
  if (responseSearches?.some((search) => search.proposal_ownership !== void 0 && !proposalContainsResponsePool(proposals ?? [], search, observations)) || responseSearches?.some(
    (search) => search.root_restriction.kind === "restricted" && !responsePoolMatchesClasses(
      responseInquiries?.filter((inquiry) => responseSearchMatchesInquiry(search, inquiry)) ?? [],
      search.root_restriction.moves_uci,
      responseSearches.filter((prior) => Number(prior.work_id.slice(5)) < Number(search.work_id.slice(5))),
      context?.playedMove
    ) && !proposalContainsResponsePool(proposals ?? [], search, observations) && !continuationInquiries?.some((inquiry) => {
      if (!responseSearchMatchesContinuation(search, inquiry) || search.root_restriction.kind !== "restricted")
        return false;
      const priorFull = responseSearches.filter(
        (prior) => Number(prior.work_id.slice(5)) < Number(search.work_id.slice(5)) && responseSearchMatchesContinuation(prior, inquiry) && (prior.root_restriction.kind === "unrestricted" || inquiry.legal_moves.every(
          (move) => prior.root_restriction.kind === "restricted" && prior.root_restriction.moves_uci.includes(move)
        ))
      ).sort((left, right) => Number(right.work_id.slice(5)) - Number(left.work_id.slice(5)))[0];
      return !!priorFull && continuationRoutePoolMatches(
        inquiry,
        search.root_restriction.moves_uci,
        false,
        priorFull.candidates[0].move_uci
      );
    })
  ))
    return;
  const candidates = [];
  for (const raw of value.candidates) {
    if (!object(raw) || !exactKeys(
      raw,
      [
        "id",
        "kind",
        "selection",
        "root_occurrence_id",
        "occurrence_ids",
        "position_ids",
        "line_ids",
        "evidence_ids",
        "source_refs",
        "detail"
      ],
      ["highlight"]
    ) || !id(raw.id) || !["local_fact", "conditional_line", "comparison"].includes(String(raw.kind)) || !["selected", "display_cap", "display_representative", "context"].includes(String(raw.selection)) || !id(raw.root_occurrence_id) || !occurrences.has(raw.root_occurrence_id) || !ids(raw.occurrence_ids) || !raw.occurrence_ids.includes(raw.root_occurrence_id) || !raw.occurrence_ids.every((v) => occurrences.has(v)) || !ids(raw.position_ids) || !raw.position_ids.every((v) => positions.has(v)) || !ids(raw.line_ids) || !raw.line_ids.every((v) => paths.has(v)) || !ids(raw.evidence_ids) || !Array.isArray(raw.source_refs) || raw.source_refs.length > 600 || !object(raw.detail) || !id(raw.detail.type))
      return;
    if (raw.detail.text !== void 0 && (typeof raw.detail.text !== "string" || !raw.detail.text.trim() || raw.detail.text.length > 4e3))
      return;
    if (raw.detail.summary !== void 0 && (typeof raw.detail.summary !== "string" || !raw.detail.summary.trim() || raw.detail.summary.length > 4e3))
      return;
    if ((raw.detail.summary_exchange !== void 0 || raw.detail.summary_question !== void 0 || raw.detail.summary_unavailable !== void 0) && (raw.kind !== "comparison" || raw.detail.type !== "root_comparison")) return;
    const usedPaths = raw.line_ids.map((v) => paths.get(v));
    if (!raw.occurrence_ids.every(
      (v) => v === raw.root_occurrence_id || usedPaths.some((p) => p.occurrenceIds.includes(v))
    ))
      return;
    if (usedPaths.length && !raw.position_ids.every((v) => usedPaths.some((p) => p.positionIds?.includes(v))))
      return;
    const sourceRefs = [];
    for (const source of raw.source_refs) {
      if (!object(source) || !exactKeys(source, ["line_id", "kind", "source", "accepted_ply_count", "stop"]) || !id(source.line_id) || !raw.line_ids.includes(source.line_id) || !["supplied", "evaluation", "admitted"].includes(String(source.kind)) || ![
        "pgn_record",
        "analysis",
        "study",
        "direct_input",
        "root_search",
        "focus_comparison",
        "investigation_comparison",
        "response_comparison",
        "legal_replay"
      ].includes(String(source.source)) || !Number.isInteger(source.accepted_ply_count) || source.accepted_ply_count < 0 || source.accepted_ply_count > 600 || source.stop !== null && !["invalid_continuation", "automatic_terminal", "input_limit"].includes(String(source.stop)))
        return;
      if (source.kind === "supplied" && !paths.get(source.line_id)?.sources?.includes(source.source))
        return;
      if (source.accepted_ply_count < paths.get(source.line_id).moves.length) return;
      sourceRefs.push(source);
    }
    let decodedDetail = raw.detail;
    if (raw.kind === "comparison" && raw.detail.type === "question_comparison") {
      const detail = raw.detail, prefix = detail.prefix_moves_uci, refs = detail.question_refs, occurrenceIds = raw.occurrence_ids;
      if (!context || "highlight" in raw || !exactKeys(detail, [
        "type",
        "scope",
        "prefix_moves_uci",
        "reference_move",
        "alternative_move",
        "perspective",
        "question_refs",
        "evaluation_relation",
        "stop_reason",
        "text"
      ], ["effects", "summary"]) || detail.scope !== "same_position_pair" || !factMoves(prefix) || prefix.length >= 80 || !factMoves([detail.reference_move, detail.alternative_move]) || detail.reference_move === detail.alternative_move || !["white", "black"].includes(String(detail.perspective)) || typeof detail.text !== "string" || !detail.text.length || detail.text.length > 4e3 || ![null, "better", "equal", "worse"].includes(detail.evaluation_relation) || !(detail.stop_reason === null || factText(detail.stop_reason)) || !Array.isArray(refs) || !refs.length || refs.length > 600 || !refs.every((ref) => object(ref) && exactKeys(ref, ["proposal_id", "requirement_id"]) && proposalId(ref.proposal_id) && proposalId(ref.requirement_id)) || new Set(refs.map((ref) => `${ref.proposal_id}/${ref.requirement_id}`)).size !== refs.length || !["selected", "context"].includes(String(raw.selection)) || !usedPaths.length) return;
      const readings = refs.flatMap((ref) => {
        const reading = proposals?.find((proposal) => proposal.id === ref.proposal_id)?.requirements.find((reading2) => reading2.id === ref.requirement_id);
        return reading?.kind === "compare_moves" ? [reading] : [];
      });
      if (readings.length !== refs.length || readings.some(
        (reading) => reading.prefix_moves_uci.length !== prefix.length || !factPrefix(prefix, reading.prefix_moves_uci) || reading.reference_move !== detail.reference_move || reading.alternative_move !== detail.alternative_move || reading.stop_reason !== detail.stop_reason
      )) return;
      const answer = readings[0].answer;
      if (readings.some((reading) => answer === null ? reading.answer !== null : reading.answer === null || Object.entries(answer).some(([key, value2]) => JSON.stringify(reading.answer[key]) !== JSON.stringify(value2)))) return;
      const comparisonId = usedPaths[0].positionIds?.[prefix.length];
      const comparison = observations.positions?.find((position) => position.id === comparisonId);
      const actualRootPath = observations.paths.find(
        (path) => path.kind !== "history" && path.startFen === context.rootFen && path.moves[0]?.uci === context.playedMove && path.occurrenceIds[0] === raw.root_occurrence_id
      );
      if (!comparison || !raw.position_ids.includes(comparison.id) || !actualRootPath || !prefix.length && (comparison.id !== actualRootPath.positionIds?.[0] || comparison.fen !== context.rootFen) || usedPaths.some(
        (path) => path.kind === "history" || path.startFen !== context.rootFen || path.positionIds?.[prefix.length] !== comparison.id || !factPrefix(prefix, path.moves.map((move) => move.uci))
      )) return;
      try {
        const position = setupPosition("chess", parseFen(comparison.fen).unwrap()).unwrap();
        if (detail.perspective !== position.turn || ![detail.reference_move, detail.alternative_move].every((uci2) => {
          const move = parseUci(uci2);
          return move && position.isLegal(move);
        })) return;
      } catch (_) {
        return;
      }
      if (answer) {
        if (detail.evaluation_relation !== answer.evaluation_relation || !sameIds(raw.line_ids, [answer.reference_line_id, answer.alternative_line_id]) || ![answer.reference_occurrence_id, answer.alternative_occurrence_id].every((id2) => occurrenceIds.includes(id2))) return;
      } else if (raw.selection !== "context" || detail.evaluation_relation !== null) return;
    } else if (raw.kind === "comparison" && raw.detail.type === "line_continuation_comparison") {
    } else if (raw.kind === "comparison" && raw.detail.type === "target_response_comparison") {
      try {
        const detail = decodeTargetResponse(raw, observations, responseInquiries ?? []);
        if (!detail) return;
        decodedDetail = detail;
      } catch (_) {
        return;
      }
    } else if (raw.kind === "comparison" && raw.detail.type === "pv_comparison") {
      try {
        const detail = decodePvComparison(raw, observations, context);
        if (!detail) return;
        decodedDetail = detail;
      } catch (_) {
        return;
      }
    } else if (raw.kind === "comparison") {
      const detail = raw.detail;
      const reference = detail.reference_line_id;
      const candidate = detail.candidate_line_id;
      const available = (value2) => value2 === null || id(value2) && raw.line_ids.includes(value2);
      if (raw.detail.type !== "root_comparison" || !exactKeys(detail, [
        "type",
        "scope",
        "comparison_evidence_id",
        "comparison_kind",
        "reference_line_id",
        "candidate_line_id",
        "missing_line_ids",
        "material_relation",
        "material_unavailable_reason",
        "text"
      ], ["perspective", "reference_net_cp", "candidate_net_cp", "effects", "summary", "summary_kind", "summary_exchange", "summary_question", "summary_unavailable"]) || detail.summary_unavailable !== void 0 && (!object(detail.summary_unavailable) || !exactKeys(detail.summary_unavailable, ["question", "reason"]) || !id(detail.summary_unavailable.question) || !detail.summary_unavailable.question.trim() || detail.summary_unavailable.reason !== "answer_not_delivered" || ["summary", "summary_kind", "summary_exchange", "summary_question"].some((key) => key in detail)) || detail.summary_kind !== void 0 && (!["observed_convergence", "exchange_retention", "question_answer"].includes(String(detail.summary_kind)) || typeof detail.summary !== "string") || detail.summary_kind === "exchange_retention" !== (detail.summary_exchange !== void 0) || detail.summary_kind === "question_answer" !== (detail.summary_question !== void 0) || !available(reference) || !available(candidate) || reference !== null && reference === candidate || !ids(detail.missing_line_ids) || detail.missing_line_ids.some((v) => paths.has(v)) || detail.missing_line_ids.length !== Number(reference === null) + Number(candidate === null) || !id(detail.comparison_evidence_id) || !raw.evidence_ids.includes(detail.comparison_evidence_id) || !["played_vs_best", "best_vs_second"].includes(String(detail.comparison_kind)) || detail.scope !== "observed_lines")
        return;
      if (detail.summary_exchange !== void 0) {
        try {
          const exchange = decodeExchangeSummary(detail.summary_exchange, usedPaths, raw.evidence_ids);
          if (!exchange || detail.material_relation === "unavailable") return;
          decodedDetail = { ...detail, summary_exchange: exchange };
        } catch (_) {
          return;
        }
      }
      if (detail.summary_question !== void 0) {
        const question = decodeQuestionSummary(detail.summary_question, usedPaths, raw.evidence_ids, detail.summary, sourceRefs, observations, proposals, context?.playedMove, responseInquiries, responseSearches);
        if (!question || detail.material_relation === "unavailable") return;
        decodedDetail = { ...detail, summary_question: question };
      }
      const unavailable = detail.material_relation === "unavailable";
      if (!["different", "equal", "unavailable"].includes(String(detail.material_relation)) || !unavailable && detail.material_unavailable_reason !== null || unavailable && !["missing_path", "incomplete_line", "material_evidence_unavailable"].includes(
        String(detail.material_unavailable_reason)
      ) || (reference === null || candidate === null) && detail.material_unavailable_reason !== "missing_path" || reference !== null && candidate !== null && detail.material_unavailable_reason === "missing_path")
        return;
      const left = reference === null ? void 0 : paths.get(reference)?.lineSummary;
      const right = candidate === null ? void 0 : paths.get(candidate)?.lineSummary;
      if (!unavailable && (!left?.material || !right?.material)) return;
      if (!unavailable && left && right && exchangeSignature(left) === exchangeSignature(right) !== (detail.material_relation === "equal"))
        return;
      const hasMaterial = ["perspective", "reference_net_cp", "candidate_net_cp"].some((k) => k in detail);
      if (hasMaterial && (!left?.material || !right?.material || detail.perspective !== left.perspective || left.perspective !== right.perspective || detail.reference_net_cp !== left.material.net_cp || detail.candidate_net_cp !== right.material.net_cp))
        return;
      if (unavailable ? hasMaterial : !hasMaterial) return;
      if (!unavailable && !raw.line_ids.every(
        (lineId) => sourceRefs.some(
          (source) => source.line_id === lineId && (source.stop === null || source.stop === "automatic_terminal") && source.accepted_ply_count === paths.get(lineId).moves.length
        )
      ))
        return;
    } else if (raw.kind === "conditional_line") {
      if (raw.detail.type === "line_continuation") {
        try {
          const detail = decodeLineContinuation(raw, observations);
          if (!detail) return;
          decodedDetail = detail;
        } catch (_) {
          return;
        }
      } else if (raw.detail.type !== "observed_line" || raw.detail.scope !== "observed_line" || raw.line_ids.length !== 1 || raw.selection !== "context")
        return;
    }
    candidates.push({
      id: raw.id,
      kind: raw.kind,
      selection: raw.selection,
      rootOccurrenceId: raw.root_occurrence_id,
      occurrenceIds: raw.occurrence_ids,
      positionIds: raw.position_ids,
      lineIds: raw.line_ids,
      evidenceIds: raw.evidence_ids,
      sourceRefs,
      detail: decodedDetail
    });
  }
  if (new Set(candidates.map((c) => c.id)).size !== candidates.length) return;
  const byId = new Map(candidates.map((c) => [c.id, c]));
  try {
    if (candidates.some(
      (candidate) => continuationComparisonDetail(candidate) && !validContinuationComparison(candidate, byId, observations)
    ))
      return;
  } catch (_) {
    return;
  }
  const linkedProfiles = (idsValue, lineIds, root) => ids(idsValue) && idsValue.every((id2) => {
    const candidate = byId.get(id2);
    const detail = candidate && lineContinuationDetail(candidate);
    return !!candidate && candidate.rootOccurrenceId === root && !!detail && lineIds.includes(detail.line_id);
  });
  const linkedComparisons = (idsValue, lineIds, root) => ids(idsValue) && idsValue.every((id2) => {
    const candidate = byId.get(id2);
    return !!candidate && candidate.rootOccurrenceId === root && !!continuationComparisonDetail(candidate) && candidate.lineIds.every((line) => lineIds.includes(line));
  });
  const continuationByLine = new Map(
    candidates.flatMap((candidate) => {
      const detail = lineContinuationDetail(candidate);
      return detail ? [[detail.line_id, detail]] : [];
    })
  );
  const continuationPaths = new Map(observations.paths.map((path) => [path.id, path]));
  const continuationPieces = /* @__PURE__ */ new Map();
  const continuationPiecesAt = (path, ply) => {
    const snapshots = continuationPieces.get(path) ?? /* @__PURE__ */ new Map();
    if (!snapshots.has(ply)) snapshots.set(ply, trackedPieces(path, ply) ?? []);
    continuationPieces.set(path, snapshots);
    return snapshots.get(ply);
  };
  const withEffects = candidates.filter((candidate) => candidate.detail.effects !== void 0);
  if (withEffects.length) {
    const observationSources = /* @__PURE__ */ new Map();
    const statementsAt = /* @__PURE__ */ new Map();
    for (const statement of observations.statements) {
      const statements = statementsAt.get(statement.occurrenceId) ?? [];
      statements.push(statement);
      statementsAt.set(statement.occurrenceId, statements);
      const sources = observationSources.get(statement.occurrenceId) ?? /* @__PURE__ */ new Set();
      for (const id2 of statement.premiseIds) sources.add(id2);
      if (statement.kind === "piece_control")
        for (const id2 of [...statement.before.premiseIds, ...statement.after.premiseIds]) sources.add(id2);
      observationSources.set(statement.occurrenceId, sources);
    }
    const positionSources = /* @__PURE__ */ new Map();
    const sourcesAt = (id2) => {
      const cached = positionSources.get(id2);
      if (cached) return cached;
      const position = positions.get(id2);
      if (!position) return;
      const sources = /* @__PURE__ */ new Set([
        position.premise_id,
        ...position.controls.pieces.flatMap((piece) => piece.source_ids),
        ...position.rays.lines.map((ray2) => ray2.source_id),
        ...position.legal_moves.moves.map((move) => move.source_id),
        ...position.pawn_states.pawns.flatMap((pawn) => pawn.source_ids),
        ...position.pawn_files.files.flatMap((file) => file.source_ids),
        ...position.pawn_advances.paths.map((advance) => advance.source_id)
      ]);
      positionSources.set(id2, sources);
      return sources;
    };
    const proposalById = new Map(proposals?.map((proposal) => [proposal.id, proposal]));
    const selectedContact = (candidate, path, ply, actor, target, square, evidenceIds) => {
      if (candidate.detail.type !== "question_comparison") return false;
      const refs = candidate.detail.question_refs;
      const physical = (piece, original) => !!piece && piece.side === original.side && piece.role === original.role && piece.square === original.square;
      const sampled = (fact, value2, line) => fact.result?.samples.some((sample) => sample.state === "known" && sample.value === value2 && sample.from_ply === ply && sample.through_ply === ply && (line === void 0 || sample.line_id === line));
      return refs.some((ref) => {
        const proposal = proposalById.get(ref.proposal_id);
        const comparison = proposal?.requirements.find((reading) => reading.id === ref.requirement_id);
        if (comparison?.kind !== "compare_moves" || !comparison.answer) return false;
        const answer = comparison.answer;
        const facts = proposal.requirements.filter((reading) => reading.kind === "fact" && ["supported", "observed"].includes(reading.state) && !!reading.result && !reading.result.needs.length);
        return facts.some((current) => {
          const source = current.path.source;
          if (source.kind !== "comparison" || source.requirement_id !== ref.requirement_id || (source.arm === "reference" ? answer.reference_line_id : answer.alternative_line_id) !== path.id || current.at.kind !== "event" || current.at.phase !== "after" || current.at.from_ply !== ply - 1 || current.at.through_ply !== ply || current.predicate.kind !== "location" || current.expected === void 0 || !sampled(current, current.expected, path.id)) return false;
          return facts.some((cause) => {
            const declared = cause.path.source;
            if (declared.kind !== "declared" || declared.moves_uci.length !== ply || !factPrefix(declared.moves_uci, path.moves.map((move) => move.uci)) || JSON.stringify(cause.at) !== JSON.stringify(current.at) || JSON.stringify(cause.through) !== JSON.stringify(current.through) || JSON.stringify(cause.predicate) !== JSON.stringify(current.predicate) || cause.expected !== current.expected || !sampled(cause, current.expected)) return false;
            const atContact = (fact) => fact.path.binding === cause.path.binding && fact.path.source.kind === "declared" && JSON.stringify(fact.path.source.moves_uci) === JSON.stringify(declared.moves_uci) && fact.at.kind === "ply" && fact.at.ply_count === ply;
            if (facts.some((fact) => atContact(fact) && fact.predicate.kind === "location" && physical(fact.predicate.subject, target) && sampled(fact, square)) && facts.some((fact) => atContact(fact) && fact.predicate.kind === "control" && physical(fact.predicate.subject, actor) && fact.predicate.square === square && sampled(fact, "present"))) return true;
            if (!physical(cause.predicate.subject, actor) || cause.at.kind !== "event" || cause.at.actor !== void 0 && !physical(cause.at.actor, actor)) return false;
            const before = continuationPiecesAt(path, ply - 1), after = continuationPiecesAt(path, ply);
            const actorBefore = before.find((piece) => samePiece(piece.original, actor))?.current;
            const actorAfter = after.find((piece) => samePiece(piece.original, actor))?.current;
            const targetBefore = before.find((piece) => samePiece(piece.original, target))?.current;
            const targetAfter = after.find((piece) => samePiece(piece.original, target))?.current;
            if (!actorBefore || !actorAfter || !targetBefore || !targetAfter || targetAfter.square !== square || path.moves[ply - 1]?.uci.slice(0, 2) !== actorBefore.square || cause.expected !== actorAfter.square) return false;
            const beforePosition = positions.get(path.positionIds?.[ply - 1] ?? "");
            const afterPosition = positions.get(path.positionIds?.[ply] ?? "");
            const beforeControl = beforePosition?.controls.pieces.find((row) => physical(row.piece, actorBefore));
            const afterControl = afterPosition?.controls.pieces.find((row) => physical(row.piece, actorAfter));
            const contact = afterControl?.squares.indexOf(targetAfter.square) ?? -1;
            return !!beforePosition?.controls.complete && !beforeControl?.squares.includes(targetBefore.square) && !!afterPosition && contact >= 0 && evidenceIds.includes(beforePosition.premise_id) && evidenceIds.includes(afterPosition.premise_id) && evidenceIds.includes(afterControl.source_ids[contact]);
          });
        });
      });
    };
    try {
      for (const candidate of withEffects) {
        const effects = candidate.detail.effects;
        if (!context || candidate.kind !== "comparison" || !["root_comparison", "pv_comparison", "question_comparison"].includes(candidate.detail.type) || !Array.isArray(effects) || !effects.length || effects.length > 600) return;
        const functionUses = [];
        const dependencyOrder = (effect) => effect.attack_ply !== void 0 ? 2 : effect.scope === "check_sequence" ? 1 : 0;
        for (const effect of [...effects].sort((a, b) => dependencyOrder(a) - dependencyOrder(b))) {
          let functionalUse = false;
          let supportLossOffset;
          if (!object(effect) || !exactKeys(effect, [
            "scope",
            "line_ids",
            "prefix_moves_uci",
            "through_plies",
            "actor",
            "target",
            "square",
            "occurrence_ids",
            "evidence_ids",
            ..."attack_ply" in effect ? ["attack_ply"] : []
          ]) || ![
            "pair_difference",
            "line_history",
            "check_sequence",
            "support_handoff",
            "support_use",
            "support_retention",
            "piece_route",
            "blocker_handoff",
            "clearance_use",
            "pawn_option",
            "capture_choice",
            "advance_choice",
            "relative_pin",
            "capture_release"
          ].includes(effect.scope) || !ids(effect.line_ids) || !effect.line_ids.every((line) => candidate.lineIds.includes(line)) || !factMoves(effect.prefix_moves_uci) || effect.prefix_moves_uci.length >= 80 || !Array.isArray(effect.through_plies) || effect.through_plies.length !== effect.line_ids.length || !object(effect.actor) || !exactKeys(effect.actor, ["position_id", "side", "role", "square"]) || effect.target !== null && (!object(effect.target) || !exactKeys(effect.target, ["position_id", "side", "role", "square"])) || typeof effect.square !== "string" || parseSquare(effect.square) === void 0 || !ids(effect.occurrence_ids) || !effect.occurrence_ids.length || !ids(effect.evidence_ids) || !effect.evidence_ids.length) return;
          const prefix = effect.prefix_moves_uci, index = prefix.length;
          if ("attack_ply" in effect && (effect.scope !== "line_history" || !integer(effect.attack_ply, index + 2, 599))) return;
          const expectedPrefix = candidate.detail.type === "question_comparison" ? candidate.detail.prefix_moves_uci : [];
          const pair = effect.scope === "pair_difference", checkSequence = effect.scope === "check_sequence";
          const choice = ["pawn_option", "capture_choice", "advance_choice"].includes(effect.scope);
          if (JSON.stringify(prefix) !== JSON.stringify(expectedPrefix) || (pair || choice ? effect.line_ids.length !== 2 || !sameIds(effect.line_ids, candidate.lineIds) : effect.line_ids.length !== 1) || !pair && effect.scope !== "pawn_option" && effect.target === null) return;
          const used = effect.line_ids.map((id2) => paths.get(id2));
          if (used.some((path, n) => path.kind === "history" || path.startFen !== context.rootFen || !factPrefix(prefix, path.moves.map((move) => move.uci)) || path.positionIds?.[index] !== used[0].positionIds?.[index] || path.occurrenceIds.slice(0, index).some((id2, at) => id2 !== used[0].occurrenceIds[at]) || !integer(effect.through_plies[n], index + 1, path.moves.length) || pair && ![index + 1, index + 2].includes(effect.through_plies[n]))) return;
          if (pair && (effect.through_plies.filter((ply) => ply === index + 2).length > 1 || effect.target !== null && effect.through_plies.some((ply) => ply !== index + 1))) return;
          const anchor = index + (pair || choice || effect.scope === "capture_release" ? 0 : 1);
          const pieces = continuationPiecesAt(used[0], anchor);
          const actor = pieces.find((piece) => samePiece(piece.current, effect.actor));
          const target = effect.target === null ? void 0 : pieces.find((piece) => samePiece(piece.current, effect.target));
          if (!actor || (effect.target !== null ? !target || pair && target.current.square !== effect.square || !checkSequence && samePiece(target.original, actor.original) : pieces.some((piece) => piece.current.square === effect.square))) return;
          const controlled = (path, count, reverse = false) => {
            const at = continuationPiecesAt(path, count);
            const currentActor = at.find((piece) => samePiece(
              piece.original,
              reverse ? target.original : actor.original
            ))?.current;
            const currentTarget = target && at.find((piece) => samePiece(
              piece.original,
              reverse ? actor.original : target.original
            ))?.current;
            if (!currentActor || (target ? !currentTarget : at.some((piece) => piece.current.square === effect.square))) return;
            const square = currentTarget?.square ?? effect.square;
            const resource = positions.get(path.positionIds?.[count] ?? "");
            const control = resource?.controls.pieces.find((row) => row.piece.side === currentActor.side && row.piece.role === currentActor.role && row.piece.square === currentActor.square);
            return control?.squares.includes(square) ? true : resource?.controls.complete ? false : void 0;
          };
          if (choice || effect.scope === "relative_pin" || effect.scope === "capture_release") {
            const at = (path, original, count) => continuationPiecesAt(path, count).find((piece) => samePiece(piece.original, original))?.current;
            const located = (left, right) => !!left && !!right && left.side === right.side && left.role === right.role && left.square === right.square;
            const position = (path, count) => positions.get(path.positionIds?.[count] ?? "");
            const legal = (path, count) => {
              const resource = position(path, count);
              return resource?.legal_moves.complete ? resource.legal_moves.moves.find((move) => move.uci === path.moves[count]?.uci && effect.evidence_ids.includes(move.source_id)) : void 0;
            };
            const control = (path, count, provider, square) => {
              const piece = at(path, provider, count);
              const row = position(path, count)?.controls.pieces.find((row2) => located(row2.piece, piece));
              const offset = row?.squares.indexOf(square) ?? -1;
              return offset >= 0 && effect.evidence_ids.includes(row.source_ids[offset]);
            };
            const advance = (path, count, original, destination, traversed) => {
              const piece = at(path, original, count);
              return position(path, count)?.pawn_advances.paths.some((row) => located(row.piece, piece) && row.destination === destination && JSON.stringify(row.traversed_squares) === JSON.stringify(traversed) && effect.evidence_ids.includes(row.source_id));
            };
            if (!sameIds(effect.occurrence_ids, [...new Set(used.flatMap((path, n) => path.occurrenceIds.slice(index, effect.through_plies[n]).map((id2) => id2 ?? "")))])) return;
            for (const [n, path] of used.entries()) {
              if (!legal(path, index)) return;
              for (let count = index; count <= effect.through_plies[n]; count++)
                if (!position(path, count) || !effect.evidence_ids.includes(position(path, count).premise_id)) return;
            }
            if (effect.scope === "pawn_option") {
              const [kept, changed] = used, through = effect.through_plies[0], last = through - 1;
              const home = actor.current.side === "white" ? "2" : "7";
              const step = `${actor.current.square[0]}${actor.current.side === "white" ? "3" : "6"}`;
              const destination = `${actor.current.square[0]}${actor.current.side === "white" ? "4" : "5"}`;
              const changedMove = legal(changed, index);
              if (actor.current.role !== "pawn" || actor.current.square[1] !== home || effect.square !== destination || effect.through_plies[1] !== index + 1 || changedMove.uci !== actor.current.square + step || changedMove.captured_square !== void 0 || !located(at(kept, actor.original, index + 1), actor.current) || !advance(kept, index, actor.original, destination, [step, destination]) || !advance(kept, index + 1, actor.original, destination, [step, destination])) return;
              if (through === index + 1) {
                if (target) return;
              } else {
                const move = legal(kept, last), finalActor = at(kept, actor.original, through);
                if (!move || move.uci !== actor.current.square + destination || move.captured_square !== void 0 || finalActor?.role !== "pawn" || finalActor.square !== destination || !advance(kept, last, actor.original, destination, [step, destination])) return;
                for (let count = index + 1; count <= last; count++)
                  if (!located(at(kept, actor.original, count), actor.current)) return;
                if (target) {
                  const supported = at(kept, target.original, through);
                  if (target.current.side !== actor.current.side || !supported || !control(kept, through, actor.original, supported.square)) return;
                }
              }
            } else if (effect.scope === "capture_choice") {
              const [kept, changed] = used, victim = target;
              const first = legal(kept, index), second = legal(changed, index);
              const capturer = continuationPiecesAt(kept, index).find((piece) => piece.current.square === first.uci.slice(0, 2));
              const after = capturer && at(kept, capturer.original, index + 1);
              if (effect.through_plies.some((ply) => ply !== index + 1) || actor.current.side === victim.current.side || effect.square !== victim.current.square || first.captured_square !== effect.square || second.captured_square !== effect.square || first.destination !== effect.square || second.destination !== effect.square || second.uci.slice(0, 2) !== actor.current.square || !capturer || samePiece(capturer.original, actor.original) || capturer.current.side !== actor.current.side || !after || after.square !== effect.square || !located(at(kept, actor.original, index + 1), actor.current) || used.some((path) => at(path, victim.original, index + 1)) || !control(kept, index + 1, actor.original, after.square)) return;
            } else if (effect.scope === "advance_choice") {
              const [blocked, usedAdvance] = used, blocker = target;
              const destination = effect.square;
              const available = position(blocked, index)?.pawn_advances.paths.find((row) => located(row.piece, actor.current) && row.destination === destination && effect.evidence_ids.includes(row.source_id));
              if (!available) return;
              const traversed = available.traversed_squares;
              const blockingMove = legal(blocked, index), reply = legal(usedAdvance, index + 1);
              const stopped = position(blocked, index + 1);
              if (actor.current.role !== "pawn" || blocker.current.role !== "pawn" || actor.current.side === blocker.current.side || effect.through_plies[0] !== index + 1 || effect.through_plies[1] !== index + 2 || blockingMove.uci.slice(0, 2) !== blocker.current.square || blockingMove.destination !== destination || blockingMove.captured_square !== void 0 || at(blocked, blocker.original, index + 1)?.square !== destination || !located(at(blocked, actor.original, index + 1), actor.current) || !stopped.pawn_advances.complete || stopped.pawn_advances.paths.some((row) => located(row.piece, actor.current) && row.destination === destination) || !advance(blocked, index, actor.original, destination, traversed) || !located(at(usedAdvance, actor.original, index + 1), actor.current) || !located(at(usedAdvance, blocker.original, index + 2), blocker.current) || !advance(usedAdvance, index + 1, actor.original, destination, traversed) || !reply || reply.uci !== actor.current.square + destination || reply.captured_square !== void 0 || at(usedAdvance, actor.original, index + 2)?.square !== destination) return;
            } else if (effect.scope === "relative_pin") {
              const path = used[0], through = effect.through_plies[0], front = target;
              const rear = pieces.find((piece) => piece.current.square === effect.square);
              const value2 = { pawn: 1, knight: 3, bishop: 3, rook: 5, queen: 9, king: 100 };
              if (!["bishop", "rook", "queen"].includes(actor.current.role) || !rear || rear.current.role === "king" || front.current.role === "king" || front.current.side === actor.current.side || rear.current.side !== front.current.side || value2[rear.current.role] <= value2[front.current.role]) return;
              const aligned = (count) => {
                const resource = position(path, count);
                if (!resource?.rays.complete) return;
                const pinner = at(path, actor.original, count), pinned = at(path, front.original, count), behind = at(path, rear.original, count);
                if (!pinner || !pinned || !behind || behind.role === "king" || value2[behind.role] <= value2[pinned.role]) return false;
                const ray2 = resource.rays.lines.find((ray3) => located(ray3.piece, pinner) && located(ray3.occupants[0], pinned) && located(ray3.occupants[1], behind));
                return ray2 ? effect.evidence_ids.includes(ray2.source_id) ? true : void 0 : false;
              };
              for (let count = anchor; count <= through; count++) {
                const present = aligned(count);
                if (present === void 0 || !present && (count === anchor || count !== through)) return;
                if (count === through && present && through !== path.moves.length) return;
              }
              if (through > anchor && !legal(path, through - 1)) return;
            } else {
              const path = used[0], victim = target, through = effect.through_plies[0];
              const releasedAt = index + 1;
              const move = legal(path, index), before = position(path, index), after = position(path, releasedAt);
              const king = pieces.find((piece) => piece.current.square === move.uci.slice(0, 2));
              const kingAfter = king && at(path, king.original, releasedAt);
              if (![releasedAt, releasedAt + 1].includes(through) || actor.current.role === "king" || victim.current.role === "king" || actor.current.side === victim.current.side || effect.square !== victim.current.square || actor.current.role === "pawn" && ["1", "8"].includes(effect.square[1]) || !king || king.current.role !== "king" || king.current.side !== actor.current.side || !kingAfter || move.captured_square !== void 0 || Math.max(
                Math.abs(king.current.square.charCodeAt(0) - kingAfter.square.charCodeAt(0)),
                Math.abs(Number(king.current.square[1]) - Number(kingAfter.square[1]))
              ) !== 1 || !located(at(path, actor.original, releasedAt), actor.current) || !located(at(path, victim.original, releasedAt), victim.current) || !before.rays.complete || !control(path, index, actor.original, effect.square) || !control(path, releasedAt, actor.original, effect.square)) return;
              if (through === releasedAt + 1) {
                const reply = legal(path, releasedAt), movedTarget = at(path, victim.original, through);
                if (!reply || reply.uci.slice(0, 2) !== victim.current.square || !movedTarget || movedTarget.square !== reply.destination) return;
              }
              const ray2 = before.rays.lines.find((ray3) => ray3.piece.side !== actor.current.side && located(ray3.occupants[0], actor.current) && located(ray3.occupants[1], king.current) && effect.evidence_ids.includes(ray3.source_id));
              if (!ray2 || ray2.piece.square === effect.square || ray2.squares.includes(effect.square)) return;
              const pinner = pieces.find((piece) => located(piece.current, ray2.piece));
              if (!pinner || !located(at(path, pinner.original, releasedAt), pinner.current)) return;
              const frozenCapture = (resource) => {
                const frozen = setupPosition("chess", parseFen(resource.fen).unwrap()).unwrap();
                const from = parseSquare(actor.current.square), to = parseSquare(effect.square);
                const piece = frozen.board.get(from), captured = frozen.board.get(to);
                if (!piece || !captured || piece.color !== actor.current.side || piece.role !== actor.current.role || captured.color !== victim.current.side || captured.role !== victim.current.role || !attacks(piece, from, frozen.board.occupied).has(to)) return;
                frozen.board.take(from);
                frozen.board.set(to, piece);
                const square = frozen.board.kingOf(actor.current.side);
                return square === void 0 ? void 0 : frozen.kingAttackers(
                  square,
                  actor.current.side === "white" ? "black" : "white",
                  frozen.board.occupied
                );
              };
              const exposed = frozenCapture(before), released = frozenCapture(after);
              if (!exposed?.has(parseSquare(pinner.current.square)) || !released?.isEmpty()) return;
            }
          } else if (effect.attack_ply !== void 0) {
            const path = used[0], attackPly = effect.attack_ply, through = effect.through_plies[0];
            const beforeAttack = continuationPiecesAt(path, attackPly - 1);
            const mover = beforeAttack.find((piece) => piece.current.square === path.moves[attackPly - 1]?.uci.slice(0, 2));
            const afterAttack = continuationPiecesAt(path, attackPly);
            const attacker = afterAttack.find((piece) => samePiece(piece.original, actor.original));
            const victim = afterAttack.find((piece) => samePiece(piece.original, target.original));
            const position = positions.get(path.positionIds?.[attackPly] ?? "");
            const control = position?.controls.pieces.find((row) => attacker && row.piece.side === attacker.current.side && row.piece.role === attacker.current.role && row.piece.square === attacker.current.square);
            const controlIndex = victim ? control?.squares.indexOf(victim.current.square) : void 0;
            if (!target || actor.current.side === target.current.side || effect.square !== target.current.square || through !== path.moves.length || attackPly >= through || controlled(path, attackPly) !== true || controlIndex === void 0 || controlIndex < 0 || !position || !effect.evidence_ids.includes(position.premise_id) || !effect.evidence_ids.includes(control.source_ids[controlIndex]) || !effect.occurrence_ids.includes(path.occurrenceIds[attackPly - 1]) || attackPly !== index + 2 && !functionUses.some(({ effect: parent }) => parent.line_ids[0] === path.id && parent.through_plies[0] === attackPly && JSON.stringify(parent.prefix_moves_uci) === JSON.stringify(prefix) && // An evading slider may regain its attack when another piece
            // opens the line. Its validated use belongs to that same slider.
            (parent.scope === "line_history" && parent.target?.side !== parent.actor.side ? samePiece(parent.actor, actor.current) : !!mover && samePiece(mover.original, actor.original)) && parent.evidence_ids.every((id2) => effect.evidence_ids.includes(id2))) && !selectedContact(
              candidate,
              path,
              attackPly,
              actor.original,
              target.original,
              victim.current.square,
              effect.evidence_ids
            )) return;
          } else if (pair) {
            const relations = used.map((path) => controlled(path, index + 1));
            if (relations.some((value2) => value2 === void 0) || relations[0] === relations[1]) return;
            for (const [n, path] of used.entries()) {
              if (effect.through_plies[n] !== index + 2) continue;
              const before = continuationPiecesAt(path, index + 1).find((piece) => piece.current.square === path.moves[index + 1].uci.slice(0, 2));
              if (!before || continuationPiecesAt(path, index + 2).find((piece) => samePiece(piece.original, before.original))?.current.square !== effect.square) return;
            }
          } else if (checkSequence) {
            const path = used[0], through = effect.through_plies[0];
            if (!target || target.current.role !== "king" || target.current.square !== effect.square || !(statementsAt.get(path.occurrenceIds[index]) ?? []).some((statement) => statement.side === actor.current.side && statement.to === actor.current.square && continuationPiecesAt(path, index).some((piece) => samePiece(piece.original, actor.original) && piece.current.square === statement.from))) return;
            const eligible = /* @__PURE__ */ new Set([index, index + 1]);
            const material = path.lineSummary?.material;
            const captures = material?.events.filter((event) => event.capture) ?? [];
            if (index === 0 && captures.length >= 2 && captures[0].ply_offset <= 1) {
              const chain = [captures[0]];
              for (const capture of captures.slice(1)) {
                if (capture.ply_offset !== chain[chain.length - 1].ply_offset + 1) break;
                chain.push(capture);
              }
              if (chain.length >= 2 && !material.events.some((event) => event.promotion_gain_cp > 0 && event.ply_offset <= chain[chain.length - 1].ply_offset))
                for (const capture of chain) eligible.add(capture.ply_offset);
            }
            const selected = (offset) => statementsAt.get(path.occurrenceIds[offset]) ?? [];
            for (const { effect: parent, lossOffset } of functionUses)
              if (parent.line_ids[0] === path.id && JSON.stringify(parent.prefix_moves_uci) === JSON.stringify(prefix)) {
                if (parent.through_plies[0] <= through) eligible.add(parent.through_plies[0] - 1);
                if (lossOffset !== void 0 && lossOffset < through) eligible.add(lossOffset);
              }
            for (const start of [...eligible])
              for (let offset = start; offset < through && selected(offset).some((row) => row.kind === "check_responses"); offset += 2)
                eligible.add(offset);
            const checks = [...eligible].filter((offset) => offset < through).flatMap((offset) => selected(offset).filter((statement) => statement.kind === "check_responses").map((statement) => ({ offset, statement })));
            const responses = [.../* @__PURE__ */ new Set([index, ...checks.map((row) => row.offset + 1)])].filter((offset) => offset < path.moves.length).flatMap((offset) => selected(offset).filter((statement) => statement.kind === "check_response" && statement.response.resource.move_uci === path.moves[offset].uci).map((statement) => ({ offset, statement })));
            const rows = [...responses, ...checks].sort((a, b) => a.offset - b.offset);
            if (!rows.length || rows.some((row) => row.offset >= through) || through !== Math.max(index, ...rows.map((row) => row.offset)) + 1 || !sameIds(effect.occurrence_ids, [.../* @__PURE__ */ new Set([
              path.occurrenceIds[index],
              ...rows.map((row) => path.occurrenceIds[row.offset])
            ])]) || !rows.every((row) => row.statement.premiseIds.every((id2) => effect.evidence_ids.includes(id2)))) return;
            const first = rows[0].statement;
            const kingSide = first.kind === "check_responses" ? first.checked_side : first.kind === "check_response" ? first.responding_side : void 0;
            if (target.current.side !== kingSide) return;
          } else if (["support_handoff", "support_use", "support_retention", "piece_route", "blocker_handoff", "clearance_use"].includes(effect.scope)) {
            functionalUse = effect.scope !== "support_retention";
            const path = used[0], through = effect.through_plies[0], last = through - 1, related = target;
            const at = (original, count) => continuationPiecesAt(path, count).find((piece) => samePiece(piece.original, original))?.current;
            const located = (left, right) => !!left && !!right && left.side === right.side && left.role === right.role && left.square === right.square;
            const position = (count) => positions.get(path.positionIds?.[count] ?? "");
            const legal = (count) => {
              const resource = position(count);
              const move = resource?.legal_moves.complete && resource.legal_moves.moves.find((move2) => move2.uci === path.moves[count]?.uci && effect.evidence_ids.includes(move2.source_id));
              return move || void 0;
            };
            const rootMove = legal(index), finalMove = legal(last), originalActor = at(actor.original, index);
            if (through <= anchor || !rootMove || !finalMove || !originalActor || path.moves[index].uci.slice(0, 2) !== originalActor.square || rootMove.destination !== actor.current.square || !sameIds(effect.occurrence_ids, path.occurrenceIds.slice(index, through).map((id2) => id2 ?? "")) || !path.lineSummary?.premise_ids.length || !path.lineSummary.premise_ids.every((id2) => effect.evidence_ids.includes(id2))) return;
            for (let count = index; count <= through; count++)
              if (!position(count) || !effect.evidence_ids.includes(position(count).premise_id)) return;
            const rayAt = (count, original, square) => {
              const resource = position(count), piece = at(original, count);
              return resource?.rays.complete ? resource.rays.lines.find((ray2) => located(ray2.piece, piece) && ray2.squares.includes(square) && effect.evidence_ids.includes(ray2.source_id)) : void 0;
            };
            const controlAt = (original, count, square) => {
              const resource = position(count), piece = at(original, count);
              if (!resource || !piece) return;
              const control = resource.controls.pieces.find((row) => located(row.piece, piece));
              const offset = control?.squares.indexOf(square) ?? -1;
              return offset >= 0 ? effect.evidence_ids.includes(control.source_ids[offset]) ? true : void 0 : resource.controls.complete ? false : void 0;
            };
            const support = (original, count) => {
              const value2 = continuationSupportAt(
                observations,
                path,
                original,
                related.original,
                count,
                continuationPiecesAt(path, count)
              );
              return value2.source_ids.every((id2) => effect.evidence_ids.includes(id2)) ? value2.state : "unknown";
            };
            if (effect.scope === "support_retention") {
              if (actor.current.side !== related.current.side || effect.square !== related.current.square || support(actor.original, index) !== "absent") return;
              const previous = continuationPiecesAt(path, last).find((piece) => piece.current.square === path.moves[last].uci.slice(0, 2));
              const departed = previous && at(previous.original, through);
              if (!previous || !departed || previous.current.side !== actor.current.side || samePiece(previous.original, actor.original) || samePiece(previous.original, related.original) || located(previous.current, departed) || finalMove.destination !== departed.square) return;
              for (let count = anchor; count <= through; count++)
                if (support(actor.original, count) !== "present") return;
              for (let count = index; count <= last; count++)
                if (support(previous.original, count) !== "present") return;
              if (support(previous.original, through) !== "absent") return;
            } else if (effect.scope === "support_handoff" || effect.scope === "support_use") {
              const usedSupport = effect.scope === "support_use";
              if (actor.current.side !== related.current.side || !usedSupport && effect.square !== related.current.square) return;
              const material = path.lineSummary.material;
              const recovery = material?.events.find((event) => event.ply_offset === last && event.capture);
              const beforeRecovery = continuationPiecesAt(path, last);
              const provider = beforeRecovery.find((piece) => piece.current.square === path.moves[last].uci.slice(0, 2));
              const capturer = recovery?.capture && beforeRecovery.find((piece) => piece.current.square === recovery.capture.square);
              if (!recovery || !provider || !capturer || provider.current.side !== related.current.side || capturer.current.side === related.current.side || finalMove.captured_square !== capturer.current.square || finalMove.destination !== at(provider.original, through)?.square) return;
              const loss = material.events.find((event) => event.ply_offset >= anchor && event.ply_offset < last && event.capture && at(related.original, event.ply_offset)?.square === event.capture.square && at(capturer.original, event.ply_offset)?.square === event.from);
              if (!loss || at(related.original, loss.ply_offset + 1)) return;
              supportLossOffset = loss.ply_offset;
              const lossMove = legal(loss.ply_offset), capturedAt = loss.ply_offset + 1;
              const providerAfterLoss = at(provider.original, capturedAt), enemyAfterLoss = at(capturer.original, capturedAt);
              const immediate = position(capturedAt);
              const immediateRecapture = immediate?.legal_moves.complete && immediate.legal_moves.moves.find((move) => move.uci.slice(0, 2) === providerAfterLoss?.square && move.captured_square === enemyAfterLoss?.square && move.destination === enemyAfterLoss?.square && effect.evidence_ids.includes(move.source_id));
              if (!lossMove || lossMove.captured_square !== loss.capture.square || !immediateRecapture) return;
              for (let count = capturedAt; count <= last; count++)
                if (!located(at(provider.original, count), providerAfterLoss) || !located(at(capturer.original, count), enemyAfterLoss)) return;
              if (usedSupport) {
                if (!samePiece(provider.original, actor.original) || loss.capture.square !== effect.square || lossMove.destination !== effect.square || finalMove.destination !== effect.square) return;
                for (let count = anchor; count <= loss.ply_offset; count++)
                  if (!located(at(provider.original, count), actor.current)) return;
                const oldTarget = at(related.original, index);
                const gainedSupport = oldTarget && controlAt(provider.original, index, oldTarget.square) === false && controlAt(provider.original, anchor, related.current.square) === true && Array.from({ length: loss.ply_offset - anchor + 1 }, (_, offset) => anchor + offset).every((count) => support(provider.original, count) === "present");
                if (!gainedSupport) {
                  if (related.current.square === effect.square || controlAt(provider.original, index, effect.square) !== false) return;
                  let arrived = false;
                  for (let count = anchor; count <= loss.ply_offset; count++) {
                    const victim = at(related.original, count);
                    if (!victim || controlAt(provider.original, count, effect.square) !== true) return;
                    if (victim.square === effect.square) arrived = true;
                    if (arrived ? victim.square !== effect.square || support(provider.original, count) !== "present" : continuationPiecesAt(path, count).some((piece) => piece.current.square === effect.square)) return;
                  }
                  if (!arrived) return;
                }
              } else {
                for (let count = anchor; count <= loss.ply_offset; count++)
                  if (support(provider.original, count) !== "present") return;
                const previous = continuationPiecesAt(path, index).filter((piece) => piece.current.side === related.current.side && !samePiece(piece.original, provider.original) && !samePiece(piece.original, related.original) && support(piece.original, index) === "present");
                const handedOff = previous.some((old) => {
                  let departure;
                  for (let count = anchor; count <= loss.ply_offset; count++) {
                    const state = support(old.original, count);
                    const absent = state === "absent" || state === "actor_removed";
                    if (departure !== void 0 && !absent) return false;
                    const before = at(old.original, count - 1);
                    if (departure === void 0 && absent && before && support(old.original, count - 1) === "present" && !located(before, at(old.original, count)))
                      departure = count;
                  }
                  return departure !== void 0 && (samePiece(provider.original, actor.original) || samePiece(old.original, actor.original) && departure === anchor);
                });
                if (!handedOff) return;
              }
            } else if (effect.scope === "piece_route") {
              const finalActor = at(actor.original, through), finalTarget = at(related.original, through);
              if (!finalActor || !finalTarget || finalActor.role !== actor.current.role || finalActor.side !== actor.current.side || finalActor.square !== effect.square || finalMove.destination !== effect.square || path.moves[last].uci.slice(0, 2) !== actor.current.square) return;
              for (let count = anchor; count <= last; count++)
                if (!located(at(actor.original, count), actor.current)) return;
              const controlChange = (reverse, before, after) => (statementsAt.get(path.occurrenceIds[last]) ?? []).some((statement) => {
                if (statement.kind !== "piece_control" || statement.before.state !== before || statement.after.state !== after)
                  return false;
                const controller = reverse ? related.original : actor.original;
                const victim = reverse ? actor.original : related.original;
                if (!located(statement.before.controller ?? void 0, at(controller, last)) || !located(statement.before.target ?? void 0, at(victim, last)) || !located(statement.after.controller ?? void 0, at(controller, through)) || !located(statement.after.target ?? void 0, at(victim, through))) return false;
                const aliases = [last, through].flatMap((count) => {
                  const resource = position(count), piece = at(controller, count), target2 = at(victim, count);
                  const control = resource.controls.pieces.find((row) => located(row.piece, piece));
                  const offset = target2 ? control?.squares.indexOf(target2.square) ?? -1 : -1;
                  const suffix = `:position-occurrence:${resource.id}`;
                  if (offset < 0 || !resource.premise_id.endsWith(suffix)) return [];
                  const source = control.source_ids[offset];
                  return effect.evidence_ids.includes(source) ? [`${resource.premise_id.slice(0, -suffix.length)}:relation:position:${resource.id}:geometric_control:${source}`] : [];
                });
                return [...statement.premiseIds, ...statement.before.premiseIds, ...statement.after.premiseIds].every((id2) => effect.evidence_ids.includes(id2) || aliases.includes(id2));
              });
              const beforeTarget = at(related.original, last);
              const gained = controlAt(actor.original, last, beforeTarget.square) === false && controlAt(actor.original, through, finalTarget.square) === true;
              const friendly = actor.current.side === related.current.side;
              const defended = !friendly || position(through).controls.pieces.some((control) => {
                const offset = control.squares.indexOf(finalTarget.square);
                return control.piece.side !== finalTarget.side && offset >= 0 && effect.evidence_ids.includes(control.source_ids[offset]);
              });
              const evaded = !friendly && controlAt(related.original, last, actor.current.square) === true && controlAt(related.original, through, finalActor.square) === false && controlChange(true, "present", "absent");
              const newRole = finalTarget.role !== "king" && controlChange(false, "absent", "present");
              if (!(gained && defended && newRole) && !evaded) return;
            } else if (effect.scope === "blocker_handoff") {
              if (!["bishop", "rook", "queen"].includes(related.current.role)) return;
              const beforeRay = rayAt(index, related.original, effect.square);
              const beforeSquares = beforeRay?.squares.slice(0, beforeRay.squares.indexOf(effect.square));
              if (!beforeRay || !beforeSquares || beforeSquares.includes(originalActor.square) || !beforeSquares.includes(actor.current.square)) return;
              const oldBlockers = continuationPiecesAt(path, index).filter((piece) => beforeSquares.includes(piece.current.square));
              const arriving = continuationPiecesAt(path, last).find((piece) => piece.current.square === path.moves[last].uci.slice(0, 2));
              if (!oldBlockers.length || !arriving || samePiece(arriving.original, actor.original) || arriving.current.side === related.current.side || finalMove.destination !== effect.square || at(arriving.original, through)?.square !== effect.square) return;
              for (let count = anchor; count <= through; count++)
                if (!located(at(actor.original, count), actor.current) || !located(at(related.original, count), related.current)) return;
              if (!rayAt(through, related.original, effect.square)) return;
              let departure;
              for (let count = anchor; count <= through; count++) {
                const occupants = continuationPiecesAt(path, count).filter((piece) => beforeSquares.includes(piece.current.square));
                const sole = occupants.length === 1 && samePiece(occupants[0].original, actor.original);
                if (departure === void 0 && count < through && sole) departure = count;
                if (departure !== void 0) {
                  const resource = position(count);
                  const control = resource.controls.pieces.find((row) => located(row.piece, related.current));
                  if (!sole || !resource.controls.complete || control?.squares.includes(effect.square)) return;
                }
              }
              if (departure === void 0) return;
            } else {
              if (actor.current.side !== related.current.side || !["bishop", "rook", "queen"].includes(at(related.original, through)?.role ?? "") || originalActor.square !== effect.square || actor.current.square === effect.square || path.moves[last].uci.slice(0, 2) !== at(related.original, last)?.square || finalMove.destination !== at(related.original, through)?.square) return;
              for (let count = anchor; count <= through; count++)
                if (continuationPiecesAt(path, count).some((piece) => piece.current.square === effect.square)) return;
              const clearThroughout = (squares) => {
                for (let count = anchor; count < through; count++)
                  if (continuationPiecesAt(path, count).some((piece) => squares.includes(piece.current.square) && !samePiece(piece.original, related.original))) return false;
                return true;
              };
              const ray2 = rayAt(last, related.original, finalMove.destination);
              const traversed = ray2?.squares.slice(0, ray2.squares.indexOf(finalMove.destination));
              const crossed = traversed?.includes(effect.square) && clearThroughout(traversed);
              const resource = position(through);
              const controller = resource.controls.pieces.find((control) => located(control.piece, at(related.original, through)));
              const usedAfter = !crossed && resource.controls.complete && controller?.squares.some((square, offset) => {
                if (!effect.evidence_ids.includes(controller.source_ids[offset]) || !continuationPiecesAt(path, through).some((piece) => piece.current.square === square)) return false;
                const afterRay = rayAt(through, related.original, square);
                const opened = afterRay?.squares.slice(0, afterRay.squares.indexOf(square));
                return !!opened?.includes(effect.square) && clearThroughout(opened) && !continuationPiecesAt(path, through).some((piece) => opened.includes(piece.current.square));
              });
              if (!crossed && !usedAfter) return;
            }
          } else {
            const path = used[0], through = effect.through_plies[0], victim = target;
            const at = (original, count) => continuationPiecesAt(path, count).find((piece) => samePiece(piece.original, original))?.current;
            const moved = (original, offset) => {
              const before = at(original, offset), after = at(original, offset + 1);
              return !!before && !!after && (before.square !== after.square || before.role !== after.role);
            };
            const located = (piece, expected) => !!piece && !!expected && piece.side === expected.side && piece.role === expected.role && piece.square === expected.square;
            const controlFact = (offset, controller, receiving, afterState) => statementsAt.get(path.occurrenceIds[offset])?.find((statement) => statement.kind === "piece_control" && statement.after.state === afterState && ["present", "absent"].includes(statement.before.state) && located(statement.before.controller, at(controller, offset)) && located(statement.before.target, at(receiving, offset)) && located(statement.after.controller, at(controller, offset + 1)) && located(statement.after.target, at(receiving, offset + 1)));
            const validHistory = () => {
              const friendly = actor.current.side === victim.current.side;
              const targetSquare = victim.current.square === effect.square;
              if (!friendly && targetSquare && controlled(path, anchor) === true && through === path.moves.length)
                return true;
              functionalUse = true;
              if (friendly && targetSquare) {
                const fact = controlFact(index, actor.original, victim.original, "present");
                return through === anchor && controlled(path, anchor) === true && fact?.kind === "piece_control" && (fact.before.state === "absent" || moved(actor.original, index) || moved(victim.original, index)) && sameIds(effect.occurrence_ids, [path.occurrenceIds[index]]);
              }
              if (!friendly && targetSquare) {
                const fact = controlFact(index, victim.original, actor.original, "absent");
                if (!moved(actor.original, index) || controlled(path, index, true) !== true || controlled(path, anchor, true) !== false || fact?.kind !== "piece_control" || fact.before.state !== "present") return false;
                const offsets = [index];
                if (through > anchor) {
                  const last = controlFact(through - 1, actor.original, victim.original, "present");
                  if (controlled(path, through) !== true || last?.kind !== "piece_control" || last.before.state !== "absent" && !moved(actor.original, through - 1)) return false;
                  for (let offset = anchor; offset < through; offset++)
                    if (moved(actor.original, offset)) offsets.push(offset);
                  offsets.push(through - 1);
                }
                return sameIds(effect.occurrence_ids, [...new Set(offsets.map((offset) => path.occurrenceIds[offset]))]);
              }
              if (!friendly || targetSquare || through <= anchor || at(actor.original, index)?.square !== effect.square || actor.current.square === effect.square || path.moves[index].uci.slice(0, 2) !== effect.square) return false;
              for (let count = anchor; count < through; count++) {
                const position = positions.get(path.positionIds?.[count] ?? "");
                if (!position || !effect.evidence_ids.includes(position.premise_id) || continuationPiecesAt(path, count).some((piece) => piece.current.square === effect.square)) return false;
              }
              return at(victim.original, through)?.square === effect.square && path.moves[through - 1].uci.slice(0, 2) === at(victim.original, through - 1)?.square && sameIds(effect.occurrence_ids, [path.occurrenceIds[index], path.occurrenceIds[through - 1]]);
            };
            if (!validHistory()) return;
          }
          const occurrences2 = new Set(used.flatMap((path, n) => path.occurrenceIds.slice(index, effect.through_plies[n])));
          if (!effect.occurrence_ids.every((id2) => occurrences2.has(id2) && effect.evidence_ids.includes(id2)) || !used.every((path) => effect.occurrence_ids.includes(path.occurrenceIds[index]))) return;
          const unresolved = new Set(effect.evidence_ids);
          for (const [n, path] of used.entries()) {
            for (const id2 of path.lineSummary?.premise_ids ?? []) unresolved.delete(id2);
            for (const occurrence of path.occurrenceIds.slice(0, effect.through_plies[n])) {
              if (!occurrence) return;
              unresolved.delete(occurrence);
              for (const id2 of observationSources.get(occurrence) ?? []) unresolved.delete(id2);
            }
            for (const id2 of path.positionIds?.slice(0, effect.through_plies[n] + 1) ?? []) {
              if (!unresolved.size) break;
              const sources = id2 ? sourcesAt(id2) : void 0;
              if (sources) {
                for (const ref of unresolved) if (sources.has(ref)) unresolved.delete(ref);
              }
            }
          }
          if (unresolved.size) return;
          if (functionalUse) functionUses.push({ effect, lossOffset: supportLossOffset });
        }
      }
    } catch (_) {
      return;
    }
  }
  const followupWitnesses = (peer, loss, recovery) => [...continuationByLine.values()].flatMap((detail) => {
    const path = continuationPaths.get(detail.line_id);
    if (!peer.occurrenceIds.every((id2, index) => path.occurrenceIds[index] === id2)) return [];
    const sameLoss = detail.events.find(
      (event) => event.occurrence_id === loss.occurrence_id && event.original_actor && loss.original_actor && samePiece(event.original_actor, loss.original_actor) && event.original_victim && loss.original_victim && samePiece(event.original_victim, loss.original_victim)
    );
    if (!sameLoss) return [];
    const outcomes = continuationRecoveries(detail, sameLoss.id);
    const material = path.lineSummary?.material;
    const sign = sameLoss.original_victim.side === path.lineSummary?.perspective ? 1 : -1;
    const observed = recovery ? detail.events.some(
      (event) => event.ply_offset > sameLoss.ply_offset && event.original_victim && recovery.original_victim && samePiece(event.original_victim, recovery.original_victim)
    ) || outcomes.length > 0 && !!material && material.net_cp * sign >= 0 : outcomes.some((event) => event.ply_offset >= peer.moves.length);
    return observed ? [path.id] : [];
  });
  const recaptureSourcesAt = (sourceLineIds, count) => sourceLineIds.flatMap((lineId) => {
    const detail = continuationByLine.get(lineId), path = continuationPaths.get(lineId);
    const position = observations.positions?.find((position2) => position2.id === path?.positionIds?.[count]);
    if (!detail || !path || !position?.legal_moves.complete) return [];
    const pieces = continuationPiecesAt(path, count);
    return [...detail.support_applications ?? [], ...detail.direct_support_recaptures ?? []].flatMap(
      (use) => {
        const comparison = detail.support_comparisons.find(
          (comparison2) => comparison2.id === use.comparison_id
        );
        if (comparison.kind !== "replacement_after_capture" || path.positionIds.indexOf(comparison.after_position_id) - 1 !== count)
          return [];
        const recovery = detail.events.find(
          (event) => event.ply_offset === count && event.original_actor && samePiece(event.original_actor, comparison.after_actor)
        );
        const capturer = recovery?.original_victim && pieces.find((piece) => samePiece(piece.original, recovery.original_victim))?.current;
        if (!capturer) return [];
        const rows = position.legal_moves.moves.filter((move) => move.captured_square === capturer.square);
        const actors = rows.flatMap(
          (move) => pieces.find((piece) => piece.current.square === move.uci.slice(0, 2))?.original.square ?? []
        );
        return actors.length === rows.length && new Set(actors).size >= 2 ? [
          {
            detail,
            path,
            recovery,
            use,
            comparison,
            moves: rows.map((move) => move.uci),
            triggers: continuationTriggerOrigins(detail, [
              ...comparison.trigger_occurrence_ids,
              "application" in use ? use.preceding_occurrence_id : use.recapture_occurrence_id
            ])
          }
        ] : [];
      }
    );
  });
  const readSupportUse = (path, source, count) => {
    const detail = continuationByLine.get(path.id);
    const comparison = detail?.support_comparisons.find(
      (comparison2) => comparison2.kind === "replacement_after_capture" && samePiece(comparison2.before_actor, source.comparison.before_actor) && path.positionIds.indexOf(comparison2.after_position_id) === count + 1
    );
    if (!detail || !comparison) return;
    if (!("application" in source.use)) {
      const use2 = source.use;
      const losses = detail.events.filter((event) => event.ply_offset > count && event.original_victim);
      const targetLoss = losses.find((event) => samePiece(event.original_victim, use2.original_target));
      return losses.some(
        (event) => samePiece(event.original_victim, comparison.after_actor) && (!targetLoss || event.ply_offset < targetLoss.ply_offset)
      ) || !!targetLoss && (!targetLoss.original_actor || !samePiece(targetLoss.original_actor, use2.original_capturer) || detail.capture_links.some((link) => link.loss_event_id === targetLoss.id));
    }
    const use = source.use;
    if (detail.events.some(
      (event) => event.ply_offset > count && event.original_victim && (samePiece(event.original_victim, source.use.original_target) || samePiece(event.original_victim, comparison.after_actor))
    ))
      return true;
    const base = path.positionIds.indexOf(comparison.after_position_id);
    return Array.from({ length: path.moves.length - base + 1 }, (_, offset) => base + offset).some((at) => {
      const point = kingCaptureAt(
        observations,
        path,
        comparison.after_actor,
        source.use.original_target,
        use.application.original_attacker,
        at,
        continuationPiecesAt(path, at)
      );
      return point && kingCaptureKey(point.application) === kingCaptureKey(use.application);
    });
  };
  const supportObservations = /* @__PURE__ */ new Map();
  const observesSupportUse = (path, source, count) => {
    const key = `${path.id}:${count}`;
    const values = supportObservations.get(key) ?? /* @__PURE__ */ new Map();
    if (!values.has(source.use)) values.set(source.use, readSupportUse(path, source, count));
    supportObservations.set(key, values);
    return values.get(source.use);
  };
  const continuationTriggersValid = (inquiry) => {
    const recaptureSources = recaptureSourcesAt(inquiry.source_line_ids, inquiry.prefix_moves_uci.length);
    const route = inquiry.route_challenge;
    if (route) {
      const searches = (responseSearches ?? []).filter((search) => responseSearchMatchesContinuation(search, inquiry)).sort((left, right) => Number(left.work_id.slice(5)) - Number(right.work_id.slice(5)));
      const reference = [...searches].reverse().find(
        (search) => search.root_restriction.kind === "unrestricted" || inquiry.legal_moves.every(
          (move) => search.root_restriction.kind === "restricted" && search.root_restriction.moves_uci.includes(move)
        )
      );
      if (!reference || inquiry.state !== "surveyed" || reference.work_id !== route.reference_work_id || reference.candidates[0].move_uci !== route.reference_move || reference.candidates[0].line_id !== route.reference_line_id)
        return false;
      const expected = /* @__PURE__ */ new Map();
      for (const lineId of inquiry.source_line_ids) {
        const detail = continuationByLine.get(lineId), path = continuationPaths.get(lineId);
        if (!detail || !path) continue;
        const count = inquiry.prefix_moves_uci.length;
        const pieces = (at) => continuationPiecesAt(path, at);
        const current = (actor, at) => pieces(at).find((piece) => samePiece(piece.original, actor))?.current;
        const recoveries = /* @__PURE__ */ new Set([
          ...detail.capture_links.map((link) => link.capture_event_id),
          ...detail.other_target_gains.map((link) => link.gain_event_id)
        ]);
        const rows = observations.positions.find((position) => position.id === inquiry.position_id).legal_moves.moves;
        for (const event of detail.events.filter(
          (event2) => event2.ply_offset >= count && recoveries.has(event2.id) && inquiry.trigger_occurrence_ids.includes(event2.occurrence_id)
        )) {
          const performer = event.original_actor && current(event.original_actor, count);
          const victim = event.original_victim && current(event.original_victim, count);
          const stationary = victim && Array.from(
            { length: event.ply_offset - count + 1 },
            (_, index) => current(event.original_victim, count + index)
          ).every(
            (piece) => piece && piece.side === victim.side && piece.role === victim.role && piece.square === victim.square
          );
          const moves = rows.filter(
            (row) => performer && row.captured_square === performer.square || stationary && row.uci.slice(0, 2) === victim.square
          ).map((row) => row.uci).sort();
          if (!moves.length) continue;
          const key = `recovery_route:${moves.join(" ")}`, group = expected.get(key) ?? { moves, occurrences: [], lines: [] };
          group.occurrences.push(event.occurrence_id);
          group.lines.push(lineId);
          expected.set(key, group);
        }
      }
      for (const source of recaptureSources.filter(
        (source2) => source2.triggers.every((id2) => inquiry.trigger_occurrence_ids.includes(id2))
      )) {
        for (const move of source.moves) {
          const key = `replacement_recapture:${move}`;
          const group = expected.get(key) ?? { moves: [move], occurrences: [], lines: [] };
          group.occurrences.push(source.recovery.occurrence_id);
          group.lines.push(source.path.id);
          expected.set(key, group);
        }
      }
      for (const lineId of inquiry.source_line_ids) {
        const detail = continuationByLine.get(lineId);
        for (const exposure of detail?.capture_exposures ?? []) {
          if (exposure.prefix_moves_uci.length !== inquiry.prefix_moves_uci.length || !exposure.prefix_moves_uci.every((move, index) => move === inquiry.prefix_moves_uci[index]) || !inquiry.trigger_occurrence_ids.includes(exposure.occurrence_id))
            continue;
          const moves = [...exposure.moves_uci].sort(), key = `exposed_capture:${moves.join(" ")}`;
          const group = expected.get(key) ?? { moves, occurrences: [], lines: [] };
          group.occurrences.push(exposure.occurrence_id);
          group.lines.push(lineId);
          expected.set(key, group);
        }
      }
      const classKey = (group) => `${group.kind ?? "recovery_route"}:${[...group.moves_uci].sort().join(" ")}`;
      if (route.move_classes.length !== expected.size || new Set(route.move_classes.map(classKey)).size !== expected.size)
        return false;
      for (const group of route.move_classes) {
        const actual = expected.get(classKey(group));
        if (!actual || !sameIds(group.premise_occurrence_ids, actual.occurrences) || !sameIds(group.source_line_ids, actual.lines))
          return false;
        const eligible = searches.filter(
          (search) => (search.root_restriction.kind === "unrestricted" || group.moves_uci.every(
            (move) => search.root_restriction.kind === "restricted" && search.root_restriction.moves_uci.includes(move)
          )) && search.candidates.some((candidate) => group.moves_uci.includes(candidate.move_uci))
        );
        if (!sameIds(
          group.sampled_work_ids,
          eligible.map((search) => search.work_id)
        ))
          return false;
        const paired = group.moves_uci.includes(route.reference_move) ? void 0 : [...eligible].reverse().find(
          (search) => search.candidates.some((candidate) => candidate.move_uci === route.reference_move)
        );
        const challenger = paired?.candidates.find((candidate) => group.moves_uci.includes(candidate.move_uci));
        const leader = paired?.candidates.find((candidate) => candidate.move_uci === route.reference_move);
        if (paired && challenger && leader) {
          if (!group.comparison || group.comparison.work_id !== paired.work_id || group.comparison.reference_line_id !== leader.line_id || group.comparison.challenge_line_id !== challenger.line_id)
            return false;
        } else if (group.comparison !== null) return false;
      }
      const missing = route.move_classes.some((group) => !group.sampled_work_ids.length);
      const nonself = route.move_classes.filter((group) => !group.moves_uci.includes(route.reference_move));
      const computed = missing ? "not_returned" : nonself.length > 0 && nonself.every((group) => group.comparison) ? "compared" : "sampled";
      if (["awaiting_engine", "stopped"].includes(route.state) ? !missing : route.state !== computed)
        return false;
      if (!["awaiting_engine", "stopped"].includes(route.state) && route.stop_reason !== (missing || nonself.some((group) => !group.comparison) ? "investigation_limit" : null))
        return false;
    }
    const proposals2 = [];
    if (inquiry.kinds.includes("check_response_not_observed")) {
      const position = observations.positions?.find((position2) => position2.id === inquiry.position_id);
      const setup = position && parseFen(position.fen).unwrap();
      const king = setup?.board.kingOf(setup.turn);
      const count = inquiry.prefix_moves_uci.length;
      const sources = inquiry.source_line_ids.map((id2) => continuationPaths.get(id2));
      const endpoints = sources.filter((path) => path.moves.length === count);
      if (!position?.legal_moves.complete || king === void 0 || !endpoints.length || !position.controls.pieces.some(
        (control) => control.piece.side !== setup.turn && control.squares.includes(makeSquare(king))
      ))
        return false;
      proposals2.push(
        ...endpoints.map((path) => ({
          kind: "check_response_not_observed",
          triggers: [inquiry.prefix_occurrence_ids[count - 1]],
          sourceLineId: path.id,
          witnessLineIds: sources.filter((source) => source.moves.length > count).map((source) => source.id)
        }))
      );
    }
    for (const id2 of inquiry.explanation_candidate_ids) {
      const detail = lineContinuationDetail(byId.get(id2));
      if (!detail) continue;
      const events = new Map(detail.events.map((event) => [event.id, event]));
      const withOrigins = (occurrences2) => continuationTriggerOrigins(detail, occurrences2);
      const rootCapture = detail.events.find((event) => event.ply_offset === 0 && event.original_victim);
      if (inquiry.prefix_moves_uci.length === 1 && rootCapture && !detail.capture_links.some((link) => link.loss_event_id === rootCapture.id && link.elapsed_plies === 1))
        proposals2.push({
          kind: "root_capture_response",
          triggers: withOrigins([rootCapture.occurrence_id]),
          sourceLineId: detail.line_id
        });
      for (const link of detail.capture_links.filter((link2) => link2.elapsed_plies > 1)) {
        const premises = /* @__PURE__ */ new Set([link.loss_event_id]), queue = [link.loss_event_id];
        while (queue.length) {
          const event = queue.shift();
          for (const earlier of detail.capture_links.filter((link2) => link2.capture_event_id === event)) {
            if (!premises.has(earlier.loss_event_id)) {
              premises.add(earlier.loss_event_id);
              queue.push(earlier.loss_event_id);
            }
          }
        }
        const lossEvents = [...premises].map((id3) => events.get(id3)), capture = events.get(link.capture_event_id);
        if (inquiry.prefix_moves_uci.length === capture.ply_offset - 1 || lossEvents.some((event) => inquiry.prefix_moves_uci.length === event.ply_offset + 1))
          proposals2.push({
            kind: "delayed_capturer_removal",
            triggers: withOrigins([...lossEvents.map((event) => event.occurrence_id), capture.occurrence_id]),
            sourceLineId: detail.line_id
          });
      }
      for (const link of detail.other_target_gains) {
        const loss = events.get(link.loss_event_id), gain = events.get(link.gain_event_id);
        if (inquiry.prefix_moves_uci.length === loss.ply_offset + 1 || inquiry.prefix_moves_uci.length === gain.ply_offset - 1)
          proposals2.push({
            kind: "other_target_gain",
            triggers: withOrigins([loss.occurrence_id, gain.occurrence_id]),
            sourceLineId: detail.line_id
          });
      }
      const path = continuationPaths.get(detail.line_id);
      for (const exposure of detail.capture_exposures ?? []) {
        const count = exposure.prefix_moves_uci.length;
        if (inquiry.prefix_moves_uci.length === count)
          proposals2.push({
            kind: "capture_exposure_response",
            triggers: [exposure.occurrence_id],
            sourceLineId: detail.line_id
          });
        const losses = detail.events.filter(
          (event) => event.ply_offset === count && event.original_actor && event.original_victim && samePiece(event.original_actor, exposure.original_attacker) && samePiece(event.original_victim, exposure.original_target) && continuationOpenLossIds(detail, path).has(event.id)
        );
        if (count > 1 && inquiry.prefix_moves_uci.length === count - 1 && losses.length)
          proposals2.push({
            kind: "exposure_prevention_choice",
            triggers: [exposure.occurrence_id, ...losses.map((event) => event.occurrence_id)],
            sourceLineId: detail.line_id
          });
      }
      const position = observations.positions?.find((position2) => position2.id === inquiry.position_id);
      for (const source of recaptureSources.filter((source2) => source2.detail === detail))
        proposals2.push({
          kind: "replacement_function_choice",
          triggers: source.triggers,
          sourceLineId: detail.line_id,
          support: source
        });
      const returned = responseSearches?.some(
        (search) => search.candidates.length > 1 && search.candidates.some(
          (candidate) => candidate.line_id === path.id && candidate.evaluation.kind !== "exact_automatic_terminal"
        )
      );
      if (returned && path.moves.length === inquiry.prefix_moves_uci.length && path.occurrenceIds.every((id3, index) => id3 === inquiry.prefix_occurrence_ids[index]) && path.lineSummary?.ending.kind === "line_end" && position?.legal_moves.complete) {
        const side = parseFen(position.fen).unwrap().turn;
        const openLosses = continuationOpenLossIds(detail, path);
        for (const loss of detail.events.filter((event) => openLosses.has(event.id))) {
          const triggers = [
            ...continuationLossOrigins(detail, loss.id),
            path.occurrenceIds[path.occurrenceIds.length - 1]
          ];
          if (loss.original_victim?.side === side && position.legal_moves.moves.some((move) => move.captured_square || move.gives_check === true)) {
            proposals2.push({
              kind: "material_followup",
              triggers,
              sourceLineId: detail.line_id,
              witnessLineIds: followupWitnesses(path, loss)
            });
          }
          const actor = loss.actor_end.piece;
          if (loss.actor_end.state === "present" && actor?.side === side && position.controls.pieces.some(
            (control) => control.piece.side !== side && control.squares.includes(actor.square)
          ))
            proposals2.push({ kind: "capturer_reply", triggers, sourceLineId: detail.line_id });
        }
      }
    }
    for (const premise of inquiry.premises.filter((premise2) => premise2.kind === "material_followup")) {
      for (const lineId of premise.source_line_ids) {
        const path = continuationPaths.get(lineId);
        if (!continuationByLine.has(lineId) && !path.lineSummary?.material && path.occurrenceIds.length === inquiry.prefix_occurrence_ids.length && premise.trigger_occurrence_ids.includes(path.occurrenceIds[path.occurrenceIds.length - 1]) && premise.trigger_occurrence_ids.every((id2) => path.occurrenceIds.includes(id2)) && responseSearches?.some(
          (search) => search.candidates.length > 1 && search.candidates.some((candidate) => candidate.line_id === lineId)
        ))
          proposals2.push({
            kind: premise.kind,
            triggers: premise.trigger_occurrence_ids,
            sourceLineId: lineId,
            unavailable: true
          });
      }
    }
    for (const source of inquiry.comparison_sources ?? []) {
      const search = responseSearches?.find((search2) => search2.work_id === source.work_id);
      const donor = continuationByLine.get(source.donor_line_id);
      const peerProfile = continuationByLine.get(source.peer_line_id);
      const donorPath = continuationPaths.get(source.donor_line_id);
      const peer = continuationPaths.get(source.peer_line_id);
      if (!search || !donorPath || !peer || source.donor_line_id === source.peer_line_id || source.kind !== "support_application" && ![source.donor_line_id, source.peer_line_id].includes(search.candidates[0].line_id) || ![source.donor_line_id, source.peer_line_id].every(
        (line) => search.candidates.some((candidate) => candidate.line_id === line)
      ) || search.candidates.find((candidate) => candidate.line_id === source.peer_line_id).evaluation.kind === "exact_automatic_terminal")
        return false;
      const prefix = responseSearchPrefix(search), n = prefix.length;
      if (peer.moves.length <= n || inquiry.prefix_moves_uci.length !== peer.moves.length || !peer.moves.every((move, index) => move.uci === inquiry.prefix_moves_uci[index]) || !prefix.every(
        (move, index) => peer.moves[index]?.uci === move && peer.occurrenceIds[index] === donorPath.occurrenceIds[index]
      ) || peer.lineSummary?.ending.kind !== "line_end" || !inquiry.source_line_ids.includes(peer.id))
        return false;
      let common = 0;
      while (common < donorPath.occurrenceIds.length && donorPath.occurrenceIds[common] === peer.occurrenceIds[common])
        common++;
      if (common < 1 || common >= donorPath.moves.length || common >= peer.moves.length) return false;
      const observation = source.observation_line_id ? continuationPaths.get(source.observation_line_id) : void 0;
      if (source.kind === "support_application" && (!observation || common !== n || !donorPath.occurrenceIds.every((id2, index) => observation.occurrenceIds[index] === id2)))
        return false;
      const missingProfiles = [donorPath, peer, ...observation ? [observation] : []].filter(
        (path) => !continuationByLine.has(path.id)
      );
      if (missingProfiles.length) {
        if (missingProfiles.some((path) => path.lineSummary?.material)) return false;
        const kind = source.kind === "support_application" ? "support_application_not_observed" : "continuation_not_observed";
        proposals2.push(
          ...inquiry.premises.filter(
            (premise) => premise.kind === kind && premise.source_line_ids.includes(peer.id) && premise.comparison_source_indices.some(
              (index) => continuationComparisonSourceKey(inquiry.comparison_sources[index]) === continuationComparisonSourceKey(source)
            )
          ).map((premise) => ({
            kind,
            triggers: premise.trigger_occurrence_ids,
            sourceLineId: peer.id,
            comparisonSource: source,
            unavailable: true
          }))
        );
        continue;
      }
      if (source.kind === "support_application") {
        const premises = recaptureSourcesAt([observation.id], n).filter((premise) => {
          const family = search.candidates.filter((candidate) => premise.moves.includes(candidate.move_uci));
          return [donorPath.id, peer.id].every((id2) => family.some((candidate) => candidate.line_id === id2)) && [donorPath.id, peer.id].includes(family[0]?.line_id) && observesSupportUse(peer, premise, n) !== void 0;
        });
        if (!premises.length) return false;
        proposals2.push(
          ...premises.map((premise) => ({
            kind: "support_application_not_observed",
            triggers: [...premise.triggers, peer.occurrenceIds[peer.occurrenceIds.length - 1]],
            sourceLineId: peer.id,
            comparisonSource: source,
            support: premise,
            witnessLineIds: [...continuationPaths.values()].filter(
              (path) => peer.occurrenceIds.every((id2, index) => path.occurrenceIds[index] === id2) && observesSupportUse(path, premise, n) === true
            ).map((path) => path.id)
          }))
        );
        continue;
      }
      const linked = donor.events.flatMap((loss) => {
        const peerLoss = peerProfile.events.find((event) => event.occurrence_id === loss.occurrence_id);
        if (loss.ply_offset >= common || !loss.original_actor || !loss.original_victim || !peerLoss?.original_actor || !peerLoss.original_victim || !samePiece(peerLoss.original_actor, loss.original_actor) || !samePiece(peerLoss.original_victim, loss.original_victim) || !["present", "captured"].includes(peerLoss.actor_end.state))
          return [];
        return continuationRecoveries(donor, loss.id).filter((capture) => capture.ply_offset > loss.ply_offset + 1 && capture.ply_offset >= common).map((capture) => ({
          loss,
          capture,
          triggers: [
            loss.occurrence_id,
            capture.occurrence_id,
            peer.occurrenceIds[peer.occurrenceIds.length - 1]
          ]
        }));
      });
      if (!linked.length) return false;
      proposals2.push(
        ...linked.map(({ triggers, loss, capture }) => ({
          kind: "continuation_not_observed",
          triggers,
          sourceLineId: peer.id,
          comparisonSource: source,
          witnessLineIds: followupWitnesses(peer, loss, capture)
        }))
      );
    }
    const premiseProposals = /* @__PURE__ */ new Map();
    for (const premise of inquiry.premises) {
      const sources = premise.comparison_source_indices.map((index) => inquiry.comparison_sources[index]);
      const matching = proposals2.filter(
        (proposal) => proposal.kind === premise.kind && sameIds(proposal.triggers, premise.trigger_occurrence_ids) && premise.source_line_ids.includes(proposal.sourceLineId) && (proposal.comparisonSource ? sources.length === 1 && continuationComparisonSourceKey(sources[0]) === continuationComparisonSourceKey(proposal.comparisonSource) : sources.length === 0) && (proposal.support ? proposal.support.use.requirement_id === premise.requirement_id : true)
      );
      if (!matching.length || !sameIds(
        premise.source_line_ids,
        matching.map((proposal) => proposal.sourceLineId)
      ) || ([
        "replacement_function_choice",
        "support_application_not_observed",
        "continuation_not_observed"
      ].includes(premise.kind) ? premise.requirement_id === null : premise.requirement_id !== null))
        return false;
      premiseProposals.set(premise, matching);
      const semantic = [
        "check_response_not_observed",
        "material_followup",
        "continuation_not_observed",
        "support_application_not_observed"
      ].includes(premise.kind);
      const witnesses = matching.flatMap((proposal) => proposal.witnessLineIds ?? []);
      const observed = matching.every((proposal) => (proposal.witnessLineIds?.length ?? 0) > 0);
      if (!sameIds(premise.witness_line_ids, witnesses) || premise.observation_state !== (matching.some((proposal) => proposal.unavailable) ? "unavailable" : semantic ? observed ? "observed" : "unobserved" : "not_applicable"))
        return false;
    }
    if (inquiry.state === "observed" && !inquiry.premises.every((premise) => premise.observation_state === "observed"))
      return false;
    {
      const returned = (responseSearches ?? []).filter((search) => responseSearchMatchesContinuation(search, inquiry)).flatMap((search) => search.candidates.map((candidate) => continuationPaths.get(candidate.line_id)));
      const roots = [
        ...returned,
        ...observations.paths.filter(
          (path) => (inquiry.source_line_ids.includes(path.id) && path.occurrenceIds.length === inquiry.prefix_occurrence_ids.length || inquiry.legal_moves.length === 1 && inquiry.observed_moves.length > 0 && path.occurrenceIds.length > inquiry.prefix_occurrence_ids.length) && inquiry.prefix_occurrence_ids.every((id2, index) => path.occurrenceIds[index] === id2)
        )
      ];
      const descendants = observations.paths.filter(
        (path) => path.kind !== "history" && path.lineSummary && roots.some((root) => root.occurrenceIds.every((id2, index) => path.occurrenceIds[index] === id2))
      );
      const ends = descendants.filter(
        (path) => !descendants.some(
          (other) => other.moves.length > path.moves.length && path.occurrenceIds.every((id2, index) => other.occurrenceIds[index] === id2)
        )
      );
      for (const premise of inquiry.premises) {
        const ownProposals = premiseProposals.get(premise);
        const unfinished = (premise.kind === "check_response_not_observed" ? [] : ends).filter((path) => {
          const detail = continuationByLine.get(path.id);
          const related = new Set(premise.trigger_occurrence_ids);
          for (const lineId of premise.source_line_ids) {
            for (const exposure of continuationByLine.get(lineId)?.capture_exposures ?? []) {
              if (exposure.prefix_moves_uci.length !== inquiry.prefix_moves_uci.length || !exposure.prefix_moves_uci.every(
                (move, index) => move === inquiry.prefix_moves_uci[index]
              ) || !premise.trigger_occurrence_ids.includes(exposure.occurrence_id))
                continue;
              for (const capture of detail?.events ?? []) {
                if (capture.ply_offset === inquiry.prefix_moves_uci.length && capture.original_actor && capture.original_victim && samePiece(capture.original_actor, exposure.original_attacker) && samePiece(capture.original_victim, exposure.original_target))
                  related.add(capture.occurrence_id);
              }
            }
          }
          return detail && [...continuationOpenLossIds(detail, path)].some(
            (id2) => [...continuationLossOrigins(detail, id2)].some((occurrence) => related.has(occurrence))
          );
        }).map((path) => path.id);
        const unfinishedFunctions = ends.filter(
          (path) => ownProposals.some((proposal) => {
            if (!proposal.support) return false;
            const peer = proposal.comparisonSource && continuationPaths.get(proposal.comparisonSource.peer_line_id);
            return (!peer || peer.occurrenceIds.every((id2, index) => path.occurrenceIds[index] === id2)) && observesSupportUse(
              path,
              proposal.support,
              proposal.comparisonSource ? responseSearchPrefix(
                responseSearches.find(
                  (search) => search.work_id === proposal.comparisonSource.work_id
                )
              ).length : inquiry.prefix_moves_uci.length
            ) === false;
          })
        ).map((path) => path.id);
        const missing = ownProposals.flatMap(
          (proposal) => proposal.comparisonSource && !proposal.witnessLineIds?.length ? [proposal.comparisonSource.peer_line_id] : []
        );
        const unchecked = premise.kind === "check_response_not_observed" && !premise.witness_line_ids.length ? premise.source_line_ids : [];
        if (!sameIds(premise.unresolved_source_line_ids, [
          ...missing,
          ...unfinished,
          ...unfinishedFunctions,
          ...unchecked
        ]))
          return false;
      }
      const losses = new Set(
        inquiry.trigger_occurrence_ids.filter(
          (id2) => [...continuationByLine.values()].some(
            (detail) => detail.events.some((event) => event.occurrence_id === id2 && event.original_victim)
          )
        )
      );
      const followups = continuationInquiries.filter(
        (next) => next.prefix_occurrence_ids.length > inquiry.prefix_occurrence_ids.length && inquiry.prefix_occurrence_ids.every((id2, index) => next.prefix_occurrence_ids[index] === id2) && next.trigger_occurrence_ids.some((id2) => losses.has(id2))
      ).map((next) => next.id);
      if (inquiry.unresolved_source_line_ids !== void 0 && (!sameIds(
        inquiry.unresolved_source_line_ids,
        inquiry.premises.flatMap((premise) => premise.unresolved_source_line_ids)
      ) || !sameIds(inquiry.followup_question_ids, followups)))
        return false;
    }
    const witnessed = proposals2.filter(
      (proposal) => inquiry.kinds.includes(proposal.kind) && proposal.triggers.every((id2) => inquiry.trigger_occurrence_ids.includes(id2))
    );
    return sameIds(
      inquiry.kinds,
      witnessed.map((proposal) => proposal.kind)
    ) && sameIds(
      inquiry.trigger_occurrence_ids,
      witnessed.flatMap((proposal) => proposal.triggers)
    );
  };
  if (candidates.some(
    (candidate) => candidate.detail.continuation_candidate_ids !== void 0 && (!["pv_comparison", "target_response_comparison", "line_continuation_comparison"].includes(
      candidate.detail.type
    ) || !linkedProfiles(
      candidate.detail.continuation_candidate_ids,
      candidate.lineIds,
      candidate.rootOccurrenceId
    ))
  ) || candidates.some(
    (candidate) => candidate.detail.continuation_comparison_ids !== void 0 && (!["pv_comparison", "target_response_comparison"].includes(candidate.detail.type) || !linkedComparisons(
      candidate.detail.continuation_comparison_ids,
      candidate.lineIds,
      candidate.rootOccurrenceId
    ))
  ) || continuationInquiries?.some(
    (inquiry) => !inquiry.explanation_candidate_ids.every(
      (id2) => linkedProfiles(
        [id2],
        [
          ...inquiry.source_line_ids,
          ...(inquiry.comparison_sources ?? []).flatMap((source) => source.observation_line_id ?? [])
        ],
        inquiry.root_occurrence_id
      ) || linkedComparisons([id2], inquiry.source_line_ids, inquiry.root_occurrence_id)
    ) || !continuationTriggersValid(inquiry)
  ))
    return;
  const scenes = [];
  for (const raw of value.scenes) {
    if (!object(raw) || !exactKeys(raw, ["id", "root_occurrence_id", "occurrence_ids", "line_ids", "candidate_ids"]) || !id(raw.id) || !id(raw.root_occurrence_id) || !occurrences.has(raw.root_occurrence_id) || !ids(raw.occurrence_ids) || !raw.occurrence_ids.includes(raw.root_occurrence_id) || !raw.occurrence_ids.every((v) => occurrences.has(v)) || !ids(raw.line_ids) || !raw.line_ids.every((v) => paths.has(v)) || !ids(raw.candidate_ids) || !raw.candidate_ids.length || !raw.candidate_ids.every((v) => byId.has(v)))
      return;
    const members = raw.candidate_ids.map((v) => byId.get(v));
    const occurrenceIds = raw.occurrence_ids;
    const lineIds = raw.line_ids;
    const comparisons = members.filter((c) => c.kind === "comparison");
    if (!members.every(
      (c) => c.occurrenceIds.every((v) => occurrenceIds.includes(v)) && c.lineIds.every((v) => lineIds.includes(v))
    ) || comparisons.length !== 1 || comparisons[0].rootOccurrenceId !== raw.root_occurrence_id || comparisons[0].detail.type === "question_comparison" && comparisons[0].selection !== "selected")
      return;
    scenes.push({
      id: raw.id,
      rootOccurrenceId: raw.root_occurrence_id,
      occurrenceIds: raw.occurrence_ids,
      lineIds: raw.line_ids,
      candidateIds: raw.candidate_ids
    });
  }
  if (new Set(scenes.map((s) => s.id)).size !== scenes.length) return;
  if (candidates.some((candidate) => candidate.detail.type === "question_comparison" && candidate.selection === "selected" && !scenes.some((scene) => scene.candidateIds.includes(candidate.id)))) return;
  const responseFields = {
    ...discovery === void 0 ? {} : { discovery },
    ...proposals === void 0 ? {} : { proposals, local_expansions_used: value.local_expansions_used },
    ...rootSearches === void 0 ? {} : { root_searches: rootSearches },
    ...responseInquiries === void 0 ? {} : { response_inquiries: responseInquiries },
    ...responseSearches === void 0 ? {} : { response_searches: responseSearches },
    ...continuationInquiries === void 0 ? {} : { continuation_inquiries: continuationInquiries }
  };
  if (responseInquiries?.some(
    (inquiry) => inquiry.state === "observed" && !candidates.some((candidate) => {
      const detail = targetResponseDetail(candidate);
      return detail && targetResponseComplete(detail) && detail?.response_inquiry_id === inquiry.id && detail.branches[0]?.reply_move === inquiry.reference_move && detail.branches[1]?.reply_move === inquiry.alternative_move;
    })
  ))
    return;
  if (!proposalFactSourcesValid(proposals ?? [], observations, continuationInquiries ?? [])) return;
  if (value.inquiries === void 0) return { version: 2, candidates, scenes, ...responseFields };
  try {
    const inquiries = decodeInquiries(value.inquiries, observations, context, candidates);
    return inquiries ? { version: 2, candidates, scenes, inquiries, ...responseFields } : void 0;
  } catch (_) {
    return;
  }
}
var continuationKinds, targetResponseDetail, pvComparisonDetail, object, id, ids, exactKeys, integer, evaluationSource, inquiryStops, samePiece, continuationComparisonSourceKey, exchangeSignature, uniqueSorted, sameIds, proposalId, factMoves, factPly, factText, factSampleIds, factPrefix, factCompatible, factPiece;
var init_moveReviewSelection = __esm({
  "lila-docker/repos/lila/ui/analyse/src/moveReviewSelection.ts"() {
    init_fen();
    init_util();
    init_chess();
    init_variant();
    init_attacks();
    init_types2();
    continuationKinds = [
      "root_capture_response",
      "delayed_capturer_removal",
      "other_target_gain",
      "continuation_not_observed",
      "material_followup",
      "check_response_not_observed",
      "capturer_reply",
      "replacement_function_choice",
      "support_application_not_observed",
      "capture_exposure_response",
      "exposure_prevention_choice"
    ];
    targetResponseDetail = (candidate) => candidate.kind === "comparison" && candidate.detail.type === "target_response_comparison" ? candidate.detail : void 0;
    pvComparisonDetail = (candidate) => candidate.kind === "comparison" && candidate.detail.type === "pv_comparison" ? candidate.detail : void 0;
    object = (v) => !!v && typeof v === "object" && !Array.isArray(v);
    id = (v) => typeof v === "string" && v.length > 0 && v.length <= 1024;
    ids = (v) => Array.isArray(v) && v.length <= 1e4 && v.every(id) && new Set(v).size === v.length;
    exactKeys = (v, required, optional = []) => required.every((k) => k in v) && Object.keys(v).every((k) => required.includes(k) || optional.includes(k));
    integer = (v, min, max) => Number.isSafeInteger(v) && v >= min && v <= max;
    evaluationSource = (v) => [
      "direct_input",
      "root_search",
      "focus_comparison",
      "investigation_comparison",
      "response_comparison"
    ].includes(String(v));
    inquiryStops = [
      "engine_unavailable",
      "browser_unsupported",
      "deadline_exceeded",
      "cancelled",
      "search_budget_exhausted",
      "engine_execution_failed",
      "invalid_engine_work_report",
      "review_construction_failed",
      "move_review_preparation_failed",
      "repetition_history_unavailable",
      "reference_changed",
      "investigation_limit"
    ];
    samePiece = (left, right) => left.position_id === right.position_id && left.side === right.side && left.role === right.role && left.square === right.square;
    continuationComparisonSourceKey = (source) => JSON.stringify([
      source.work_id,
      source.donor_line_id,
      source.peer_line_id,
      source.kind ?? "material_recovery",
      source.observation_line_id ?? null
    ]);
    exchangeSignature = (summary) => JSON.stringify(
      summary.material.events.flatMap((event) => [
        ...event.capture ? [`loss:${event.side === "white" ? "black" : "white"}:${event.capture.role}`] : [],
        ...event.promotion_gain_cp > 0 ? [`promotion:${event.side}:${event.before_role}:${event.after_role}`] : []
      ]).sort()
    );
    uniqueSorted = (values) => [...new Set(values)].sort();
    sameIds = (left, right) => JSON.stringify(uniqueSorted(left)) === JSON.stringify(uniqueSorted(right));
    proposalId = (value) => typeof value === "string" && /^[A-Za-z0-9._:-]{1,128}$/.test(value);
    factMoves = (value) => Array.isArray(value) && value.length <= 80 && value.every((move) => typeof move === "string" && /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(move));
    factPly = (value) => Number.isInteger(value) && Number(value) >= 0 && Number(value) <= 80;
    factText = (value) => typeof value === "string" && value.length > 0 && value.length <= 256;
    factSampleIds = (value) => Array.isArray(value) && value.length <= 36e4 && value.every(id) && new Set(value).size === value.length;
    factPrefix = (prefix, moves) => prefix.every((move, index) => moves[index] === move);
    factCompatible = (left, right) => factPrefix(left, right) || factPrefix(right, left);
    factPiece = (value) => object(value) && exactKeys(value, ["side", "role", "square"]) && ["white", "black"].includes(String(value.side)) && ["pawn", "knight", "bishop", "rook", "queen", "king"].includes(String(value.role)) && typeof value.square === "string" && /^[a-h][1-8]$/.test(value.square);
  }
});

// lila-docker/repos/lila/ui/analyse/src/moveReview.ts
var moveReview_exports = {};
__export(moveReview_exports, {
  buildMoveReviewEngineWorkReport: () => buildMoveReviewEngineWorkReport,
  buildMoveReviewJobRequest: () => buildMoveReviewJobRequest,
  decodeMoveReviewSnapshot: () => decodeMoveReviewSnapshot,
  formatMoveReviewPercent: () => formatMoveReviewPercent,
  formatMoveReviewPercentagePointChange: () => formatMoveReviewPercentagePointChange,
  moveReviewBudgets: () => moveReviewBudgets,
  moveReviewCopy: () => moveReviewCopy,
  moveReviewEngineOutcomeAtRequiredDepth: () => moveReviewEngineOutcomeAtRequiredDepth,
  moveReviewFocusKey: () => moveReviewFocusKey,
  moveReviewFrameForSubject: () => moveReviewFrameForSubject,
  moveReviewObservations: () => moveReviewObservations,
  moveReviewProofById: () => moveReviewProofById,
  moveReviewRecordFromTree: () => moveReviewRecordFromTree,
  moveReviewSan: () => moveReviewSan,
  moveReviewSans: () => moveReviewSans,
  moveReviewSubjectFromNodeList: () => moveReviewSubjectFromNodeList,
  moveReviewSubjectKey: () => moveReviewSubjectKey,
  moveReviewVerdictCodeLabel: () => moveReviewVerdictCodeLabel,
  moveReviewVerdictLabel: () => moveReviewVerdictLabel,
  normalizeMoveReviewLocale: () => normalizeMoveReviewLocale,
  selectedMoveReviewCandidate: () => selectedMoveReviewCandidate,
  updateMoveReviewViewForJob: () => updateMoveReviewViewForJob
});
function moveReviewObservations(job) {
  return job.observations ?? (job.kind === "completed" || job.kind === "position-action" ? job.snapshot.observations : void 0);
}
function updateMoveReviewViewForJob(view, previous, next) {
  const before = moveReviewObservations(previous)?.owner, after = moveReviewObservations(next)?.owner;
  if (before?.requestId === after?.requestId && before?.jobId === after?.jobId) return;
  view.hoveredFrame = view.pinnedFrame = view.boardFrame = void 0;
}
function normalizeMoveReviewLocale(locale) {
  const requested = locale || (typeof document === "undefined" ? void 0 : document.documentElement.lang) || (typeof navigator === "undefined" ? void 0 : navigator.language);
  return requested?.toLowerCase().startsWith("ko") ? "ko-KR" : "en-US";
}
function moveReviewCopy(locale) {
  return copies[locale];
}
function moveReviewVerdictLabel(symbol, copy) {
  return copy.verdictLabels[symbol];
}
function moveReviewVerdictCodeLabel(code, copy) {
  return copy.verdictCodeLabels[code];
}
function formatMoveReviewPercent(value, locale) {
  return `${new Intl.NumberFormat(locale, { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(value)}%`;
}
function formatMoveReviewPercentagePointChange(value, locale) {
  const amount = new Intl.NumberFormat(locale, {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
    signDisplay: "always"
  }).format(value);
  return `${amount}%p`;
}
function moveReviewSubjectFromNodeList(variant, currentPath, nodeList, recordedMoves, source = "analysis") {
  if (variant !== "standard" || nodeList.length < 2) return;
  const initial = nodeList[0];
  const before = nodeList[nodeList.length - 2];
  const after = nodeList[nodeList.length - 1];
  const playedUci = before && standardReviewUci(before.fen, after?.uci);
  const playedSan = san(after?.san);
  if (!initial || !before || !after || !after.id || !playedUci || !playedSan || !currentPath.endsWith(after.id))
    return;
  const prefix = nodeList.slice(1, -1).map((node, index) => standardReviewUci(nodeList[index].fen, node.uci));
  if (!prefix.every((move) => !!move)) return;
  const inputLines = [];
  const record = recordedMoves && prefix.every((move, index) => recordedMoves[index] === move) ? recordedMoves.slice(prefix.length) : void 0;
  if (record?.length) inputLines.push({ source: "pgn_record", moves: record });
  const visit = (node, moves) => {
    for (const child of node.children) {
      if (!child.uci) continue;
      const path = [...moves, standardReviewUci(node.fen, child.uci)];
      if (child.children.length) visit(child, path);
      else if (!inputLines[0] || inputLines[0].source !== "pgn_record" || path.length > inputLines[0].moves.length || !path.every((move, index) => inputLines[0].moves[index] === move))
        inputLines.push({ source, moves: path });
    }
  };
  if ("children" in before) visit(before, []);
  return {
    variant: "standard",
    initialFen: initial.fen,
    movePrefixUci: prefix,
    before: { path: currentPath.slice(0, -after.id.length), fen: before.fen },
    played: { uci: playedUci, san: playedSan },
    after: { path: currentPath, fen: after.fen },
    ...inputLines.length ? { inputLines } : {}
  };
}
function moveReviewRecordFromTree(variant, root, recordedMoves, chapter, source = "study") {
  const first = root.children.find((node) => standardReviewUci(root.fen, node.uci) === recordedMoves?.[0]) ?? root.children[0];
  if (!first) return;
  const subject = moveReviewSubjectFromNodeList(variant, first.id, [root, first], recordedMoves, source);
  if (!subject) return;
  const subjects = [subject];
  let parent = first;
  let path = first.id;
  const prefix = [subject.played.uci];
  while (subjects.length < 600) {
    const next = recordedMoves ? parent.children.find((node) => standardReviewUci(parent.fen, node.uci) === recordedMoves[prefix.length]) : parent.children[0];
    if (!next) break;
    const move = standardReviewUci(parent.fen, next.uci);
    const label = san(next.san);
    if (!move || !label) break;
    subjects.push({
      variant: "standard",
      initialFen: root.fen,
      movePrefixUci: [...prefix],
      before: { path, fen: parent.fen },
      played: { uci: move, san: label },
      after: { path: path + next.id, fen: next.fen }
    });
    prefix.push(move);
    path += next.id;
    parent = next;
  }
  const revision = (node) => [node.id, node.uci, node.fen, node.children.map(revision)];
  return { key: JSON.stringify([chapter, moveReviewSubjectKey(subject), revision(root)]), subject, subjects };
}
function moveReviewFocusKey(subject) {
  return JSON.stringify([
    subject.initialFen,
    subject.movePrefixUci,
    subject.before,
    subject.played.uci,
    subject.after
  ]);
}
function moveReviewFrameForSubject(observations, origin, selected) {
  if (origin.initialFen !== selected.initialFen || !origin.movePrefixUci.every((move, i) => selected.movePrefixUci[i] === move))
    return;
  const suffix = [...selected.movePrefixUci.slice(origin.movePrefixUci.length), selected.played.uci];
  for (const path of observations.paths) {
    const index = suffix.length - 1;
    if (path.startFen !== origin.before.fen || !path.occurrenceIds[index] || !suffix.every((move, i) => path.moves[i]?.uci === move))
      continue;
    const before = index === 0 ? path.startFen : path.moves[index - 1].fenAfter;
    if (before === selected.before.fen && path.moves[index].fenAfter === selected.after.fen)
      return { proofId: path.id, ply: index + 1, phase: "after" };
  }
  return;
}
function standardReviewUci(beforeFen, raw) {
  const value = uci(raw);
  return value ? standardUci(beforeFen, value) : void 0;
}
function buildMoveReviewJobRequest(requestId, subject, engineProfile, remainingBudgetMs) {
  return {
    schema_version: moveReviewJobRequestSchema,
    request_id: requestId,
    variant: "standard",
    initial_fen: subject.initialFen,
    move_prefix_uci: subject.movePrefixUci,
    current_fen: subject.before.fen,
    focus: {
      kind: "played_move",
      played_move_uci: subject.played.uci,
      resulting_fen: subject.after.fen
    },
    engine_profile: engineProfile,
    ...remainingBudgetMs === void 0 ? {} : { remaining_budget_ms: remainingBudgetMs },
    ...subject.inputLines?.length ? { input_lines: subject.inputLines } : {}
  };
}
function buildMoveReviewEngineWorkReport(work, outcome) {
  return {
    schema_version: moveReviewEngineWorkReportSchema,
    engine_profile: work.engineProfile,
    work_id: work.workId,
    execution_key_sha256: work.executionKeySha256,
    outcome: outcome.kind === "executor_failed" ? { kind: outcome.kind, failure_code: outcome.failureCode } : {
      kind: outcome.kind,
      line_suffixes: outcome.lineSuffixes.map((line) => ({
        moves: line.moves,
        depth: line.depth,
        white_score: line.whiteScore
      }))
    }
  };
}
function moveReviewEngineOutcomeAtRequiredDepth(work, evaluation, previousEvaluation, executorElapsedMs = evaluation.millis) {
  if (evaluation.fen !== work.searchFen || evaluation.depth !== work.searchLimits.depth || !Number.isSafeInteger(evaluation.nodes) || evaluation.nodes < 1 || evaluation.nodes > work.searchLimits.nodes || !Number.isSafeInteger(evaluation.millis) || evaluation.millis < 0 || evaluation.millis > work.searchLimits.movetimeMs || !Number.isSafeInteger(executorElapsedMs) || executorElapsedMs < 0 || executorElapsedMs > work.maxSearchElapsedMs || !uci(evaluation.bestmove))
    return;
  const projected = projectExactEvaluationLines(work, evaluation, work.searchLimits.depth);
  const previous = previousEvaluation ? projectExactEvaluationLines(work, previousEvaluation, work.searchLimits.depth - 1) : void 0;
  if (!projected || !previous || previousEvaluation?.depth !== work.searchLimits.depth - 1) return;
  if (!unique(projected.map((line) => line.moves[0])) || !unique(previous.map((line) => line.moves[0]))) return;
  if (evaluation.bestmove !== projected[0]?.moves[0]) return;
  return {
    kind: "completed",
    completedDepth: evaluation.depth,
    selectiveDepth: evaluation.seldepth ?? 0,
    nodes: evaluation.nodes,
    engineTimeMs: evaluation.millis,
    executorElapsedMs,
    bestmoveUci: evaluation.bestmove,
    lineSuffixes: projected
  };
}
function projectExactEvaluationLines(work, evaluation, requiredDepth) {
  if (evaluation.fen !== work.searchFen || evaluation.depth !== requiredDepth || evaluation.pvs.length < work.searchLimits.multiPv)
    return;
  const projected = evaluation.pvs.slice(0, work.searchLimits.multiPv).map((pv) => {
    const depth = pv.depth ?? evaluation.depth;
    if (pv.bound !== void 0 || depth !== requiredDepth || !validUciMoves(pv.moves, 1, 80 - (work.searchAnchor?.prefixMovesUci.length ?? 0)) || work.rootRestriction.kind === "restricted" && !work.rootRestriction.movesUci.includes(pv.moves[0]))
      return;
    const whiteScore = projectLocalEvalScore(pv);
    return whiteScore && lineLegallyReplays(work, pv.moves) ? { moves: [...pv.moves], depth, whiteScore } : void 0;
  });
  return projected.every((line) => !!line) ? projected : void 0;
}
function lineLegallyReplays(work, lineMoves) {
  return replayFen(work.enginePositionInitialFen, [...work.enginePositionMovesUci, ...lineMoves]) !== void 0;
}
function moveReviewSubjectKey(subject) {
  return JSON.stringify([
    subject.variant,
    subject.initialFen,
    subject.movePrefixUci,
    subject.before.path,
    subject.before.fen,
    subject.played.uci,
    subject.played.san,
    subject.after.path,
    subject.after.fen,
    subject.inputLines
  ]);
}
function decodeMoveReviewSnapshot(raw, context) {
  if (!isObject(raw)) return;
  const snapshot = raw.schema_version === moveReviewJobStatusSchema ? projectJobStatus(raw, context) : raw.schema_version === moveReviewResponseSchema ? projectCompleted(raw, context) : void 0;
  if (snapshot) shareSnapshotStrings(snapshot);
  return snapshot;
}
function shareSnapshotStrings(snapshot) {
  const strings = /* @__PURE__ */ new Map();
  const seen = /* @__PURE__ */ new Set([snapshot.subject]);
  const visit = (value) => {
    if (!value || typeof value !== "object" || seen.has(value) || Object.isFrozen(value)) return;
    seen.add(value);
    const fields = value;
    for (const key of Object.keys(fields)) {
      const child = fields[key];
      if (typeof child !== "string") visit(child);
      else {
        const shared = strings.get(child);
        if (shared === void 0) strings.set(child, child);
        else fields[key] = shared;
      }
    }
  };
  visit(snapshot);
}
function selectedMoveReviewCandidate(evidence, selectedUci) {
  return evidence.candidates.find((candidate) => candidate.uci === selectedUci) ?? evidence.candidates.find((candidate) => candidate.roles.includes("played"));
}
function projectJobStatus(raw, context) {
  const common = projectCommon(raw, context);
  if (!common || nonNegativeInteger(raw.deadline_epoch_ms) === void 0 || !wireFocusMatches(raw.focus, context.subject))
    return;
  if (raw.state === "stopped") {
    if (!hasExactKeys(raw, [
      "schema_version",
      "request_id",
      "job_id",
      "engine_profile",
      "variant",
      "deadline_epoch_ms",
      "focus",
      "state",
      "progress",
      "stop_condition",
      ...raw.observations === void 0 ? [] : ["observations"],
      ...raw.verification === void 0 ? [] : ["verification"]
    ]) || !isMoveReviewStopCondition(raw.stop_condition) || common.verification?.state === "pending" || !validProgress(raw.progress, "stopped", common.observations))
      return;
    return { ...common, kind: "abstained", stopCondition: raw.stop_condition };
  }
  if (raw.state !== "awaiting_engine_work" || !hasExactKeys(raw, [
    "schema_version",
    "request_id",
    "job_id",
    "engine_profile",
    "variant",
    "deadline_epoch_ms",
    "focus",
    "state",
    "progress",
    "issued_engine_work",
    ...raw.observations === void 0 ? [] : ["observations"],
    ...raw.assessment === void 0 ? [] : ["assessment"],
    ...raw.assessment_state === void 0 ? [] : ["assessment_state"],
    ...raw.assessment_scope === void 0 ? [] : ["assessment_scope"],
    ...raw.verification === void 0 ? [] : ["verification"]
  ]))
    return;
  const work = projectIssuedEngineWork(
    raw.issued_engine_work,
    common.engineProfile,
    context.subject,
    common.observations,
    common.verification
  );
  if (!work || !validProgress(raw.progress, work.purpose, common.observations)) return;
  const assessment = raw.assessment === void 0 ? void 0 : projectAssessment(raw.assessment, common);
  if (raw.assessment !== void 0 && !assessment || (work.purpose === "investigation_comparison" || work.purpose === "response_comparison" || work.purpose === "threat_probe" ? !assessment || !isObject(raw.progress) || raw.progress.selected_commentaries_completed !== 1 : assessment && (!common.verification || common.verification.state !== "pending" || !isObject(raw.progress) || raw.progress.selected_commentaries_completed !== 1)))
    return;
  return {
    ...common,
    kind: work.purpose === "root_search" && !assessment ? "awaiting-core" : "awaiting-evidence",
    issuedEngineWork: work,
    ...assessment ? { assessment } : {}
  };
}
function projectCommon(raw, context) {
  const jobId = typeof raw.job_id === "string" && jobIdPattern.test(raw.job_id) ? raw.job_id : void 0;
  const profile = isMoveReviewEngineProfile(raw.engine_profile) ? raw.engine_profile : void 0;
  if (raw.request_id !== context.requestId || !requestIdPattern.test(context.requestId) || !jobId || !profile || raw.variant !== "standard" || context.subject.variant !== "standard" || context.jobId !== void 0 && context.jobId !== jobId || context.engineProfile !== void 0 && context.engineProfile !== profile || raw.assessment_state !== void 0 && raw.assessment_state !== "current" && raw.assessment_state !== "needs_refresh" || raw.assessment_scope !== void 0 && raw.assessment_scope !== "root_search" && raw.assessment_scope !== "investigation_pair")
    return;
  const observations = raw.observations === void 0 ? void 0 : projectObservations(raw.observations, context.subject, profile);
  if (raw.observations !== void 0 && !observations) return;
  if (observations) observations.owner = { requestId: context.requestId, jobId };
  const verification = raw.verification === void 0 ? void 0 : projectVerification(raw.verification);
  if (raw.verification !== void 0 && !verification) return;
  return {
    requestId: context.requestId,
    jobId,
    engineProfile: profile,
    judgmentRevision: moveReviewResponseSchema,
    annotationPolicyRevision: moveReviewAnnotationPolicyRevision,
    subject: context.subject,
    ...observations ? { observations } : {},
    ...raw.assessment_state === void 0 ? {} : { assessmentState: raw.assessment_state },
    ...raw.assessment_scope === void 0 ? {} : { assessmentScope: raw.assessment_scope },
    ...verification ? { verification } : {}
  };
}
function projectVerification(value) {
  if (!isObject(value) || !hasExactKeys(
    value,
    ["state", "target_depth", "reason", "trigger_work_ids", "completed_depth", "stop_reason"]
  ) || !["pending", "complete", "stopped", "not_required"].includes(String(value.state)) || !["initial_verification", "child_challenge"].includes(String(value.reason)) || integerInRange(value.target_depth, 8, 100) === void 0 || !Array.isArray(value.trigger_work_ids) || value.trigger_work_ids.length > 32 || !unique(value.trigger_work_ids) || !value.trigger_work_ids.every((id2) => typeof id2 === "string" && /^work:[0-9]+$/.test(id2)) || value.completed_depth !== null && integerInRange(value.completed_depth, 8, 100) === void 0 || value.state === "complete" && (value.completed_depth === null || Number(value.completed_depth) < Number(value.target_depth)) || (value.state === "stopped" ? typeof value.stop_reason !== "string" || !value.stop_reason.length : value.stop_reason !== null))
    return;
  return {
    state: value.state,
    targetDepth: Number(value.target_depth),
    reason: value.reason,
    triggerWorkIds: value.trigger_work_ids,
    ...value.completed_depth === null ? {} : { completedDepth: Number(value.completed_depth) },
    ...value.stop_reason === null ? {} : { stopReason: String(value.stop_reason) }
  };
}
function wireFocusMatches(value, subject) {
  return isObject(value) && hasExactKeys(value, ["kind", "played_move_uci", "resulting_fen"]) && value.kind === "played_move" && value.played_move_uci === subject.played.uci && value.resulting_fen === subject.after.fen;
}
function validProgress(value, phase, observations) {
  const minimumLegalMoves = phase === "stopped" ? 0 : 1;
  const functional = observations?.selection?.response_searches?.some((search) => search.proposal_ownership?.question_refs.some((ref) => {
    const proposal = observations.selection?.proposals?.find((proposal2) => proposal2.id === ref.proposal_id);
    const reading = proposal?.requirements.find((reading2) => reading2.id === ref.requirement_id);
    return !!proposal && !!reading && ownedChoiceSurveyMatches(
      proposal,
      reading,
      search.prefix_moves_uci ?? [search.root_move],
      search.root_move_occurrence_id
    );
  }));
  const maximumWorks = 32 + (functional ? 24 : 0);
  if (!isObject(value) || !hasExactKeys(value, [
    "phase",
    "legal_move_count",
    "root_candidate_lines_admitted",
    "selected_commentaries_completed",
    "physical_works_issued",
    "physical_reports_accepted"
  ]) || value.phase !== phase || integerInRange(value.legal_move_count, minimumLegalMoves, 218) === void 0 || integerInRange(value.root_candidate_lines_admitted, 0, 3) === void 0 || integerInRange(value.selected_commentaries_completed, 0, 1) === void 0 || integerInRange(value.physical_works_issued, 0, maximumWorks) === void 0 || integerInRange(value.physical_reports_accepted, 0, maximumWorks) === void 0)
    return false;
  const issued = value.physical_works_issued;
  const accepted = value.physical_reports_accepted;
  return phase === "completed" || phase === "stopped" ? accepted <= issued : issued === accepted + 1;
}
function isMoveReviewStopCondition(value) {
  return typeof value === "string" && Object.prototype.hasOwnProperty.call(copies["en-US"].stopReasons, value);
}
function projectIssuedEngineWork(value, profile, subject, observations, contextVerification) {
  if (!isObject(value) || !hasExactKeys(value, [
    "work_id",
    "purpose",
    "engine_profile",
    "execution_key_sha256",
    "variant",
    "engine_position_initial_fen",
    "engine_position_moves_uci",
    "search_fen",
    "root_restriction",
    "search_limits",
    "max_search_elapsed_ms",
    ...value.search_anchor === void 0 ? [] : ["search_anchor"],
    ...value.threat_origin_prefix_uci === void 0 ? [] : ["threat_origin_prefix_uci"]
  ]) || typeof value.work_id !== "string" || !workIdPattern.test(value.work_id) || value.purpose !== "root_search" && value.purpose !== "focus_comparison" && value.purpose !== "investigation_comparison" && value.purpose !== "response_comparison" && value.purpose !== "threat_probe" || value.engine_profile !== profile || typeof value.execution_key_sha256 !== "string" || !sha256Pattern.test(value.execution_key_sha256) || value.variant !== "standard" || !validUciMoves(value.engine_position_moves_uci, 0, value.purpose === "response_comparison" ? 679 : 600) || !fenText(value.search_fen) || !isObject(value.root_restriction) || !isObject(value.search_limits) || !hasExactKeys(value.search_limits, ["depth", "nodes", "movetime_ms", "multi_pv"]))
    return;
  const threat = value.purpose === "threat_probe";
  const threatPrefix = value.threat_origin_prefix_uci;
  if (threat) {
    if (!validUciMoves(threatPrefix, 0, 1) || threatPrefix.length === 1 && threatPrefix[0] !== subject.played.uci) return;
    const originFen = threatPrefix.length ? subject.after.fen : subject.before.fen;
    const setup = parseFen(originFen);
    if (setup.isErr) return;
    const origin = setupPosition("chess", setup.value);
    if (origin.isErr || origin.value.isCheck() || origin.value.isEnd()) return;
    const expected = makeFen(threatSetup(originFen));
    if (value.engine_position_initial_fen !== expected || value.engine_position_moves_uci.length !== 0 || value.search_fen !== expected) return;
  } else if (threatPrefix !== void 0 || value.engine_position_initial_fen !== subject.initialFen || !arrayPrefix(subject.movePrefixUci, value.engine_position_moves_uci) || replayFen(subject.initialFen, value.engine_position_moves_uci) !== value.search_fen) return;
  const limits = {
    depth: integerInRange(value.search_limits.depth, 1, 18),
    nodes: integerInRange(value.search_limits.nodes, 1, 25e7),
    movetimeMs: integerInRange(value.search_limits.movetime_ms, 1, 12e4),
    multiPv: integerInRange(value.search_limits.multi_pv, 1, 3)
  };
  if (Object.values(limits).some((limit) => limit === void 0)) return;
  const unrestricted = hasExactKeys(value.root_restriction, ["kind"]) && value.root_restriction.kind === "unrestricted";
  const restrictedMoves = hasExactKeys(value.root_restriction, ["kind", "moves_uci"]) && value.root_restriction.kind === "restricted" && validUciMoves(
    value.root_restriction.moves_uci,
    value.purpose === "response_comparison" ? 1 : 2,
    value.purpose === "focus_comparison" ? 2 : 218
  ) && unique(value.root_restriction.moves_uci) ? value.root_restriction.moves_uci : void 0;
  const rootOrFocusPosition = arrayEquals(value.engine_position_moves_uci, subject.movePrefixUci) && value.search_fen === subject.before.fen;
  const anchor = value.search_anchor;
  const anchorPrefix = isObject(anchor) ? anchor.prefix_moves_uci ?? [anchor.root_move] : void 0;
  const proposalComparisonMoves = new Set(
    value.purpose === "response_comparison" && Array.isArray(anchorPrefix) ? observations?.selection?.proposals?.flatMap(
      (proposal) => proposal.requirements.flatMap(
        (reading) => reading.kind === "compare_moves" && reading.state === "awaiting_engine" && reading.work_id === value.work_id && arrayEquals(reading.prefix_moves_uci, anchorPrefix) ? [reading.reference_move, reading.alternative_move] : []
      )
    ) ?? [] : []
  );
  const reserveClassPool = restrictedMoves && isObject(anchor) && Array.isArray(anchorPrefix) && observations?.selection?.proposals?.some(
    (proposal) => proposal.requirements.some((reading) => {
      if (reading.kind !== "compare_moves" || reading.state !== "awaiting_engine" || reading.work_id !== value.work_id || !arrayEquals(reading.prefix_moves_uci, anchorPrefix)) return false;
      return typeof anchor.position_id === "string" && reserveResponsePoolMatches(proposal, reading, restrictedMoves, observations, anchor.position_id) && limits.multiPv === Math.min(3, restrictedMoves.length);
    })
  );
  const firstReplySurvey = unrestricted && Array.isArray(anchorPrefix) && anchorPrefix.length === 1 && isObject(anchor) && observations?.positions?.some((position) => position.id === anchor.position_id && position.legal_moves.complete && position.legal_moves.moves.length >= 2 && limits.multiPv === Math.min(3, position.legal_moves.moves.length) && observations.selection?.proposals?.some((proposal) => proposal.admission === "generated" && proposal.requirements.some((reading) => reading.kind === "compare_moves" && reading.state === "awaiting_engine" && reading.work_id === value.work_id && arrayEquals(reading.prefix_moves_uci, anchorPrefix) && reading.reference_move !== reading.alternative_move && [reading.reference_move, reading.alternative_move].every((move) => position.legal_moves.moves.some((row) => row.uci === move)))));
  const functionalSurvey = unrestricted && isObject(anchor) && Array.isArray(anchorPrefix) && observations?.positions?.some((position) => position.id === anchor.position_id && position.legal_moves.complete && position.legal_moves.moves.length >= 2 && limits.multiPv === Math.min(3, position.legal_moves.moves.length) && observations.selection?.proposals?.some((proposal) => proposal.requirements.some((reading) => reading.kind === "compare_moves" && reading.state === "awaiting_engine" && reading.work_id === value.work_id && arrayEquals(reading.prefix_moves_uci, anchorPrefix) && ownedChoiceSurveyMatches(proposal, reading, anchorPrefix, anchor.root_occurrence_id) && reading.reference_move !== reading.alternative_move && [reading.reference_move, reading.alternative_move].every((move) => position.legal_moves.moves.some((row) => row.uci === move)))));
  const responsePosition = value.purpose === "response_comparison" && isObject(anchor) && hasExactKeys(anchor, [
    "position_id",
    "root_move",
    "root_occurrence_id",
    ...anchor.prefix_moves_uci === void 0 ? [] : ["prefix_moves_uci"]
  ]) && semanticId(anchor.position_id) && semanticId(anchor.root_occurrence_id) && typeof anchor.root_move === "string" && validUciMoves(anchorPrefix, 1, 79) && anchorPrefix[0] === anchor.root_move && arrayEquals(value.engine_position_moves_uci, [...subject.movePrefixUci, ...anchorPrefix]) && observations?.positions?.some(
    (position) => position.id === anchor.position_id && position.fen === value.search_fen
  ) && commentarySearchAnchorPath(
    observations,
    subject.before.fen,
    anchor.root_move,
    anchor.root_occurrence_id,
    anchor.position_id,
    anchorPrefix
  ) && (firstReplySurvey || functionalSurvey || anchorPrefix.length === 1 && observations.selection?.response_inquiries?.some(
    (inquiry) => inquiry.state === "awaiting_engine" && inquiry.root_move === anchor.root_move && inquiry.root_move_occurrence_id === anchor.root_occurrence_id && inquiry.child_position_id === anchor.position_id && (unrestricted && limits.multiPv === Math.min(3, inquiry.capture_moves.length + inquiry.decline_moves.length) || restrictedMoves && responsePoolMatchesClasses(
      observations.selection.response_inquiries.filter(
        (peer) => peer.root_move === anchor.root_move && peer.root_move_occurrence_id === anchor.root_occurrence_id && peer.child_position_id === anchor.position_id
      ),
      restrictedMoves,
      observations.selection.response_searches?.filter(
        (search) => responseSearchMatchesInquiry(search, inquiry)
      ),
      subject.played.uci
    ) && limits.multiPv === Math.min(3, restrictedMoves.length))
  ) || observations.selection?.continuation_inquiries?.some(
    (inquiry) => inquiry.position_id === anchor.position_id && inquiry.prefix_occurrence_ids[0] === anchor.root_occurrence_id && arrayEquals(inquiry.prefix_moves_uci, anchorPrefix) && inquiry.legal_moves.length >= 2 && (inquiry.state === "awaiting_engine" && unrestricted && limits.multiPv === Math.min(3, inquiry.legal_moves.length) || inquiry.route_challenge?.state === "awaiting_engine" && restrictedMoves && continuationRoutePoolMatches(inquiry, restrictedMoves, true) && limits.multiPv === Math.min(3, restrictedMoves.length))
  ) || reserveClassPool || // One bounded work can answer several pairs at this exact prefix.
  proposalComparisonMoves.size >= 2 && proposalComparisonMoves.size <= 3 && restrictedMoves?.length === proposalComparisonMoves.size && restrictedMoves.every((move) => proposalComparisonMoves.has(move)) && limits.multiPv === Math.min(3, restrictedMoves.length) || observations.selection?.proposals?.some(
    (proposal) => proposal.requirements.some(
      (reading) => reading.kind === "fact" && reading.state === "awaiting_engine" && reading.work_id === value.work_id && unrestricted && reading.result?.needs.some(
        (need) => need.kind === "continuation" && arrayEquals(need.prefix_moves_uci, anchorPrefix) && need.horizon !== null && need.horizon > anchorPrefix.length
      ) && observations.positions?.some(
        (position) => position.id === anchor.position_id && position.legal_moves.complete && position.legal_moves.moves.length >= 2 && limits.multiPv === Math.min(3, position.legal_moves.moves.length)
      )
    )
  ));
  const selectedFirstReply = value.purpose === "response_comparison" && Array.isArray(anchorPrefix) && anchorPrefix.length === 1 && restrictedMoves && (restrictedMoves.length === 2 && observations?.selection?.proposals?.some((proposal) => proposal.admission === "generated" && proposal.requirements.some((reading) => reading.kind === "compare_moves" && reading.state === "awaiting_engine" && reading.work_id === value.work_id && arrayEquals(reading.prefix_moves_uci, anchorPrefix) && restrictedMoves.includes(reading.reference_move) && restrictedMoves.includes(reading.alternative_move))) || restrictedMoves.length >= 2 && restrictedMoves.length <= 3 && anchorPrefix[0] === subject.played.uci && observations?.selection?.response_inquiries?.some((inquiry) => inquiry.state === "awaiting_engine" && inquiry.root_move === subject.played.uci && inquiry.root_move_occurrence_id === anchor.root_occurrence_id && inquiry.child_position_id === anchor.position_id && inquiry.original_target.square === subject.played.uci.slice(0, 2) && inquiry.target.square === subject.played.uci.slice(2, 4) && reviewedMoverResponsePoolMatches(
    [inquiry],
    restrictedMoves,
    observations.selection?.response_searches,
    subject.played.uci
  )));
  if (value.purpose !== "response_comparison" && anchor !== void 0) return;
  const stoppedFocus = value.purpose === "focus_comparison" && restrictedMoves && observations?.selection?.root_searches?.some((search) => search.purpose === "focus_comparison" && search.state === "stopped" && search.stop_reason === "search_budget_exhausted" && search.required_depth === limits.depth && search.root_restriction.kind === "restricted" && arrayEquals(search.root_restriction.moves_uci, restrictedMoves));
  const inquiryPrefix = anchorPrefix === void 0 ? [] : Array.isArray(anchorPrefix) ? anchorPrefix : void 0;
  const selectedInquiry = value.purpose !== "focus_comparison" && inquiryPrefix && restrictedMoves && observations?.selection?.proposals?.some((proposal) => proposal.requirements.some((reading) => reading.kind === "compare_moves" && reading.state === "awaiting_engine" && reading.work_id === value.work_id && arrayEquals(reading.prefix_moves_uci, inquiryPrefix) && restrictedMoves.includes(reading.reference_move) && restrictedMoves.includes(reading.alternative_move)));
  const initialRootCompletion = contextVerification?.state === "pending" && contextVerification.reason === "initial_verification" && contextVerification.targetDepth === limits.depth && limits.nodes === 4e7 && limits.movetimeMs === 8e3 && value.max_search_elapsed_ms === 9e3 && observations?.selection?.root_searches?.some((search) => search.state === "stopped" && search.stop_reason === "search_budget_exhausted" && search.purpose === "root_search" && search.root_restriction.kind === "unrestricted" && search.required_depth === limits.depth && search.engine_profile === profile);
  const shapeValid = threat && unrestricted && limits.depth === 8 && limits.nodes === 25e4 && limits.movetimeMs === 750 && limits.multiPv <= 2 && value.max_search_elapsed_ms === 1250 || value.purpose === "root_search" && rootOrFocusPosition && unrestricted && (limits.depth === 8 && limits.nodes === 2e6 && limits.movetimeMs === 2500 && value.max_search_elapsed_ms === 3500 || limits.depth >= 16 && limits.nodes === 5e6 && limits.movetimeMs === 5e3 && value.max_search_elapsed_ms === 6e3 || limits.depth >= 16 && (limits.nodes === 4e7 && limits.movetimeMs === 8e3 && value.max_search_elapsed_ms === 9e3 || limits.nodes === 25e7 && limits.movetimeMs === 12e4 && value.max_search_elapsed_ms === 121e3) && contextVerification?.state === "pending" && contextVerification.reason === "child_challenge" && contextVerification.targetDepth === limits.depth || initialRootCompletion) || (value.purpose === "focus_comparison" || value.purpose === "investigation_comparison" || value.purpose === "response_comparison") && (value.purpose === "response_comparison" ? responsePosition : rootOrFocusPosition) && (value.purpose === "response_comparison" || restrictedMoves) && (value.purpose !== "focus_comparison" || restrictedMoves?.includes(subject.played.uci)) && (!restrictedMoves || restrictedMoves.every(
    (move) => replayFen(subject.initialFen, [...value.engine_position_moves_uci, move]) !== void 0
  )) && (limits.depth >= 16 || value.purpose === "focus_comparison" && limits.depth === 8) && (limits.nodes === 2e6 && limits.movetimeMs === 2500 && value.max_search_elapsed_ms === 3500 || limits.depth >= 16 && (selectedInquiry || stoppedFocus) && limits.nodes === 2e7 && limits.movetimeMs === 2500 && value.max_search_elapsed_ms === 3500 || selectedFirstReply && limits.nodes === 4e7 && limits.movetimeMs === 8e3 && value.max_search_elapsed_ms === 9e3 || limits.depth >= 16 && stoppedFocus && limits.nodes === 4e7 && limits.movetimeMs === 8e3 && value.max_search_elapsed_ms === 9e3 || limits.depth >= 16 && (limits.nodes === 5e6 || limits.nodes === 2e7) && limits.movetimeMs === 5e3 && value.max_search_elapsed_ms === 6e3 && // A selected inquiry may use more nodes inside the same five seconds
  // for its direct reply or one server-scheduled retry. Position, legal roots,
  // depth and MultiPV remain subject to the checks above.
  (value.purpose !== "focus_comparison" || stoppedFocus)) && (value.purpose === "response_comparison" || restrictedMoves && limits.multiPv === Math.min(3, restrictedMoves.length));
  if (!shapeValid) return;
  return {
    engineProfile: profile,
    workId: value.work_id,
    purpose: value.purpose,
    executionKeySha256: value.execution_key_sha256,
    variant: "standard",
    enginePositionInitialFen: value.engine_position_initial_fen,
    enginePositionMovesUci: [...value.engine_position_moves_uci],
    searchFen: value.search_fen,
    ...threat ? { threatOriginPrefixUci: [...threatPrefix] } : {},
    ...responsePosition ? {
      searchAnchor: {
        positionId: anchor.position_id,
        rootMove: anchor.root_move,
        rootOccurrenceId: anchor.root_occurrence_id,
        prefixMovesUci: [...anchorPrefix]
      }
    } : {},
    rootRestriction: restrictedMoves ? { kind: "restricted", movesUci: [...restrictedMoves] } : { kind: "unrestricted" },
    searchLimits: {
      depth: limits.depth,
      nodes: limits.nodes,
      movetimeMs: limits.movetimeMs,
      multiPv: limits.multiPv
    },
    maxSearchElapsedMs: value.max_search_elapsed_ms
  };
}
function projectCompleted(raw, context) {
  if (!hasExactKeys(raw, [
    "schema_version",
    "annotation_policy_revision",
    "request_id",
    "job_id",
    "engine_profile",
    "variant",
    "current_fen",
    "focus",
    "progress",
    "result",
    ...raw.observations === void 0 ? [] : ["observations"],
    ...raw.assessment_state === void 0 ? [] : ["assessment_state"],
    ...raw.assessment_scope === void 0 ? [] : ["assessment_scope"],
    ...raw.verification === void 0 ? [] : ["verification"]
  ]) || raw.annotation_policy_revision !== moveReviewAnnotationPolicyRevision || raw.current_fen !== context.subject.before.fen || !wireFocusMatches(raw.focus, context.subject))
    return;
  const common = projectCommon(raw, context);
  if (!common || common.verification?.state === "pending" || !validProgress(raw.progress, "completed", common.observations)) return;
  const assessment = projectAssessment(raw.result, common);
  return assessment ? { ...common, ...assessment } : void 0;
}
function projectAssessment(result, common) {
  if (!isObject(result)) return;
  if (result.kind === "move_observations") {
    if (!common.observations || !hasOnlyKeys(result, ["kind", "draw_claims"], ["kind"])) return;
    const drawClaims2 = result.draw_claims === void 0 ? void 0 : projectDrawClaims(result.draw_claims);
    if (result.draw_claims !== void 0 && !drawClaims2) return;
    return {
      kind: "completed",
      evidence: { candidates: [], ...drawClaims2 ? { drawClaims: drawClaims2 } : {} }
    };
  }
  const action = projectPositionAction(result);
  if (action) return { kind: "position-action", action };
  if (result.kind === "forced_single_move") return projectForcedSingleMove(result, common.subject);
  if (result.kind !== "selected_move_choices" || !hasOnlyKeys(
    result,
    ["kind", "selected_move_reviews", "draw_claims"],
    ["kind", "selected_move_reviews"]
  ) || !Array.isArray(result.selected_move_reviews) || result.selected_move_reviews.length < 1 || result.selected_move_reviews.length > 2)
    return;
  const candidates = result.selected_move_reviews.map((value) => projectSelectedReview(value, common.subject));
  if (!candidates.every((candidate) => !!candidate)) return;
  const played = candidates.filter((candidate) => candidate.roles.includes("played"));
  const best = candidates.filter((candidate) => candidate.roles.includes("best"));
  if (played.length !== 1 || best.length !== 1 || played[0]?.uci !== common.subject.played.uci || !unique(candidates.map((candidate) => candidate.uci)))
    return;
  const bestRow = result.selected_move_reviews[candidates.indexOf(best[0])];
  if (common.assessmentScope !== "investigation_pair" && (!isObject(bestRow) || !isObject(bestRow.selection) || bestRow.selection.root_rank !== 1))
    return;
  const drawClaims = Object.prototype.hasOwnProperty.call(result, "draw_claims") ? projectDrawClaims(result.draw_claims) : void 0;
  if (Object.prototype.hasOwnProperty.call(result, "draw_claims") && !drawClaims) return;
  for (const candidate of candidates) {
    if (candidate.review.kind !== "move-verdict") continue;
    if (candidate.review.core.bestUci !== best[0].uci) return;
    candidate.winPercent = candidate.review.core.winChance?.playedPercent;
    if (candidate.review.core.winChance && best[0].winPercent === void 0)
      best[0].winPercent = candidate.review.core.winChance.referencePercent;
  }
  return {
    kind: "completed",
    evidence: { candidates, ...drawClaims ? { drawClaims } : {} }
  };
}
function projectPositionAction(value) {
  if (value.kind === "automatic_terminal") {
    if (!hasExactKeys(value, ["kind", "terminal"])) return;
    const terminal = projectAutomaticTerminal(value.terminal);
    return terminal ? { kind: "automatic-terminal", terminal } : void 0;
  }
  if (value.kind === "draw_claim_action") {
    if (!hasExactKeys(value, ["kind", "claims"])) return;
    const claims = projectDrawClaims(value.claims);
    return claims ? { kind: "draw-claim", claims } : void 0;
  }
  return;
}
function projectForcedSingleMove(value, subject) {
  if (!hasOnlyKeys(
    value,
    ["kind", "move_uci", "supporting_endpoint", "draw_claims"],
    ["kind", "move_uci", "supporting_endpoint"]
  ))
    return;
  const move = uci(value.move_uci);
  const endpoint = projectEndpoint(value.supporting_endpoint);
  const claims = Object.prototype.hasOwnProperty.call(value, "draw_claims") ? projectDrawClaims(value.draw_claims) : void 0;
  if (!move || move !== subject.played.uci || !endpoint || endpoint.moves[0] !== move) return;
  return {
    kind: "completed",
    evidence: {
      ...claims ? { drawClaims: claims } : {},
      candidates: [
        {
          uci: move,
          label: subject.played.san,
          roles: ["best", "played"],
          winPercent: endpoint.winPercent,
          review: {
            kind: "forced-single-move",
            lineUcis: endpoint.moves,
            ...endpoint.terminal ? { terminal: endpoint.terminal } : {}
          }
        }
      ]
    }
  };
}
function projectSelectedReview(value, subject) {
  if (!isObject(value) || integerInRange(value.legal_move_index, 0, 217) === void 0 || !uci(value.move_uci) || !isObject(value.selection) || !hasOnlyKeys(value.selection, ["roles", "root_rank"], ["roles"]) || !Array.isArray(value.selection.roles))
    return;
  const roles = value.selection.roles.filter(
    (role) => role === "best" || role === "played" || role === "alternative"
  );
  if (roles.length !== value.selection.roles.length || !unique(roles) || roles.length < 1 || roles.includes("played") !== (value.move_uci === subject.played.uci) || Object.prototype.hasOwnProperty.call(value.selection, "root_rank") && integerInRange(value.selection.root_rank, 1, 3) === void 0)
    return;
  let review;
  if (hasExactKeys(value, ["legal_move_index", "move_uci", "selection", "commentary"]))
    review = projectCommentary(value.commentary, value.move_uci, subject);
  else if (hasExactKeys(value, ["legal_move_index", "move_uci", "selection", "line_insight"]))
    review = projectLineInsight(value.line_insight, value.move_uci, subject.before.fen);
  if (!review) return;
  return {
    uci: value.move_uci,
    label: moveReviewSan(subject.before.fen, value.move_uci),
    roles,
    review
  };
}
function projectLineInsight(value, move, startFen) {
  if (!isObject(value) || !hasExactKeys(value, ["endpoint"])) return;
  const endpoint = projectEndpoint(value.endpoint);
  if (!endpoint || endpoint.moves[0] !== move) return;
  const proof = buildProof(`line:${move}`, startFen, endpoint.moves);
  return proof ? { kind: "single-candidate-insight", proof } : void 0;
}
function projectCommentary(value, move, subject) {
  if (!isObject(value) || !hasExactKeys(value, ["primary"]) || !isObject(value.primary)) return;
  const primary = value.primary;
  let verdictRef;
  let verdictCode;
  let referenceEndpoint;
  let reviewedEndpoint;
  let winChance;
  let bestChoice;
  if (primary.kind === "move_verdict") {
    if (!hasExactKeys(primary, [
      "kind",
      "comparison_evidence_id",
      "verdict_code",
      "verdict_confidence",
      "mover",
      "delta",
      "reference_endpoint",
      "played_endpoint"
    ]))
      return;
    verdictRef = semanticId(primary.comparison_evidence_id);
    verdictCode = moveReviewVerdictCode(primary.verdict_code);
    referenceEndpoint = projectEndpoint(primary.reference_endpoint);
    reviewedEndpoint = projectEndpoint(primary.played_endpoint);
    const delta = projectDelta(primary.delta);
    if (!verdictRef || !verdictCode || !referenceEndpoint || !reviewedEndpoint || reviewedEndpoint.moves[0] !== move || delta === void 0)
      return;
    if (referenceEndpoint.winPercent !== void 0 && reviewedEndpoint.winPercent !== void 0)
      winChance = {
        referencePercent: referenceEndpoint.winPercent,
        playedPercent: reviewedEndpoint.winPercent,
        changePercentagePoints: delta
      };
  } else if (primary.kind === "best_choice") {
    if (!hasExactKeys(primary, [
      "kind",
      "comparison_evidence_id",
      "runner_up_verdict_code",
      "verdict_confidence",
      "mover",
      "delta",
      "best_endpoint",
      "runner_up_endpoint"
    ]))
      return;
    verdictRef = semanticId(primary.comparison_evidence_id);
    reviewedEndpoint = projectEndpoint(primary.best_endpoint);
    referenceEndpoint = projectEndpoint(primary.runner_up_endpoint);
    const runnerUpVerdictCode = moveReviewVerdictCode(primary.runner_up_verdict_code);
    const delta = projectDelta(primary.delta);
    const runnerUpUci = referenceEndpoint?.moves[0];
    if (!verdictRef || !reviewedEndpoint || !referenceEndpoint || reviewedEndpoint.moves[0] !== move || !runnerUpUci || runnerUpUci === move || !runnerUpVerdictCode || runnerUpVerdictCode === "improves_on_reference" || delta === void 0)
      return;
    bestChoice = { runnerUpVerdictCode, runnerUpUci };
    if (reviewedEndpoint.winPercent !== void 0 && referenceEndpoint.winPercent !== void 0)
      winChance = {
        referencePercent: referenceEndpoint.winPercent,
        playedPercent: reviewedEndpoint.winPercent,
        changePercentagePoints: -delta
      };
  } else return;
  const bestUci = primary.kind === "best_choice" ? reviewedEndpoint?.moves[0] : referenceEndpoint?.moves[0];
  if (!bestUci || !referenceEndpoint || !reviewedEndpoint || !verdictRef) return;
  const comparisonProof = buildProof(`pv:${move}`, subject.before.fen, reviewedEndpoint.moves);
  if (!comparisonProof) return;
  const comparisonProofs = [comparisonProof];
  if (bestChoice) {
    const referenceProof = buildProof(`pv:${move}:reference`, subject.before.fen, referenceEndpoint.moves);
    if (!referenceProof) return;
    comparisonProofs.push(referenceProof);
  }
  const coreFields = {
    verdictRef,
    verdictSymbol: verdictCode ? verdictSymbolByCode[verdictCode] : "none",
    playedUci: move,
    bestUci,
    ...winChance ? { winChance } : {},
    ...referenceEndpoint.terminal ? { referenceTerminal: referenceEndpoint.terminal } : {},
    ...reviewedEndpoint.terminal ? { reviewedTerminal: reviewedEndpoint.terminal } : {}
  };
  const core = bestChoice ? { ...coreFields, kind: "best-choice", bestChoice } : verdictCode ? { ...coreFields, kind: "move-verdict", verdictCode } : void 0;
  if (!core) return;
  return {
    kind: "move-verdict",
    core,
    comparisonProofs
  };
}
function moveReviewProofById(review, proofId) {
  if (review.kind === "single-candidate-insight")
    return review.proof.id === proofId ? review.proof : void 0;
  if (review.kind !== "move-verdict") return;
  return review.comparisonProofs.find((proof) => proof.id === proofId);
}
function projectObservations(value, subject, engineProfile) {
  if (!isObject(value) || !hasExactKeys(value, [
    "statements",
    "paths",
    ...value.positions !== void 0 ? ["positions"] : [],
    ...value.input_issues !== void 0 ? ["input_issues"] : [],
    ...value.highlights !== void 0 ? ["highlights"] : [],
    ...value.selection !== void 0 ? ["selection"] : []
  ]) || !Array.isArray(value.paths) || !Array.isArray(value.statements))
    return;
  const paths = [];
  let selectionEvidenceValid = true;
  const occurrences = /* @__PURE__ */ new Map();
  for (const raw of value.paths) {
    if (!isObject(raw) || !hasExactKeys(raw, [
      "id",
      "kind",
      "start_fen",
      "moves",
      "occurrence_ids",
      ...value.positions !== void 0 ? ["position_ids"] : [],
      ...raw.line_summary !== void 0 ? ["line_summary"] : [],
      ...raw.sources !== void 0 ? ["sources"] : [],
      ...raw.evaluations !== void 0 ? ["evaluations"] : [],
      ...raw.conditional_evaluations !== void 0 ? ["conditional_evaluations"] : []
    ]) || !semanticId(raw.id) || !fenText(raw.start_fen) || !validUciMoves(raw.moves, 1, 600) || !Array.isArray(raw.occurrence_ids) || raw.occurrence_ids.length !== raw.moves.length || value.positions !== void 0 && (!Array.isArray(raw.position_ids) || raw.position_ids.length !== raw.moves.length + 1 || !raw.position_ids.every((id2) => id2 === null || semanticId(id2))) || raw.kind !== "played" && raw.kind !== "analysis" && raw.kind !== "history")
      return;
    if (raw.kind === "history") {
      if (subject.movePrefixUci.length === 0 || raw.moves.length !== 2 || raw.moves[0] !== subject.movePrefixUci[subject.movePrefixUci.length - 1] || raw.moves[1] !== subject.played.uci || replayFen(subject.initialFen, subject.movePrefixUci.slice(0, -1)) !== raw.start_fen || raw.occurrence_ids[0] !== null)
        return;
    } else if (raw.start_fen !== subject.before.fen || raw.kind === "played" && (raw.moves.length !== 1 || raw.moves[0] !== subject.played.uci))
      return;
    const proof = buildProof(raw.id, raw.start_fen, raw.moves);
    if (!proof) return;
    for (const [index, id2] of raw.occurrence_ids.entries()) {
      if (id2 === null && raw.kind === "history" && index === 0) continue;
      if (!semanticId(id2)) return;
      const occurrence = {
        uci: proof.moves[index].uci,
        beforeFen: index === 0 ? proof.startFen : proof.moves[index - 1].fenAfter,
        afterFen: proof.moves[index].fenAfter
      };
      const previous = occurrences.get(id2);
      if (previous && (previous.uci !== occurrence.uci || previous.beforeFen !== occurrence.beforeFen || previous.afterFen !== occurrence.afterFen))
        return;
      occurrences.set(id2, occurrence);
    }
    const sources = raw.sources;
    if (sources !== void 0 && (!Array.isArray(sources) || !sources.length || !unique(sources) || !sources.every(
      (source) => subject.inputLines?.some(
        (line) => line.source === source && proof.moves.every((move, index) => line.moves[index] === move.uci)
      )
    )))
      return;
    const evaluations = Array.isArray(raw.evaluations) && raw.evaluations.length > 0 && raw.evaluations.length <= 600 ? raw.evaluations.map((value2) => decodeCommentaryEvaluation(value2, proof.moves.length)) : void 0;
    const validEvaluations = evaluations?.every(
      (value2) => value2 !== void 0 && value2.source !== "response_comparison"
    );
    if (raw.evaluations !== void 0 && !validEvaluations) selectionEvidenceValid = false;
    const conditionalEvaluations = Array.isArray(raw.conditional_evaluations) && raw.conditional_evaluations.length > 0 && raw.conditional_evaluations.length <= 2 ? raw.conditional_evaluations.map((value2) => {
      if (!isObject(value2) || !hasExactKeys(value2, ["search_position_id", "ply_offset", "evaluation"]) || raw.kind === "history" || proof.moves.length < 2 || integerInRange(value2.ply_offset, 1, proof.moves.length - 1) === void 0 || !semanticId(value2.search_position_id) || !Array.isArray(raw.position_ids) || raw.position_ids[value2.ply_offset] !== value2.search_position_id)
        return;
      const offset = value2.ply_offset;
      const evaluation = decodeCommentaryEvaluation(value2.evaluation, proof.moves.length - offset);
      return evaluation?.source === "response_comparison" ? { searchPositionId: value2.search_position_id, plyOffset: offset, evaluation } : void 0;
    }) : void 0;
    const validConditionalEvaluations = conditionalEvaluations?.every((value2) => value2 !== void 0) && new Set(conditionalEvaluations.map((value2) => JSON.stringify(value2))).size === conditionalEvaluations.length;
    if (raw.conditional_evaluations !== void 0 && !validConditionalEvaluations)
      selectionEvidenceValid = false;
    paths.push({
      ...proof,
      kind: raw.kind,
      occurrenceIds: raw.occurrence_ids,
      ...value.positions !== void 0 ? { positionIds: raw.position_ids } : {},
      ...sources ? { sources } : {},
      ...validEvaluations ? { evaluations } : {},
      ...validConditionalEvaluations ? {
        conditionalEvaluations
      } : {}
    });
  }
  if (!unique(paths.map((path) => path.id))) return;
  const statements = [];
  const square = (v) => typeof v === "string" && /^[a-h][1-8]$/.test(v);
  const role = (v) => typeof v === "string" && Object.prototype.hasOwnProperty.call(copies["en-US"].roleLabels, v);
  const piece = (v) => isObject(v) && hasExactKeys(v, ["side", "role", "square"]) && (v.side === "white" || v.side === "black") && role(v.role) && square(v.square);
  const side = (v) => v === "white" || v === "black";
  const list = (v, valid) => Array.isArray(v) && v.every(valid);
  const locatedPiece = (v) => isObject(v) && hasExactKeys(v, ["role", "square"]) && role(v.role) && square(v.square);
  const legalResource = (v) => {
    if (!isObject(v) || !hasExactKeys(v, ["movement", "move_uci", "capture"])) return false;
    const m = v.movement;
    return isObject(m) && hasExactKeys(m, ["side", "from", "to", "before_role", "after_role"]) && side(m.side) && square(m.from) && square(m.to) && role(m.before_role) && role(m.after_role) && validUciMoves([v.move_uci], 1, 1) && v.move_uci.slice(0, 4) === m.from + m.to && (v.capture === null || piece(v.capture));
  };
  const movementResource = (v) => {
    if (!isObject(v) || !hasExactKeys(v, [
      "destination",
      "target",
      "mode",
      ...v.mode === "en_passant_capture" ? ["captured_pawn"] : []
    ]) || !square(v.destination))
      return false;
    const target = v.target;
    return isObject(target) && (target.kind === "empty" ? hasExactKeys(target, ["kind"]) : hasExactKeys(target, ["kind", "role"]) && (target.kind === "friendly" || target.kind === "enemy") && role(target.role)) && (v.mode === "en_passant_capture" ? piece(v.captured_pawn) && v.captured_pawn.role === "pawn" : v.mode === "controlled_destination" || v.mode === "pawn_advance" || v.mode === "pawn_double_advance");
  };
  const pinPath = (v) => {
    if (!isObject(v) || !hasExactKeys(v, ["pinner", "pinned", "king_square", "geometry"]) || !locatedPiece(v.pinner) || !locatedPiece(v.pinned) || !square(v.king_square))
      return false;
    const g = v.geometry;
    if (!isObject(g) || !hasExactKeys(g, ["direction", "squares"]) || !list(g.squares, square) || !g.squares.length || !unique(g.squares))
      return false;
    const d = g.direction;
    return isObject(d) && hasExactKeys(d, ["file_step", "rank_step"]) && integerInRange(d.file_step, -1, 1) !== void 0 && integerInRange(d.rank_step, -1, 1) !== void 0 && (d.file_step !== 0 || d.rank_step !== 0);
  };
  const restrictedRecapture = (v) => isObject(v) && hasExactKeys(v, ["piece", "resource", "king_square", "post_move_controllers", "absolute_pin_paths"]) && locatedPiece(v.piece) && movementResource(v.resource) && square(v.king_square) && list(v.post_move_controllers, locatedPiece) && list(v.absolute_pin_paths, pinPath);
  const checkResponse = (v) => isObject(v) && hasExactKeys(v, ["resource", "modes"]) && legalResource(v.resource) && Array.isArray(v.modes) && v.modes.length > 0 && unique(v.modes) && v.modes.every((mode) => mode === "king_move" || mode === "capture_checker" || mode === "interpose");
  const controlledDestination = (v) => isObject(v) && hasExactKeys(v, ["resource", "controllers"]) && movementResource(v.resource) && list(v.controllers, locatedPiece);
  const pawnState = (v) => isObject(v) && hasExactKeys(v, [
    "side",
    "square",
    "doubled",
    "isolated",
    "passed",
    "geometrically_protected_passer",
    "front_square",
    "front_occupant",
    "component_pawns",
    "connections",
    "enemy_pawn_contacts"
  ]) && side(v.side) && square(v.square) && ["doubled", "isolated", "passed", "geometrically_protected_passer"].every(
    (key) => typeof v[key] === "boolean"
  ) && (v.front_square === null || square(v.front_square)) && (v.front_occupant === null || piece(v.front_occupant)) && list(v.component_pawns, square) && unique(v.component_pawns) && list(v.enemy_pawn_contacts, square) && unique(v.enemy_pawn_contacts) && Array.isArray(v.connections) && v.connections.every(
    (c) => isObject(c) && hasExactKeys(c, ["peer", "kind", "direction"]) && square(c.peer) && (c.kind === "geometric_support" ? c.direction === "supports" || c.direction === "supported_by" : c.kind === "phalanx" && c.direction === "peer")
  );
  const structuralSubject = (v) => {
    if (!isObject(v)) return false;
    const file = typeof v.file === "string" && /^[a-h]$/.test(v.file);
    if (v.kind === "open_file") return hasExactKeys(v, ["kind", "file"]) && file;
    if (!side(v.side)) return false;
    if (v.kind === "semi_open_file") return hasExactKeys(v, ["kind", "side", "file"]) && file;
    if (v.kind === "passed_pawn_created" || v.kind === "passed_pawn_lost")
      return hasExactKeys(v, ["kind", "side", "square"]) && square(v.square);
    if (!square(v.from) || !square(v.to)) return false;
    if (v.kind === "passed_pawn_advanced" || v.kind === "passed_status_created")
      return hasExactKeys(v, ["kind", "side", "from", "to", "relative_rank"]) && integerInRange(v.relative_rank, 1, 8) !== void 0;
    return hasExactKeys(v, ["kind", "side", "from", "to"]) && (v.kind === "pawn_tension_created" || v.kind === "pawn_tension_resolved" || v.kind === "passed_pawn_promoted");
  };
  const structuralChange = (v) => isObject(v) && hasExactKeys(v, ["kind", "subjects", "targets"]) && typeof v.kind === "string" && Object.prototype.hasOwnProperty.call(copies["en-US"].structuralChangeLabels, v.kind) && list(v.subjects, structuralSubject) && list(v.targets, structuralSubject);
  const controlPoint = (v) => {
    if (!isObject(v) || !hasExactKeys(v, ["controller", "target", "state", "premise_ids"]) || v.controller !== null && !piece(v.controller) || v.target !== null && !piece(v.target) || !Array.isArray(v.premise_ids) || !v.premise_ids.every((id2) => !!semanticId(id2)) || !unique(v.premise_ids) || v.state !== "present" && v.state !== "absent" && v.state !== "unknown" && v.state !== "removed" || (v.state === "removed" ? v.controller !== null && v.target !== null : v.controller === null || v.target === null) || (v.state === "unknown" ? v.premise_ids.length !== 0 : v.premise_ids.length === 0))
      return;
    return {
      controller: v.controller,
      target: v.target,
      state: v.state,
      premiseIds: v.premise_ids
    };
  };
  const commonKeys = ["occurrence_id", "side", "role", "from", "to", "premise_ids", "kind"];
  for (const raw of value.statements) {
    if (!isObject(raw) || !semanticId(raw.occurrence_id) || raw.side !== "white" && raw.side !== "black" || !role(raw.role) || !square(raw.from) || !square(raw.to) || !Array.isArray(raw.premise_ids) || raw.premise_ids.length === 0 || !raw.premise_ids.every((id2) => !!semanticId(id2)) || !unique(raw.premise_ids) || occurrences.get(raw.occurrence_id)?.uci.slice(0, 4) !== raw.from + raw.to)
      return;
    const common = {
      occurrenceId: raw.occurrence_id,
      side: raw.side,
      role: raw.role,
      from: raw.from,
      to: raw.to,
      premiseIds: raw.premise_ids
    };
    if (raw.kind === "capture") {
      if (!hasExactKeys(raw, [...commonKeys, "captured_role", "captured_square", "recapture"]) || !role(raw.captured_role) || !square(raw.captured_square) || raw.recapture !== "proven" && raw.recapture !== "excluded" && raw.recapture !== "unknown")
        return;
      statements.push({
        ...common,
        side: raw.side,
        kind: "capture",
        capturedRole: raw.captured_role,
        capturedSquare: raw.captured_square,
        recapture: raw.recapture
      });
    } else if (raw.kind === "development") {
      if (!hasExactKeys(raw, [...commonKeys, "central_squares"]) || !Array.isArray(raw.central_squares) || !unique(raw.central_squares) || !raw.central_squares.every((v) => typeof v === "string" && ["d4", "e4", "d5", "e5"].includes(v)))
        return;
      statements.push({
        ...common,
        side: raw.side,
        kind: "development",
        centralSquares: raw.central_squares
      });
    } else if (raw.kind === "piece_control") {
      if (!hasExactKeys(raw, [...commonKeys, "relation", "before", "after"]) || raw.relation !== "support" && raw.relation !== "attack")
        return;
      const before = controlPoint(raw.before);
      const after = controlPoint(raw.after);
      if (!before || !after || !(before.controller ?? after.controller) || !(before.target ?? after.target))
        return;
      for (const point of [before, after]) {
        if (point.controller && point.target && point.controller.side === point.target.side !== (raw.relation === "support"))
          return;
      }
      statements.push({ ...common, kind: "piece_control", relation: raw.relation, before, after });
    } else if (raw.kind === "recapture_resources") {
      if (!hasExactKeys(raw, [
        ...commonKeys,
        "phase",
        "captured",
        "geometric_recapturers",
        "legal_recaptures",
        "restricted_recaptures"
      ]) || raw.phase !== "after" || !piece(raw.captured) || !list(raw.geometric_recapturers, locatedPiece) || !list(raw.legal_recaptures, legalResource) || !list(raw.restricted_recaptures, restrictedRecapture))
        return;
      statements.push({
        ...common,
        kind: raw.kind,
        phase: raw.phase,
        captured: raw.captured,
        geometric_recapturers: raw.geometric_recapturers,
        legal_recaptures: raw.legal_recaptures,
        restricted_recaptures: raw.restricted_recaptures
      });
    } else if (raw.kind === "check_responses") {
      if (!hasExactKeys(raw, [
        ...commonKeys,
        "phase",
        "checked_side",
        "king_square",
        "checkers",
        "responses",
        "controlled_king_destinations",
        "terminal"
      ]) || raw.phase !== "after" || !side(raw.checked_side) || !square(raw.king_square) || !list(raw.checkers, locatedPiece) || !raw.checkers.length || !list(raw.responses, checkResponse) || !list(raw.controlled_king_destinations, controlledDestination) || raw.terminal !== "ongoing" && raw.terminal !== "checkmate")
        return;
      statements.push({
        ...common,
        kind: raw.kind,
        phase: raw.phase,
        checked_side: raw.checked_side,
        king_square: raw.king_square,
        checkers: raw.checkers,
        responses: raw.responses,
        controlled_king_destinations: raw.controlled_king_destinations,
        terminal: raw.terminal
      });
    } else if (raw.kind === "check_response") {
      if (!hasExactKeys(raw, [
        ...commonKeys,
        "phase",
        "responding_side",
        "king_square",
        "checkers",
        "response"
      ]) || raw.phase !== "before" || !side(raw.responding_side) || !square(raw.king_square) || !list(raw.checkers, locatedPiece) || !raw.checkers.length || !checkResponse(raw.response))
        return;
      statements.push({
        ...common,
        kind: raw.kind,
        phase: raw.phase,
        responding_side: raw.responding_side,
        king_square: raw.king_square,
        checkers: raw.checkers,
        response: raw.response
      });
    } else if (raw.kind === "pawn_structure") {
      if (!hasExactKeys(raw, [...commonKeys, "phase", "before", "after", "changed_facets"]) || raw.phase !== "transition" || raw.before !== null && !pawnState(raw.before) || raw.after !== null && !pawnState(raw.after) || raw.before === null && raw.after === null || !Array.isArray(raw.changed_facets) || !raw.changed_facets.length || !unique(raw.changed_facets) || !raw.changed_facets.every(
        (facet) => typeof facet === "string" && Object.prototype.hasOwnProperty.call(copies["en-US"].pawnFacetLabels, facet)
      ))
        return;
      statements.push({
        ...common,
        kind: raw.kind,
        phase: raw.phase,
        before: raw.before,
        after: raw.after,
        changed_facets: raw.changed_facets
      });
    } else if (raw.kind === "stalemate") {
      if (!hasExactKeys(raw, [...commonKeys, "phase", "stalled_side", "king_square"]) || raw.phase !== "after" || !side(raw.stalled_side) || !square(raw.king_square))
        return;
      statements.push({
        ...common,
        kind: raw.kind,
        phase: raw.phase,
        stalled_side: raw.stalled_side,
        king_square: raw.king_square
      });
    } else if (raw.kind === "castling") {
      if (!hasExactKeys(raw, [...commonKeys, "rook"]) || !isObject(raw.rook) || !hasExactKeys(raw.rook, ["from", "to"]) || !square(raw.rook.from) || !square(raw.rook.to))
        return;
      statements.push({ ...common, kind: raw.kind, rook: { from: raw.rook.from, to: raw.rook.to } });
    } else if (raw.kind === "promotion") {
      if (!hasExactKeys(raw, [...commonKeys, "promoted_role"]) || !role(raw.promoted_role) || raw.promoted_role === "pawn" || raw.promoted_role === "king")
        return;
      statements.push({ ...common, kind: raw.kind, promoted_role: raw.promoted_role });
    } else if (raw.kind === "structural_change") {
      if (!hasExactKeys(raw, [...commonKeys, "phase", "changes"]) || raw.phase !== "transition" || !list(raw.changes, structuralChange))
        return;
      statements.push({ ...common, kind: raw.kind, phase: raw.phase, changes: raw.changes });
    } else return;
  }
  const inputIssues = [];
  if (value.input_issues !== void 0) {
    if (!Array.isArray(value.input_issues)) return;
    for (const raw of value.input_issues) {
      if (!isObject(raw) || !hasExactKeys(raw, ["input_line_index", "accepted_ply_count", "reason"])) return;
      const index = integerInRange(raw.input_line_index, 0, (subject.inputLines?.length ?? 0) - 1);
      if (index === void 0) return;
      const count = integerInRange(raw.accepted_ply_count, 0, subject.inputLines[index].moves.length - 1);
      if (count === void 0 || raw.reason !== "invalid_continuation" && raw.reason !== "automatic_terminal" && raw.reason !== "input_limit")
        return;
      inputIssues.push({ inputLineIndex: index, acceptedPlyCount: count, reason: raw.reason });
    }
    if (!unique(inputIssues.map((issue) => issue.inputLineIndex))) return;
  }
  const ids2 = (v) => Array.isArray(v) && v.length > 0 && v.every((id2) => !!semanticId(id2)) && unique(v);
  const squares = (v) => list(v, square) && unique(v);
  for (const [index, rawPath] of value.paths.entries()) {
    const raw = rawPath.line_summary;
    if (raw === void 0) continue;
    const path = paths[index];
    const owns = (v) => {
      const offset = integerInRange(v.ply_offset, 0, path.moves.length - 1);
      return offset !== void 0 && !!semanticId(v.occurrence_id) && path.occurrenceIds[offset] === v.occurrence_id && (v.move_uci === void 0 || path.moves[offset].uci === v.move_uci);
    };
    const locationKeys = ["ply_offset", "occurrence_id", "move_uci"];
    if (!isObject(raw) || !hasExactKeys(raw, [
      "scope",
      "perspective",
      "premise_ids",
      "events",
      "ending",
      ...raw.material !== void 0 ? ["material"] : []
    ]) || raw.scope !== "observed_line" || !side(raw.perspective) || raw.perspective !== parseFen(path.startFen).unwrap().turn || !ids2(raw.premise_ids) || raw.premise_ids.length !== 1 || !Array.isArray(raw.events) || !raw.events.every(
      (event) => isObject(event) && hasExactKeys(event, [
        "kind",
        ...locationKeys,
        ...["side", "piece_role", "target_role", "square"].filter((key) => event[key] !== void 0)
      ]) && owns(event) && validUciMoves([event.move_uci], 1, 1) && [
        "capture",
        "recapture",
        "check_evasion",
        "castling",
        "check",
        "mate",
        "stalemate",
        "promotion"
      ].includes(event.kind) && (event.side === void 0 || side(event.side)) && (event.piece_role === void 0 || role(event.piece_role)) && (event.target_role === void 0 || role(event.target_role)) && (event.square === void 0 || square(event.square))
    ) || !isObject(raw.ending) || !hasExactKeys(raw.ending, ["kind", "ply_offset", "occurrence_id"]) || !owns(raw.ending) || raw.ending.ply_offset !== path.moves.length - 1 || ![
      "line_end",
      "checkmate",
      "stalemate",
      "insufficient_material",
      "fivefold_repetition",
      "seventy_five_move_rule"
    ].includes(raw.ending.kind))
      return;
    const m = raw.material;
    if (m !== void 0 && (!isObject(m) || !hasExactKeys(m, ["events", "net_cp", "max_gain_cp", "max_loss_cp", "recovered_after_loss"]) || !Number.isSafeInteger(m.net_cp) || !Number.isSafeInteger(m.max_gain_cp) || m.max_gain_cp < 0 || !Number.isSafeInteger(m.max_loss_cp) || m.max_loss_cp > 0 || typeof m.recovered_after_loss !== "boolean" || !Array.isArray(m.events) || !m.events.every((event) => {
      if (!isObject(event) || !hasExactKeys(event, [
        ...locationKeys,
        "side",
        "from",
        "to",
        "before_role",
        "after_role",
        "promotion_gain_cp",
        "delta_cp",
        "balance_cp",
        ...event.capture !== void 0 ? ["capture"] : []
      ]) || !owns(event) || !validUciMoves([event.move_uci], 1, 1) || !side(event.side) || !square(event.from) || !square(event.to) || event.move_uci.slice(0, 4) !== event.from + event.to || !role(event.before_role) || !role(event.after_role) || !Number.isSafeInteger(event.promotion_gain_cp) || event.promotion_gain_cp < 0 || !Number.isSafeInteger(event.delta_cp) || !Number.isSafeInteger(event.balance_cp))
        return false;
      const c = event.capture;
      return c === void 0 || isObject(c) && hasExactKeys(c, ["role", "square", "value_cp", "recapture"]) && role(c.role) && square(c.square) && Number.isSafeInteger(c.value_cp) && c.value_cp > 0 && ["proven", "excluded", "unknown"].includes(c.recapture);
    })))
      return;
    if (isObject(m)) {
      const events = m.events;
      let balance = 0, maxGain = 0, maxLoss = 0, wasNegative = false, recovered = false;
      for (const event of events) {
        const delta = (event.capture?.value_cp ?? 0) + event.promotion_gain_cp;
        const signed = event.side === raw.perspective ? delta : -delta;
        balance += signed;
        if (!Number.isSafeInteger(balance) || event.delta_cp !== signed || event.balance_cp !== balance)
          return;
        maxGain = Math.max(maxGain, balance);
        maxLoss = Math.min(maxLoss, balance);
        recovered ||= wasNegative && balance >= 0;
        wasNegative ||= balance < 0;
      }
      if (events.some((event, i) => i > 0 && event.ply_offset <= events[i - 1].ply_offset) || m.net_cp !== balance || m.max_gain_cp !== maxGain || m.max_loss_cp !== maxLoss || m.recovered_after_loss !== recovered)
        return;
    }
    path.lineSummary = raw;
  }
  const sourceId = (v) => typeof v === "string" && sha256Pattern.test(v);
  const sourceIds = (v) => list(v, sourceId) && v.length > 0 && unique(v);
  const positionResources = (v) => {
    if (!isObject(v) || !hasExactKeys(v, [
      "id",
      "fen",
      "premise_id",
      "controls",
      "rays",
      "pawn_advances",
      "legal_moves",
      "pawn_states",
      "pawn_files"
    ]) || !semanticId(v.id) || !fenText(v.fen) || !semanticId(v.premise_id))
      return false;
    const parsed = parseFen(v.fen);
    if (parsed.isErr) return false;
    const board = parsed.value.board;
    const occupied = (p) => {
      const actual = board.get(parseSquare(p.square));
      return actual?.color === p.side && actual.role === p.role;
    };
    const c = v.controls, r = v.rays, l = v.legal_moves, ps = v.pawn_states, pf = v.pawn_files, a = v.pawn_advances;
    const pawnSquares = Array.from({ length: 64 }, (_, i) => i).filter((i) => board.get(i)?.role === "pawn");
    const nullableBoolean = (value2) => value2 === null || typeof value2 === "boolean";
    return isObject(ps) && hasExactKeys(ps, ["complete", "pawns"]) && typeof ps.complete === "boolean" && Array.isArray(ps.pawns) && ps.pawns.length === pawnSquares.length && ps.pawns.every(
      (entry) => isObject(entry) && hasExactKeys(entry, ["square", "passed", "isolated", "doubled", "source_ids"]) && square(entry.square) && board.get(parseSquare(entry.square))?.role === "pawn" && nullableBoolean(entry.passed) && nullableBoolean(entry.isolated) && nullableBoolean(entry.doubled) && list(entry.source_ids, sourceId) && unique(entry.source_ids) && [entry.passed, entry.isolated, entry.doubled].some((x) => x !== null) === entry.source_ids.length > 0
    ) && unique(ps.pawns.map((entry) => entry.square)) && ps.complete === ps.pawns.every((entry) => entry.passed !== null && entry.isolated !== null && entry.doubled !== null) && isObject(pf) && hasExactKeys(pf, ["complete", "files"]) && typeof pf.complete === "boolean" && Array.isArray(pf.files) && pf.files.length <= 8 && (pf.complete ? pf.files.length === 8 : pf.files.length < 8) && pf.files.every(
      (entry) => isObject(entry) && hasExactKeys(entry, ["file", "occupancy", "source_ids"]) && typeof entry.file === "string" && /^[a-h]$/.test(entry.file) && ["open", "white_pawns_only", "black_pawns_only", "both_sides"].includes(
        entry.occupancy
      ) && sourceIds(entry.source_ids) && entry.source_ids.length === 2
    ) && unique(pf.files.map((entry) => entry.file)) && isObject(l) && hasExactKeys(l, ["complete", "moves"]) && typeof l.complete === "boolean" && Array.isArray(l.moves) && l.moves.every((entry) => {
      if (!isObject(entry) || !hasExactKeys(entry, [
        "uci",
        "destination",
        "source_id",
        ...entry.captured_square === void 0 ? [] : ["captured_square"],
        ...entry.gives_check === void 0 ? [] : ["gives_check"]
      ]) || entry.gives_check !== void 0 && typeof entry.gives_check !== "boolean" || !validUciMoves([entry.uci], 1, 1) || !square(entry.destination) || !sourceId(entry.source_id))
        return false;
      const from = entry.uci.slice(0, 2), to = entry.uci.slice(2, 4), actor = board.get(parseSquare(from));
      if (actor?.color !== parsed.value.turn) return false;
      if (entry.captured_square !== void 0) {
        if (!square(entry.captured_square)) return false;
        const captured = board.get(parseSquare(entry.captured_square));
        if (!captured || captured.color === actor.color) return false;
        if (entry.captured_square !== entry.destination && (actor.role !== "pawn" || captured.role !== "pawn" || board.has(parseSquare(entry.destination)) || entry.captured_square !== `${to[0]}${from[1]}`))
          return false;
      }
      if (entry.destination === to) return true;
      const rook = board.get(parseSquare(to));
      return actor.role === "king" && rook?.role === "rook" && rook.color === actor.color && from[1] === to[1] && entry.destination === `${to[0] > from[0] ? "g" : "c"}${from[1]}`;
    }) && unique(l.moves.map((entry) => entry.uci)) && unique(l.moves.map((entry) => entry.source_id)) && isObject(c) && hasExactKeys(c, ["complete", "pieces"]) && typeof c.complete === "boolean" && Array.isArray(c.pieces) && c.pieces.every(
      (entry) => isObject(entry) && hasExactKeys(entry, ["piece", "squares", "source_ids"]) && piece(entry.piece) && occupied(entry.piece) && squares(entry.squares) && sourceIds(entry.source_ids) && entry.source_ids.length === entry.squares.length
    ) && unique(
      c.pieces.map((entry) => entry.piece.square)
    ) && isObject(r) && hasExactKeys(r, ["complete", "lines"]) && typeof r.complete === "boolean" && Array.isArray(r.lines) && r.lines.every((entry) => {
      if (!isObject(entry) || !hasExactKeys(entry, ["piece", "squares", "occupants", "source_id"]) || !piece(entry.piece) || !["bishop", "rook", "queen"].includes(entry.piece.role) || !occupied(entry.piece) || !squares(entry.squares) || !entry.squares.length || !list(entry.occupants, piece) || !sourceId(entry.source_id))
        return false;
      const occupiedSquares = entry.squares.filter((key) => board.has(parseSquare(key)));
      return entry.occupants.length === occupiedSquares.length && entry.occupants.every((p, i) => occupied(p) && p.square === occupiedSquares[i]);
    }) && isObject(a) && hasExactKeys(a, ["complete", "paths"]) && typeof a.complete === "boolean" && Array.isArray(a.paths) && a.paths.every(
      (entry) => isObject(entry) && hasExactKeys(entry, ["piece", "destination", "traversed_squares", "source_id"]) && piece(entry.piece) && entry.piece.role === "pawn" && occupied(entry.piece) && square(entry.destination) && squares(entry.traversed_squares) && entry.traversed_squares.length >= 1 && entry.traversed_squares.length <= 2 && entry.traversed_squares[entry.traversed_squares.length - 1] === entry.destination && entry.traversed_squares.every((key) => !board.has(parseSquare(key))) && sourceId(entry.source_id)
    );
  };
  let positions;
  const occurrencePositions = /* @__PURE__ */ new Map();
  if (value.positions !== void 0) {
    if (!list(value.positions, positionResources) || !unique(value.positions.map((p) => p.id))) return;
    positions = value.positions;
    const byId2 = new Map(positions.map((p) => [p.id, p]));
    const incomingOccurrences = /* @__PURE__ */ new Map();
    for (const path of paths) {
      for (const [i, id2] of path.positionIds.entries()) {
        if (id2 === null) continue;
        if (byId2.get(id2)?.fen !== (i === 0 ? path.startFen : path.moves[i - 1].fenAfter)) return;
        const incoming = path.occurrenceIds[i - 1];
        if (incoming) {
          const previous = incomingOccurrences.get(id2);
          if (previous !== void 0 && previous !== incoming) return;
          incomingOccurrences.set(id2, incoming);
        }
      }
      for (const [i, id2] of path.occurrenceIds.entries()) {
        if (id2 === null) continue;
        const pair = path.positionIds.slice(i, i + 2);
        const previous = occurrencePositions.get(id2);
        if (previous && previous.some((p, i2) => p !== pair[i2])) return;
        occurrencePositions.set(id2, pair);
      }
    }
  }
  const highlights = [];
  const seen = /* @__PURE__ */ new Set();
  const byId = new Map(positions?.map((p) => [p.id, p]));
  const positionSources = /* @__PURE__ */ new Map();
  const premises = new Map(Array.from(occurrences.keys(), (id2) => [id2, /* @__PURE__ */ new Set([id2])]));
  for (const statement of statements) {
    const refs = premises.get(statement.occurrenceId);
    for (const id2 of statement.premiseIds) refs.add(id2);
    if (statement.kind === "piece_control")
      for (const id2 of [...statement.before.premiseIds, ...statement.after.premiseIds]) refs.add(id2);
  }
  for (const [occurrenceId, pair] of occurrencePositions)
    for (const id2 of pair) {
      const position = id2 ? byId.get(id2) : void 0;
      if (position) premises.get(occurrenceId).add(position.premise_id);
    }
  if (Array.isArray(value.highlights))
    for (const raw of value.highlights) {
      const linked = isObject(raw) && ("premise_ids" in raw || "frames" in raw);
      if (!isObject(raw) || !hasExactKeys(raw, [
        "occurrence_id",
        "text",
        "squares",
        ...linked ? ["premise_ids", "frames"] : []
      ]) || typeof raw.occurrence_id !== "string" || !occurrences.has(raw.occurrence_id) || typeof raw.text !== "string" || !raw.text.trim() || raw.text.length > 1e3 || !squares(raw.squares) || raw.squares.length === 0 || raw.squares.length > 64)
        continue;
      const highlight = { occurrenceId: raw.occurrence_id, text: raw.text, squares: raw.squares };
      const frames = [];
      if (linked) {
        if (!Array.isArray(raw.premise_ids) || raw.premise_ids.length > 64 || !unique(raw.premise_ids) || !raw.premise_ids.every((id2) => premises.get(raw.occurrence_id).has(id2)) || !Array.isArray(raw.frames) || !raw.frames.length || raw.frames.length > 2)
          continue;
        for (const frame of raw.frames) {
          if (!isObject(frame) || !hasExactKeys(frame, ["phase", "position_id", "squares", "source_ids"]) || frame.phase !== "before" && frame.phase !== "after" || typeof frame.position_id !== "string" || occurrencePositions.get(raw.occurrence_id)?.[frame.phase === "before" ? 0 : 1] !== frame.position_id || !squares(frame.squares) || !frame.squares.length || frame.squares.length > 64 || !frame.squares.every((key2) => highlight.squares.includes(key2)) || !list(frame.source_ids, sourceId) || !unique(frame.source_ids))
            break;
          const position = byId.get(frame.position_id);
          if (!position) break;
          let sources = positionSources.get(position.id);
          if (!sources) {
            sources = /* @__PURE__ */ new Set([
              ...position.controls.pieces.flatMap((p) => p.source_ids),
              ...position.rays.lines.map((r) => r.source_id),
              ...position.legal_moves.moves.map((m) => m.source_id),
              ...position.pawn_states.pawns.flatMap((p) => p.source_ids),
              ...position.pawn_files.files.flatMap((f) => f.source_ids),
              ...position.pawn_advances.paths.map((p) => p.source_id)
            ]);
            positionSources.set(position.id, sources);
          }
          if (!frame.source_ids.every((id2) => sources.has(id2))) break;
          frames.push({
            phase: frame.phase,
            positionId: frame.position_id,
            squares: frame.squares,
            sourceIds: frame.source_ids
          });
        }
        if (frames.length !== raw.frames.length || !unique(frames.map((frame) => frame.phase))) continue;
      }
      const key = `${raw.occurrence_id}:${raw.text}`;
      if (seen.has(key)) continue;
      seen.add(key);
      highlights.push(linked ? { ...highlight, premiseIds: raw.premise_ids, frames } : highlight);
    }
  const result = {
    paths,
    statements,
    ...highlights.length ? { highlights } : {},
    ...positions ? { positions } : {},
    ...inputIssues.length ? { inputIssues } : {}
  };
  if (value.selection !== void 0 && selectionEvidenceValid)
    result.selection = decodeCommentarySelection(value.selection, result, {
      rootFen: subject.before.fen,
      playedMove: subject.played.uci,
      engineProfile
    });
  return result;
}
function moveReviewSan(fen, uci2) {
  try {
    const position = setupPosition("chess", parseFen(fen).unwrap()).unwrap();
    const move = parseUci(uci2);
    return move && position.isLegal(move) ? makeSan(position, move) : "?";
  } catch (_) {
    return "?";
  }
}
function moveReviewSans(fen, moves) {
  return buildProof("display", fen, moves)?.moves.map((move) => move.label) ?? [];
}
function buildProof(id2, startFen, moves) {
  if (!semanticId(id2) || moves.length < 1 || moves.length > 600) return;
  try {
    const position = setupPosition("chess", parseFen(startFen).unwrap()).unwrap();
    const proofMoves = [];
    for (const rawMove of moves) {
      const move = parseUci(rawMove);
      if (!move || !position.isLegal(move)) return;
      const label = makeSanAndPlay(position, move);
      proofMoves.push({ uci: rawMove, label, fenAfter: makeFen(position.toSetup()) });
    }
    return { id: id2, startFen, moves: proofMoves };
  } catch (_) {
    return;
  }
}
function projectEndpoint(value) {
  if (!isObject(value) || !validUciMoves(value.moves, 1, 80)) return;
  if (value.kind === "engine_search") {
    const winPercent = finiteNumber(value.win_percent_for_mover, 0, 100);
    const depth = integerInRange(value.depth, 1, 100);
    return winPercent !== void 0 && depth !== void 0 ? { moves: [...value.moves], winPercent } : void 0;
  }
  if (value.kind === "exact_automatic_terminal") {
    const terminal = projectAutomaticTerminal(value.terminal);
    return terminal ? { moves: [...value.moves], terminal } : void 0;
  }
  return;
}
function projectDelta(value) {
  if (!isObject(value) || value.kind !== "engine_evaluation" && value.kind !== "outcome_only") return;
  return finiteNumber(value.candidate_win_percent_delta_for_mover, -100, 100);
}
function projectAutomaticTerminal(value) {
  if (!isObject(value) || typeof value.kind !== "string") return;
  if (value.kind === "checkmate")
    return value.winner === "white" || value.winner === "black" ? { kind: "checkmate", winner: value.winner } : void 0;
  if (value.kind === "stalemate" || value.kind === "insufficient_material" || value.kind === "fivefold_repetition" || value.kind === "seventy_five_move_rule")
    return { kind: value.kind };
  return;
}
function projectDrawClaims(value) {
  if (!Array.isArray(value) || value.length < 1 || value.length > 4) return;
  const claims = value.map(projectDrawClaim);
  return claims.every((claim) => !!claim) ? claims : void 0;
}
function projectDrawClaim(value) {
  if (!isObject(value) || value.rule !== "threefold_repetition" && value.rule !== "fifty_move_rule" || value.availability !== "available_now" && value.availability !== "available_by_declared_move")
    return;
  if (value.availability === "available_now")
    return hasExactKeys(value, ["rule", "availability"]) ? { rule: value.rule, availability: value.availability } : void 0;
  return hasExactKeys(value, ["rule", "availability", "move_ucis"]) && validUciMoves(value.move_ucis, 1, 218) ? { rule: value.rule, availability: value.availability, moveUcis: [...value.move_ucis] } : void 0;
}
function replayFen(initialFen, moves) {
  try {
    const position = setupPosition("chess", parseFen(initialFen).unwrap()).unwrap();
    for (const rawMove of moves) {
      const move = parseUci(rawMove);
      if (!move || !position.isLegal(move)) return;
      position.play(move);
    }
    return makeFen(position.toSetup());
  } catch (_) {
    return;
  }
}
function moveReviewVerdictCode(value) {
  return typeof value === "string" && Object.prototype.hasOwnProperty.call(verdictSymbolByCode, value) ? value : void 0;
}
function projectLocalEvalScore(value) {
  if (value.cp !== void 0 && value.mate === void 0)
    return Number.isSafeInteger(value.cp) ? { kind: "cp", value: value.cp } : void 0;
  if (value.mate !== void 0 && value.cp === void 0)
    return Number.isSafeInteger(value.mate) && value.mate !== 0 ? { kind: "mate", value: value.mate } : void 0;
  return;
}
function isObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function hasExactKeys(value, required) {
  const keys = Object.keys(value);
  return keys.length === required.length && required.every((keyName) => Object.prototype.hasOwnProperty.call(value, keyName));
}
function hasOnlyKeys(value, allowed, required = allowed) {
  const keys = Object.keys(value);
  return keys.every((keyName) => allowed.includes(keyName)) && required.every((keyName) => keys.includes(keyName));
}
function arrayEquals(first, second) {
  return first.length === second.length && first.every((value, index) => value === second[index]);
}
function arrayPrefix(prefix, values) {
  return prefix.length <= values.length && prefix.every((value, index) => value === values[index]);
}
function unique(values) {
  return new Set(values).size === values.length;
}
function semanticId(value) {
  return typeof value === "string" && value.length >= 1 ? value : void 0;
}
function fenText(value) {
  return typeof value === "string" && value.length >= 1 && value.length <= 128 ? value : void 0;
}
function san(value) {
  return typeof value === "string" && value.trim().length > 0 && value.length <= 64 ? value : void 0;
}
function uci(value) {
  return typeof value === "string" && uciPattern.test(value) ? value : void 0;
}
function validUciMoves(value, minimum, maximum = Number.MAX_SAFE_INTEGER) {
  return Array.isArray(value) && value.length >= minimum && value.length <= maximum && value.every((move) => !!uci(move));
}
function nonNegativeInteger(value) {
  return integerInRange(value, 0, Number.MAX_SAFE_INTEGER);
}
function integerInRange(value, minimum, maximum) {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= minimum && value <= maximum ? value : void 0;
}
function finiteNumber(value, minimum, maximum) {
  return typeof value === "number" && Number.isFinite(value) && value >= minimum && value <= maximum ? value : void 0;
}
var moveReviewJobRequestSchema, moveReviewJobStatusSchema, moveReviewResponseSchema, moveReviewEngineWorkReportSchema, moveReviewAnnotationPolicyRevision, moveReviewBudgets, verdictSymbolByCode, copies, requestIdPattern, jobIdPattern, workIdPattern, sha256Pattern, uciPattern;
var init_moveReview = __esm({
  "lila-docker/repos/lila/ui/analyse/src/moveReview.ts"() {
    init_types2();
    init_util2();
    init_fen();
    init_san();
    init_util();
    init_variant();
    init_util3();
    init_moveReviewSelection();
    moveReviewJobRequestSchema = "chesstory.position-commentary.job-request.v6";
    moveReviewJobStatusSchema = "chesstory.position-commentary.job-status.v6";
    moveReviewResponseSchema = "chesstory.position-commentary.response.v6";
    moveReviewEngineWorkReportSchema = "chesstory.position-commentary.engine-work-report.v6";
    moveReviewAnnotationPolicyRevision = "chesstory.verdict-threshold-policy.v2";
    moveReviewBudgets = { singleMs: 1e4, jobSafetyMs: 18e4 };
    verdictSymbolByCode = {
      improves_on_reference: "none",
      matches_reference: "none",
      playable_loss: "none",
      inaccuracy: "?!",
      mistake: "?",
      blunder: "??"
    };
    copies = {
      "ko-KR": {
        title: "\uC9C1\uC804 \uC218 \uB9AC\uBDF0",
        idleTitle: "\uC544\uC9C1 \uB9AC\uBDF0\uD560 \uC218\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4",
        idleBody: "\uC218\uB97C \uB450\uAC70\uB098 \uAE30\uBCF4\uC5D0\uC11C \uC218\uB97C \uC120\uD0DD\uD558\uC138\uC694.",
        analysing: "\uC9C1\uC804 \uC218\uB97C \uBD84\uC11D\uD558\uACE0 \uC788\uC2B5\uB2C8\uB2E4\u2026",
        completed: "\uC9C1\uC804 \uC218 \uB9AC\uBDF0\uAC00 \uC644\uB8CC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
        liveEnginePaused: "\uB9AC\uBDF0\uAC00 \uB05D\uB0A0 \uB54C\uAE4C\uC9C0 \uC2E4\uC2DC\uAC04 \uC5D4\uC9C4\uC744 \uC7A0\uC2DC \uBA48\uCDC4\uC2B5\uB2C8\uB2E4.",
        unavailable: "\uC9C1\uC804 \uC218 \uB9AC\uBDF0\uB97C \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
        unsupported: "\uC5D4\uC9C4 \uBD84\uC11D\uC744 \uC2DC\uC791\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
        retry: "\uB2E4\uC2DC \uC2DC\uB3C4",
        gradeNotRequested: "\uC774 \uC218\uC758 \uD3C9\uAC00\uB294 \uC694\uCCAD\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
        requestGrade: "\uC774 \uC218 \uD3C9\uAC00\uD558\uAE30",
        observationsLoading: "\uC785\uB825\uB41C \uC218\uC21C\uC758 \uAD00\uCC30\uC744 \uBD88\uB7EC\uC624\uACE0 \uC788\uC2B5\uB2C8\uB2E4\u2026",
        observationsMissing: "\uC774 \uC218\uC758 \uC785\uB825 \uC218\uC21C \uAD00\uCC30\uC740 \uC544\uC9C1 \uC5C6\uC2B5\uB2C8\uB2E4.",
        best: "\uCD08\uAE30 \uAC80\uC0C9 1\uC21C\uC704",
        played: "\uB454 \uC218",
        alternative: "\uB300\uC548",
        candidateMoves: "\uD6C4\uBCF4 \uC218",
        lineInsight: "\uAC80\uC99D\uB41C \uD6C4\uBCF4 \uC218\uC21C",
        forcedSingleMove: "\uAC15\uC81C\uB41C \uB2E8\uC77C \uC218",
        candidateUnavailable: "\uC774 \uD6C4\uBCF4 \uC218\uC758 \uBD84\uC11D\uC774 \uBCF4\uB958\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
        analysisStopped: "\uBD84\uC11D \uC911\uB2E8",
        observationsTitle: "\uD655\uC778\uB41C \uC218\uC758 \uB0B4\uC6A9",
        workTitle: "\uAE30\uBB3C\uC758 \uC5ED\uD560",
        comparisonUnavailable: "\uBE44\uAD50 \uD310\uC815\uC774 \uC81C\uACF5\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
        pathLabels: { played: "\uC120\uD0DD\uD55C \uC218", analysis: "\uBD84\uC11D \uAC00\uC9C0", history: "\uC9C1\uC804 \uC218\uBD80\uD130" },
        lineSourceLabels: {
          pgn_record: "\uC785\uB825 \uAE30\uBCF4\uC758 \uB300\uAD6D \uC218\uC21C",
          analysis: "\uC785\uB825\uB41C \uBD84\uC11D \uAC00\uC9C0",
          study: "Study \uC218\uC21C \xB7 \uC2E4\uC804 \uC5EC\uBD80 \uBBF8\uD655\uC778"
        },
        inputIssueText: {
          invalid_continuation: "\uC785\uB825 \uC218\uC21C {line}: {ply}\uC218\uAE4C\uC9C0 \uBCF4\uC874\uD588\uC2B5\uB2C8\uB2E4. \uADF8\uB2E4\uC74C \uC218\uC758 \uC5F0\uC18D\uC131\uC744 \uAC80\uC99D\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
          automatic_terminal: "\uC785\uB825 \uC218\uC21C {line}: {ply}\uC218\uC5D0\uC11C \uB300\uAD6D\uC774 \uC790\uB3D9 \uC885\uB8CC\uB418\uC5B4 \uC774\uD6C4 \uC218\uB97C \uC81C\uC678\uD588\uC2B5\uB2C8\uB2E4.",
          input_limit: "\uC785\uB825 \uC218\uC21C {line}: \uC218\uC21C \uCC98\uB9AC \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD558\uC5EC {ply}\uC218\uAE4C\uC9C0 \uBCF4\uC874\uD588\uC2B5\uB2C8\uB2E4."
        },
        roleLabels: { pawn: "\uD3F0", knight: "\uB098\uC774\uD2B8", bishop: "\uBE44\uC20D", rook: "\uB8E9", queen: "\uD038", king: "\uD0B9" },
        captureText: "{side} {role}: {square}\uC758 \uC0C1\uB300 {captured} \uD3EC\uD68D.",
        recaptureText: "\uC9C1\uC804\uC5D0 \uD3EC\uD68D\uD55C \uC0C1\uB300 \uAE30\uBB3C\uC744 \uB418\uC7A1\uC2B5\uB2C8\uB2E4.",
        recaptureUnknown: "\uC774\uBC88 \uD3EC\uD68D\uC774 \uC7AC\uD3EC\uD68D\uC778\uC9C0\uB294 \uD655\uC778\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
        developmentText: "{side} {role}: \uC2DC\uC791 \uCE78 {from}\uC744 \uCC98\uC74C \uB5A0\uB098 {to}\uB85C \uC774\uB3D9\uD569\uB2C8\uB2E4.",
        centralControlText: "\uC774 \uC704\uCE58\uC5D0\uC11C \uC911\uC559\uC758 {squares} \uCE78\uC744 \uC9C0\uBC30\uD569\uB2C8\uB2E4.",
        frameLabels: { before: "\uC218 \uC774\uC804", after: "\uC218 \uC774\uD6C4" },
        controlRelationLabels: { support: "\uAE30\uD558\uC801 \uC9C0\uC6D0", attack: "\uAE30\uD558\uC801 \uACF5\uACA9" },
        controlStateLabels: { present: "\uC131\uB9BD", absent: "\uC131\uB9BD\uD558\uC9C0 \uC54A\uC74C", unknown: "\uBBF8\uD655\uC778", removed: "\uAE30\uBB3C \uC81C\uAC70" },
        controlChangeLabels: {
          created: "\uAD00\uACC4\uAC00 \uC0DD\uACBC\uC2B5\uB2C8\uB2E4",
          retained: "\uAD00\uACC4\uAC00 \uC720\uC9C0\uB429\uB2C8\uB2E4",
          lost: "\uAD00\uACC4\uAC00 \uC0AC\uB77C\uC84C\uC2B5\uB2C8\uB2E4",
          removed: "\uAD00\uACC4\uAC00 \uAE30\uBB3C \uC81C\uAC70\uB85C \uB05D\uB0AC\uC2B5\uB2C8\uB2E4"
        },
        removedPiece: "\uC81C\uAC70\uB41C \uAE30\uBB3C",
        observationDetails: "\uD3F0\xB7\uAD6C\uC870 \uBCC0\uD654 \uC0C1\uC138 ({count})",
        resourceLabels: {
          square: "\uC0B4\uD3B4\uBCFC \uCE78",
          choose: "\uCE78 \uC120\uD0DD",
          controls: "\uC774 \uCE78\uC744 \uD1B5\uC81C\uD558\uB294 \uAE30\uBB3C",
          outgoingControls: "\uC120\uD0DD \uAE30\uBB3C\uC774 \uD1B5\uC81C\uD558\uB294 \uCE78",
          legalMoves: "\uC120\uD0DD \uAE30\uBB3C\uC758 \uD569\uBC95\uC801\uC778 \uC774\uB3D9",
          noLegalMoves: "\uC774 \uAE30\uBB3C\uC740 \uD604\uC7AC \uD569\uBC95\uC801\uC778 \uC774\uB3D9\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.",
          pawnState: "\uD604\uC7AC \uD3F0 \uC0C1\uD0DC",
          rookFile: "\uC774 \uB8E9\uC774 \uB193\uC778 \uD30C\uC77C",
          openFile: "\uC5F4\uB9B0 \uD30C\uC77C: \uC591\uCE21 \uD3F0\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.",
          semiOpenFile: "\uC774 \uB8E9 \uCABD\uC5D0 \uBC18\uC5F4\uB9B0 \uD30C\uC77C: \uC0C1\uB300 \uD3F0\uB9CC \uC788\uC2B5\uB2C8\uB2E4.",
          ownPawnFile: "\uC774 \uB8E9 \uCABD\uC758 \uD3F0\uC774 \uC788\uB294 \uD30C\uC77C\uC785\uB2C8\uB2E4.",
          unconfirmed: "\uBBF8\uD655\uC778",
          friendlySupport: "\uAC19\uC740 \uD3B8 \uAE30\uBB3C\uC758 \uAE30\uD558\uC801 \uC9C0\uC6D0",
          capturedOn: "\uD3EC\uD68D\uB418\uB294 \uCE78",
          opposingControl: "\uC0C1\uB300 \uAE30\uBB3C\uC758 \uD1B5\uC81C",
          rays: "\uAD00\uB828 \uAD11\uC120",
          advances: "\uAD00\uB828 \uD3F0 \uC804\uC9C4 \uACBD\uB85C",
          first: "\uCCAB \uC7A5\uC560\uBB3C",
          behind: "\uADF8 \uB4A4\uC758 \uAE30\uBB3C (\uAC70\uB9AC\uC21C)",
          path: "\uACBD\uB85C",
          none: "\uC5C6\uC74C",
          partial: "\uC77C\uBD80 \uADFC\uAC70\uB9CC \uD655\uC778\uB428. \uB2E4\uB978 \uC790\uC6D0\uC758 \uBD80\uC7AC\uB294 \uD655\uC778\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
          unavailable: "\uC774 \uC704\uCE58\uC758 \uADFC\uAC70\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4.",
          legal: "\uD569\uBC95\uC801\uC778 \uC774\uB3D9",
          illegal: "\uD604\uC7AC \uD569\uBC95\uC801\uC774\uC9C0 \uC54A\uC740 \uC774\uB3D9",
          not_turn: "\uC774 \uAE30\uBB3C \uCABD\uC758 \uCC28\uB840\uAC00 \uC544\uB2D9\uB2C8\uB2E4. \uD569\uBC95\uC131\uC740 \uD310\uC815\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
          unknown: "\uD569\uBC95\uC131 \uBBF8\uD655\uC778",
          relationships: "\uAE30\uBB3C \uAD00\uACC4"
        },
        lineLabels: {
          title: "\uC774 \uC218\uC21C\uC5D0\uC11C \uAD00\uCC30\uB41C \uACB0\uACFC",
          material: "\uBB3C\uC9C8 \uBCC0\uD654",
          units: "\uC218\uC21C \uC2DC\uC791 \uB300\uBE44 {side}\uC758 \uBB3C\uC9C8 \uBCC0\uD654\uC785\uB2C8\uB2E4. \uD3F0 \uD558\uB098\uB97C 1\uB85C \uD658\uC0B0\uD558\uBA70 \uC5D4\uC9C4 \uD3C9\uAC00\uAC00 \uC544\uB2D9\uB2C8\uB2E4.",
          delta: "\uC774\uBC88 \uBCC0\uD654",
          balance: "\uB204\uC801 \uBCC0\uD654",
          net: "\uB05D\uC5D0\uC11C\uC758 \uBCC0\uD654",
          maximum: "\uAC00\uC7A5 \uB192\uC558\uB358 \uBCC0\uD654",
          minimum: "\uAC00\uC7A5 \uB0AE\uC558\uB358 \uBCC0\uD654",
          recovered: "\uC774 \uC218\uC21C \uC911 \uC190\uC2E4 \uC774\uD6C4 \uB204\uC801 \uBCC0\uD654\uAC00 0 \uC774\uC0C1\uC73C\uB85C \uB3CC\uC544\uC628 \uC2DC\uC810\uC774 \uC788\uC2B5\uB2C8\uB2E4. \uC774\uD6C4 \uB2E4\uC2DC \uC783\uC744 \uC218 \uC788\uC2B5\uB2C8\uB2E4.",
          noMaterialEvents: "\uC774 \uC218\uC21C\uC5D0 \uBB3C\uC9C8 \uBCC0\uD654 \uC0AC\uAC74\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.",
          missingMaterial: "\uC774 \uC218\uC21C\uC758 \uBB3C\uC9C8 \uBCC0\uD654 \uADFC\uAC70\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4.",
          missingSummary: "\uC774 \uC218\uC21C\uC758 \uACB0\uACFC \uADFC\uAC70\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4.",
          limit: "\uD45C\uC2DC\uD55C \uC218\uC21C \uC548\uC5D0\uC11C\uC758 \uACB0\uACFC\uC785\uB2C8\uB2E4. \uCD5C\uC120 \uC751\uC218 \uC544\uB798 \uAC15\uC81C\uB418\uB294 \uC774\uB4DD\uC774\uB098 \uC601\uAD6C\uC801 \uC774\uB4DD\uC744 \uB73B\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
          line_end: "\uC5EC\uAE30\uC11C \uC785\uB825\xB7\uBD84\uC11D\uB41C \uC218\uC21C\uC774 \uB05D\uB0A9\uB2C8\uB2E4.",
          checkmate: "\uC218\uC21C \uB05D\uC5D0\uC11C \uCCB4\uD06C\uBA54\uC774\uD2B8\uC785\uB2C8\uB2E4.",
          stalemate: "\uC218\uC21C \uB05D\uC5D0\uC11C \uC2A4\uD14C\uC77C\uBA54\uC774\uD2B8\uC785\uB2C8\uB2E4.",
          promotionGain: "\uC2B9\uACA9\uC5D0 \uC758\uD55C \uBB3C\uC9C8 \uC99D\uAC00",
          value: "\uAE30\uBB3C \uAC00\uCE58"
        },
        lineEventLabels: {
          capture: "\uD3EC\uD68D",
          recapture: "\uC989\uC2DC \uC7AC\uD3EC\uD68D",
          check_evasion: "\uCCB4\uD06C \uC751\uC218",
          castling: "\uCE90\uC2AC\uB9C1",
          check: "\uCCB4\uD06C",
          mate: "\uCCB4\uD06C\uBA54\uC774\uD2B8",
          stalemate: "\uC2A4\uD14C\uC77C\uBA54\uC774\uD2B8",
          promotion: "\uC2B9\uACA9"
        },
        lineEventText: {
          recapture: "{side} {role}: {square}\uC758 \uC0C1\uB300 {captured} \uC7AC\uD3EC\uD68D.",
          check_evasion: "{side}: \uCCB4\uD06C\uB97C \uD574\uC18C\uD569\uB2C8\uB2E4.",
          castling: "{side}: \uCE90\uC2AC\uB9C1\uD558\uC5EC \uD0B9\uC744 {square}\uC5D0 \uB461\uB2C8\uB2E4.",
          check: "{side}: {square}\uC758 \uC0C1\uB300 \uD0B9\uC5D0\uAC8C \uCCB4\uD06C.",
          mate: "{side}: {square}\uC758 \uC0C1\uB300 \uD0B9\uC744 \uCCB4\uD06C\uBA54\uC774\uD2B8\uD569\uB2C8\uB2E4.",
          stalemate: "{side}: {square}\uC758 \uC0C1\uB300 \uD0B9\uC744 \uC2A4\uD14C\uC77C\uBA54\uC774\uD2B8 \uC0C1\uD0DC\uB85C \uB9CC\uB4ED\uB2C8\uB2E4.",
          promotion: "{side}: {square}\uC5D0\uC11C {captured} \uC2B9\uACA9."
        },
        observationLabels: {
          recapture_resources: "\uC7AC\uD3EC\uD68D \uC790\uC6D0",
          check_responses: "\uCCB4\uD06C\uC640 \uD569\uBC95 \uC751\uC218",
          check_response: "\uC120\uD0DD\uD55C \uCCB4\uD06C \uC751\uC218",
          pawn_structure: "\uD3F0 \uAD6C\uC870 \uBCC0\uD654",
          stalemate: "\uC2A4\uD14C\uC77C\uBA54\uC774\uD2B8",
          castling: "\uCE90\uC2AC\uB9C1",
          promotion: "\uC2B9\uACA9",
          structural_change: "\uAD6C\uC870 \uBCC0\uD654 \uADFC\uAC70"
        },
        illegalRecaptureText: "{piece}\uC758 {square} \uC7AC\uD3EC\uD68D\uC740 {king}\uC758 \uD0B9\uC744 {controllers}\uC758 \uACF5\uACA9\uC5D0 \uB178\uCD9C\uD558\uBBC0\uB85C \uD569\uBC95\uC801\uC778 \uC218\uAC00 \uC544\uB2D9\uB2C8\uB2E4.",
        observationFields: {
          none: "\uC5C6\uC74C",
          yes: "\uC608",
          no: "\uC544\uB2C8\uC624",
          geometric: "\uAE30\uD558\uC801 \uC7AC\uD3EC\uD68D \uAE30\uBB3C",
          legal: "\uD569\uBC95 \uC751\uC218",
          restricted: "\uC81C\uD55C\uB41C \uC751\uC218",
          captured: "\uC7A1\uD78C \uAE30\uBB3C",
          checkers: "\uCCB4\uD06C \uAE30\uBB3C",
          king: "\uD0B9",
          relatedTargets: "\uAD00\uB828 \uB300\uC0C1",
          pins: "\uC808\uB300 \uD540 \uACBD\uB85C",
          controlledDestinations: "\uD1B5\uC81C\uB41C \uD0B9 \uC774\uB3D9\uCE78",
          frontSquare: "\uC55E\uCE78",
          frontOccupant: "\uC55E\uCE78 \uAE30\uBB3C",
          component: "\uC5F0\uACB0\uB41C \uD3F0 \uC9D1\uD569",
          connections: "\uD3F0 \uC5F0\uACB0",
          enemyPawnContacts: "\uC0C1\uB300 \uD3F0 \uC811\uC810",
          ongoing: "\uCCB4\uD06C\uBA54\uC774\uD2B8 \uC544\uB2D8",
          empty: "\uBE48 \uCE78",
          friendly: "\uC790\uAE30 \uAE30\uBB3C",
          enemy: "\uC0C1\uB300 \uAE30\uBB3C",
          relativeRank: "\uC790\uAE30 \uC9C4\uC601 \uAE30\uC900 \uB7AD\uD06C"
        },
        checkModeLabels: { king_move: "\uD0B9 \uC774\uB3D9", capture_checker: "\uCCB4\uD06C \uAE30\uBB3C \uD3EC\uD68D", interpose: "\uC0AC\uC774\uB9C9\uAE30" },
        movementModeLabels: {
          controlled_destination: "\uAE30\uD558\uC801\uC73C\uB85C \uD1B5\uC81C\uD55C \uCE78",
          pawn_advance: "\uD3F0 \uC804\uC9C4",
          pawn_double_advance: "\uD3F0 \uB450 \uCE78 \uC804\uC9C4",
          en_passant_capture: "\uC559\uD30C\uC0C1 \uD3EC\uD68D"
        },
        pawnFacetLabels: {
          doubled: "\uB354\uBE14\uD3F0",
          isolated: "\uACE0\uB9BD\uD3F0",
          passed: "\uD1B5\uACFC\uD3F0",
          geometrically_protected_passer: "\uAE30\uD558\uC801\uC73C\uB85C \uC9C0\uC6D0\uBC1B\uB294 \uD1B5\uACFC\uD3F0",
          front_state: "\uC55E\uCE78 \uC0C1\uD0DC",
          component: "\uC5F0\uACB0\uB41C \uD3F0 \uC9D1\uD569",
          connections: "\uD3F0 \uC5F0\uACB0",
          enemy_pawn_contacts: "\uC0C1\uB300 \uD3F0 \uC811\uC810",
          removed: "\uD3F0 \uC81C\uAC70"
        },
        pawnConnectionLabels: {
          supports: "\uAE30\uD558\uC801\uC73C\uB85C \uC9C0\uC6D0\uD568",
          supported_by: "\uAE30\uD558\uC801 \uC9C0\uC6D0\uC744 \uBC1B\uC74C",
          peer: "\uB098\uB780\uD788 \uC704\uCE58\uD568"
        },
        structuralChangeLabels: {
          open_file_established: "\uC5F4\uB9B0 \uD30C\uC77C \uC0DD\uC131",
          semi_open_file_established: "\uBC18\uC5F4\uB9B0 \uD30C\uC77C \uC0DD\uC131",
          pawn_tension_created: "\uD3F0 \uAE34\uC7A5 \uC0DD\uC131",
          pawn_tension_resolution: "\uD3F0 \uAE34\uC7A5 \uD574\uC18C",
          passed_pawn_progress: "\uD1B5\uACFC\uD3F0 \uBCC0\uD654",
          passed_pawn_status_removed: "\uD1B5\uACFC\uD3F0 \uC9C0\uC704 \uC0C1\uC2E4"
        },
        structuralSubjectLabels: {
          open_file: "\uC5F4\uB9B0 \uD30C\uC77C",
          semi_open_file: "\uBC18\uC5F4\uB9B0 \uD30C\uC77C",
          pawn_tension_created: "\uD3F0 \uAE34\uC7A5 \uC0DD\uC131",
          pawn_tension_resolved: "\uD3F0 \uAE34\uC7A5 \uD574\uC18C",
          passed_pawn_created: "\uD1B5\uACFC\uD3F0 \uC0DD\uC131",
          passed_pawn_lost: "\uD1B5\uACFC\uD3F0 \uC0C1\uC2E4",
          passed_pawn_advanced: "\uD1B5\uACFC\uD3F0 \uC804\uC9C4",
          passed_status_created: "\uD1B5\uACFC\uD3F0 \uC9C0\uC704 \uC0DD\uC131",
          passed_pawn_promoted: "\uD1B5\uACFC\uD3F0 \uC2B9\uACA9"
        },
        stalemateText: "{side} \uD0B9 {square}: \uCCB4\uD06C \uC0C1\uD0DC\uAC00 \uC544\uB2C8\uBA70 \uD569\uBC95 \uC218\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. \uC2A4\uD14C\uC77C\uBA54\uC774\uD2B8\uC785\uB2C8\uB2E4.",
        stopReasons: {
          engine_unavailable: "\uC5D4\uC9C4 \uD30C\uC77C\uC744 \uBD88\uB7EC\uC624\uAC70\uB098 \uC2DC\uC791\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
          browser_unsupported: "\uC774 \uBE0C\uB77C\uC6B0\uC800 \uD658\uACBD\uC740 \uD544\uC694\uD55C \uC5D4\uC9C4 \uC2E4\uD589 \uC870\uAC74\uC744 \uCDA9\uC871\uD558\uC9C0 \uBABB\uD569\uB2C8\uB2E4.",
          deadline_exceeded: "\uC774 \uCC29\uC218\uC758 \uBD84\uC11D \uC2E4\uD589 \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD588\uC2B5\uB2C8\uB2E4.",
          cancelled: "\uBD84\uC11D\uC774 \uCDE8\uC18C\uB410\uC2B5\uB2C8\uB2E4.",
          search_budget_exhausted: "\uC774 \uBD84\uC11D \uC791\uC5C5\uC758 \uC2E4\uD589 \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD588\uC2B5\uB2C8\uB2E4.",
          engine_execution_failed: "\uC5D4\uC9C4 \uC2E4\uD589 \uC911 \uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4.",
          invalid_engine_work_report: "\uBC1B\uC740 \uC5D4\uC9C4 \uACB0\uACFC\uAC00 \uC694\uCCAD\uD55C \uBD84\uC11D \uC870\uAC74\uACFC \uB9DE\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
          review_construction_failed: "\uBC1B\uC740 \uC790\uB8CC\uB85C \uD3C9\uAC00 \uD310\uC815\uC744 \uAD6C\uC131\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
          move_review_preparation_failed: "\uD3C9\uAC00\uB97C \uBE44\uAD50\uD558\uB294 \uB370 \uD544\uC694\uD55C \uC218\uC21C\uC744 \uC900\uBE44\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
          repetition_history_unavailable: "\uBC18\uBCF5 \uC5EC\uBD80\uB97C \uD655\uC778\uD560 \uC774\uC804 \uAE30\uBCF4\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4."
        },
        selectedReference: "\uC774\uBC88 \uBD84\uC11D\uC5D0\uC11C \uAC00\uC7A5 \uB192\uAC8C \uD3C9\uAC00\uD55C \uC218\uC785\uB2C8\uB2E4",
        terminalResult: "\uC885\uB8CC\uB41C \uD3EC\uC9C0\uC158",
        drawClaimAvailable: "\uBB34\uC2B9\uBD80 \uCCAD\uAD6C \uAC00\uB2A5",
        terminalLabels: {
          checkmate: "\uCCB4\uD06C\uBA54\uC774\uD2B8",
          stalemate: "\uC2A4\uD14C\uC77C\uBA54\uC774\uD2B8",
          insufficient_material: "\uAE30\uBB3C \uBD80\uC871 \uBB34\uC2B9\uBD80",
          fivefold_repetition: "5\uD68C \uB3D9\uD615\uBC18\uBCF5",
          seventy_five_move_rule: "75\uC218 \uADDC\uCE59"
        },
        drawRuleLabels: { threefold_repetition: "3\uD68C \uB3D9\uD615\uBC18\uBCF5", fifty_move_rule: "50\uC218 \uADDC\uCE59" },
        colorLabels: { white: "\uBC31", black: "\uD751" },
        drawAvailabilityLabels: {
          available_now: "\uC9C0\uAE08 \uCCAD\uAD6C \uAC00\uB2A5",
          available_by_declared_move: "\uC9C0\uC815 \uC218\uB85C \uCCAD\uAD6C \uAC00\uB2A5"
        },
        runnerUp: "\uCD08\uAE30 \uAC80\uC0C9 2\uC21C\uC704",
        proofStep: "\uB2E8\uACC4",
        addToStudy: "Study\uC5D0 \uC218\uC21C \uCD94\uAC00",
        addedToStudy: "Study\uC5D0 \uC218\uC21C\uC744 \uCD94\uAC00\uD588\uC2B5\uB2C8\uB2E4.",
        viewAddedLine: "\uCD94\uAC00\uD55C \uC218\uC21C \uBCF4\uAE30",
        showEvidence: "\uADFC\uAC70 \uD3BC\uCE58\uAE30",
        hideEvidence: "\uADFC\uAC70 \uC811\uAE30",
        proofBoard: "\uADFC\uAC70 \uC218\uC21C \uBBF8\uB2C8\uBCF4\uB4DC",
        winChance: "\uC2B9\uB9AC \uAC00\uB2A5\uC131",
        winChanceChange: "\uAC80\uD1A0 \uC218\uC758 \uAE30\uC900 \uB300\uBE44 \uBCC0\uD654",
        verdictLabels: { none: "\uC8FC\uC11D \uC5C6\uC74C", "?!": "\uC758\uC2EC\uC2A4\uB7EC\uC6B4 \uC218", "?": "\uC2E4\uC218", "??": "\uD070 \uC2E4\uC218" },
        verdictCodeLabels: {
          improves_on_reference: "\uAE30\uC900 \uC218\uBCF4\uB2E4 \uB098\uC740 \uC218",
          matches_reference: "\uAE30\uC900 \uC218\uC640 \uB3D9\uB4F1\uD55C \uC218",
          playable_loss: "\uCDA9\uBD84\uD788 \uB458 \uB9CC\uD55C \uC218",
          inaccuracy: "\uBD80\uC815\uD655\uD55C \uC218",
          mistake: "\uC2E4\uC218",
          blunder: "\uD070 \uC2E4\uC218"
        }
      },
      "en-US": {
        title: "Last move review",
        idleTitle: "No move to review yet",
        idleBody: "Make a move or select one in the notation.",
        analysing: "Reviewing the last move\u2026",
        completed: "Last move review complete.",
        liveEnginePaused: "The live engine is paused until this review finishes.",
        unavailable: "The last move review is unavailable.",
        unsupported: "Engine analysis could not start.",
        retry: "Retry",
        gradeNotRequested: "This move has not been graded.",
        requestGrade: "Analyze this move",
        observationsLoading: "Loading observations for the supplied moves\u2026",
        observationsMissing: "No supplied observations are available for this move.",
        best: "Initial search #1",
        played: "Played",
        alternative: "Alternative",
        candidateMoves: "Candidate moves",
        lineInsight: "Verified candidate line",
        forcedSingleMove: "Forced single move",
        candidateUnavailable: "Analysis was withheld for this candidate.",
        analysisStopped: "Analysis stopped",
        observationsTitle: "Verified move observations",
        workTitle: "Piece roles",
        comparisonUnavailable: "No comparison verdict was provided.",
        pathLabels: { played: "Selected move", analysis: "Analysis branch", history: "From the preceding move" },
        lineSourceLabels: {
          pgn_record: "Game line in the imported PGN",
          analysis: "Submitted analysis branch",
          study: "Study line \xB7 game origin unverified"
        },
        inputIssueText: {
          invalid_continuation: "Input line {line}: retained the valid continuation. The next move could not be admitted.",
          automatic_terminal: "Input line {line}: the game ended automatically; later moves were excluded.",
          input_limit: "Input line {line}: reached the input processing limit; retained the valid continuation."
        },
        roleLabels: {
          pawn: "pawn",
          knight: "knight",
          bishop: "bishop",
          rook: "rook",
          queen: "queen",
          king: "king"
        },
        captureText: "{side} {role} captures the {captured} on {square}.",
        recaptureText: "It recaptures the opposing piece that just captured.",
        recaptureUnknown: "Whether this capture was a recapture is unknown.",
        developmentText: "{side} {role} leaves its starting square {from} for {to} for the first time.",
        centralControlText: "From here it controls the central squares {squares}.",
        frameLabels: { before: "Before move", after: "After move" },
        controlRelationLabels: { support: "Geometric support", attack: "Geometric attack" },
        controlStateLabels: {
          present: "Present",
          absent: "Absent",
          unknown: "Unverified",
          removed: "Piece removed"
        },
        removedPiece: "Removed piece",
        controlChangeLabels: {
          created: "relationship created",
          retained: "relationship retained",
          lost: "relationship lost",
          removed: "relationship ended with piece removal"
        },
        observationDetails: "Pawn and structural details ({count})",
        resourceLabels: {
          square: "Square to inspect",
          choose: "Choose a square",
          controls: "Pieces controlling this square",
          outgoingControls: "Squares controlled by this piece",
          legalMoves: "Legal moves of this piece",
          noLegalMoves: "This piece has no legal move in this position.",
          pawnState: "Current pawn state",
          rookFile: "This rook\u2019s file",
          openFile: "Open file: neither side has a pawn on it.",
          semiOpenFile: "Semi-open for this rook\u2019s side: only opposing pawns are on it.",
          ownPawnFile: "This rook\u2019s side has pawns on the file.",
          unconfirmed: "Not established",
          friendlySupport: "Geometric support from friendly pieces",
          capturedOn: "Captured on",
          opposingControl: "Control by opposing pieces",
          rays: "Related rays",
          advances: "Related pawn advance paths",
          first: "First blocker",
          behind: "Pieces behind it (nearest first)",
          path: "Path",
          none: "None",
          partial: "Only partial evidence is available. Other resources have not been ruled out.",
          unavailable: "No evidence is available for this position.",
          legal: "Legal move",
          illegal: "Move is not legal in this position",
          not_turn: "Not this piece\u2019s turn. Legality has not been assessed.",
          unknown: "Legality unknown",
          relationships: "Piece relationships"
        },
        lineLabels: {
          title: "Within this line",
          material: "Material change",
          units: "Material changes for {side}, relative to the line\u2019s start, in pawn units. These are not engine evaluations.",
          delta: "Change at this move",
          balance: "Running change",
          net: "Change at line end",
          maximum: "Highest running change",
          minimum: "Lowest running change",
          recovered: "After a loss, the running change returned to at least zero within this line. Further losses may follow.",
          noMaterialEvents: "No material-changing events in this line.",
          missingMaterial: "Material evidence is unavailable for this line.",
          missingSummary: "Result evidence is unavailable for this line.",
          limit: "These results were observed within the displayed line. They do not establish a forced or lasting gain against best play.",
          line_end: "The supplied or analyzed line stops here.",
          checkmate: "The line ends in checkmate.",
          stalemate: "The line ends in stalemate.",
          promotionGain: "Material added by promotion",
          value: "Piece value"
        },
        lineEventLabels: {
          capture: "Capture",
          recapture: "Immediate recapture",
          check_evasion: "Check response",
          castling: "Castling",
          check: "Check",
          mate: "Checkmate",
          stalemate: "Stalemate",
          promotion: "Promotion"
        },
        lineEventText: {
          recapture: "{side} {role} recaptures the {captured} on {square}.",
          check_evasion: "{side} gets out of check.",
          castling: "{side} castles, placing the king on {square}.",
          check: "{side} gives check to the king on {square}.",
          mate: "{side} checkmates the king on {square}.",
          stalemate: "{side} stalemates the opposing king on {square}.",
          promotion: "{side} promotes to a {captured} on {square}."
        },
        observationLabels: {
          recapture_resources: "Recapture resources",
          check_responses: "Check and legal responses",
          check_response: "Selected check response",
          pawn_structure: "Pawn structure change",
          stalemate: "Stalemate",
          castling: "Castling",
          promotion: "Promotion",
          structural_change: "Structural evidence"
        },
        illegalRecaptureText: "If {piece} recaptures on {square}, {controllers} would attack its king on {king}; this recapture is illegal.",
        observationFields: {
          none: "None",
          yes: "Yes",
          no: "No",
          geometric: "Geometric recapturers",
          legal: "Legal responses",
          restricted: "Restricted responses",
          captured: "Captured piece",
          checkers: "Checking pieces",
          king: "King",
          relatedTargets: "Related targets",
          pins: "Absolute pin paths",
          controlledDestinations: "Controlled king destinations",
          frontSquare: "Front square",
          frontOccupant: "Front occupant",
          component: "Connected pawn group",
          connections: "Pawn connections",
          enemyPawnContacts: "Enemy pawn contacts",
          ongoing: "Not checkmate",
          empty: "Empty square",
          friendly: "Friendly piece",
          enemy: "Enemy piece",
          relativeRank: "Relative rank"
        },
        checkModeLabels: { king_move: "King move", capture_checker: "Capture checker", interpose: "Interpose" },
        movementModeLabels: {
          controlled_destination: "Geometrically controlled destination",
          pawn_advance: "Pawn advance",
          pawn_double_advance: "Double pawn advance",
          en_passant_capture: "En passant capture"
        },
        pawnFacetLabels: {
          doubled: "Doubled",
          isolated: "Isolated",
          passed: "Passed",
          geometrically_protected_passer: "Geometrically protected passer",
          front_state: "Front square state",
          component: "Connected pawn group",
          connections: "Pawn connections",
          enemy_pawn_contacts: "Enemy pawn contacts",
          removed: "Pawn removed"
        },
        pawnConnectionLabels: {
          supports: "Geometrically supports",
          supported_by: "Geometrically supported by",
          peer: "In phalanx with"
        },
        structuralChangeLabels: {
          open_file_established: "Open file established",
          semi_open_file_established: "Semi-open file established",
          pawn_tension_created: "Pawn tension created",
          pawn_tension_resolution: "Pawn tension resolved",
          passed_pawn_progress: "Passed pawn change",
          passed_pawn_status_removed: "Passed status removed"
        },
        structuralSubjectLabels: {
          open_file: "Open file",
          semi_open_file: "Semi-open file",
          pawn_tension_created: "Pawn tension created",
          pawn_tension_resolved: "Pawn tension resolved",
          passed_pawn_created: "Passed pawn created",
          passed_pawn_lost: "Passed pawn lost",
          passed_pawn_advanced: "Passed pawn advanced",
          passed_status_created: "Passed status created",
          passed_pawn_promoted: "Passed pawn promoted"
        },
        stalemateText: "{side} king on {square} is not in check and has no legal moves. Stalemate.",
        stopReasons: {
          engine_unavailable: "The engine files could not be loaded or started.",
          browser_unsupported: "This browser environment does not meet the engine requirements.",
          deadline_exceeded: "This move reached its analysis time limit.",
          cancelled: "Analysis was cancelled.",
          search_budget_exhausted: "This analysis work reached its execution limit.",
          engine_execution_failed: "The engine failed during analysis.",
          invalid_engine_work_report: "The engine result did not match the requested analysis conditions.",
          review_construction_failed: "The available evidence could not support an evaluation verdict.",
          move_review_preparation_failed: "The lines needed for the evaluation comparison could not be prepared.",
          repetition_history_unavailable: "The earlier moves needed to check repetition are unavailable."
        },
        selectedReference: "The highest-rated move in this analysis",
        terminalResult: "Terminal position",
        drawClaimAvailable: "Draw claim available",
        terminalLabels: {
          checkmate: "Checkmate",
          stalemate: "Stalemate",
          insufficient_material: "Insufficient material",
          fivefold_repetition: "Fivefold repetition",
          seventy_five_move_rule: "Seventy-five-move rule"
        },
        drawRuleLabels: { threefold_repetition: "Threefold repetition", fifty_move_rule: "Fifty-move rule" },
        colorLabels: { white: "White", black: "Black" },
        drawAvailabilityLabels: {
          available_now: "Available now",
          available_by_declared_move: "Available by declared move"
        },
        runnerUp: "Initial search #2",
        proofStep: "Step",
        addToStudy: "Add line to Study",
        addedToStudy: "Line added to Study.",
        viewAddedLine: "View added line",
        showEvidence: "Show evidence",
        hideEvidence: "Hide evidence",
        proofBoard: "Proof line mini-board",
        winChance: "Win chance",
        winChanceChange: "Reviewed change from reference",
        verdictLabels: { none: "No annotation", "?!": "Dubious", "?": "Mistake", "??": "Blunder" },
        verdictCodeLabels: {
          improves_on_reference: "Improves on the reference",
          matches_reference: "Matches the reference",
          playable_loss: "Playable",
          inaccuracy: "Inaccuracy",
          mistake: "Mistake",
          blunder: "Blunder"
        }
      }
    };
    requestIdPattern = /^[A-Za-z0-9._:-]{1,128}$/;
    jobIdPattern = /^[A-Za-z0-9_-]{32}$/;
    workIdPattern = /^work:[0-9]+$/;
    sha256Pattern = /^[a-f0-9]{64}$/;
    uciPattern = /^[a-h][1-8][a-h][1-8][qrbn]?$/;
  }
});

// research/critical-comparison-20261007/engine-bridge.ts
init_fen();
init_san();
init_util();
init_variant();
import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { performance as performance2 } from "node:perf_hooks";
import { createRequire } from "node:module";
import { resolve } from "node:path";
var { JSDOM } = createRequire(resolve("target/relationship-delivery-20261004/frontend-probe/package.json"))("jsdom");
var dom = new JSDOM("<!doctype html><html><body></body></html>", { url: "http://localhost/", pretendToBeVisual: true });
Object.assign(globalThis, {
  window: dom.window,
  document: dom.window.document,
  HTMLElement: dom.window.HTMLElement,
  Event: dom.window.Event,
  requestAnimationFrame: dom.window.requestAnimationFrame.bind(dom.window),
  cancelAnimationFrame: dom.window.cancelAnimationFrame.bind(dom.window)
});
var { Protocol: Protocol2 } = await Promise.resolve().then(() => (init_protocol(), protocol_exports));
var { makeMoveReviewWork: makeMoveReviewWork2 } = await Promise.resolve().then(() => (init_types2(), types_exports));
var { decodeMoveReviewSnapshot: decodeMoveReviewSnapshot2, moveReviewEngineOutcomeAtRequiredDepth: moveReviewEngineOutcomeAtRequiredDepth2, buildMoveReviewEngineWorkReport: buildMoveReviewEngineWorkReport2 } = await Promise.resolve().then(() => (init_moveReview(), moveReview_exports));
var started = performance2.now();
export { decodeMoveReviewSnapshot2 as decode, moveReviewSan, projectCommon, dom };

export { projectObservations };
