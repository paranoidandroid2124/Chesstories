import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {decode,moveReviewSan} from './held-normal21-source-control-decoder.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex');
const plan=JSON.parse(readFileSync(new URL('./audit-plan.json',import.meta.url),'utf8'));
const rows=[];
for(const file of plan.snapshots){
 const bytes=readFileSync(file.path);
 if(sha(bytes)!==file.sha256) throw Error('snapshot drift');
 const raw=JSON.parse(gunzipSync(bytes).toString('utf8'));
 const q=raw.request,s=raw.snapshot;
 const subject={variant:q.variant,initialFen:q.initial_fen,movePrefixUci:q.move_prefix_uci,
 before:{path:'',fen:q.current_fen},played:{uci:q.focus.played_move_uci,san:moveReviewSan(q.current_fen,q.focus.played_move_uci)},
 after:{path:'probe',fen:q.focus.resulting_fen}};
 const selected=obs=>(obs?.selection?.candidates??[]).find(c=>c.detail?.type==='root_comparison'&&c.selection==='selected');
 const before=JSON.stringify(s),root=selected(s.observations);
 const start=performance.now();
 let d,error;
 try{d=decode(s,{requestId:q.request_id,subject});}catch(e){error=String(e);}
 rows.push({id:raw.game_id,snapshot_sha256:file.sha256,decoded_kind:d?.kind??null,error:error??null,
 accepted_completed:d?.kind==='completed',selection_retained:!!d?.observations?.selection,
 root_detail_unchanged:JSON.stringify(selected(d?.observations)?.detail??null)===JSON.stringify(root?.detail??null),
 raw_response_unmutated:JSON.stringify(s)===before,elapsed_ms:Math.round(performance.now()-start)});
}
const result={schema_version:1,scope:'Untouched actual final eight responses through frozen normalUI21 decoder; no reprojection, overlays or engines',
 decoder_sha256:sha(readFileSync(new URL('./held-normal21-source-control-decoder.mjs',import.meta.url))),
 passed:rows.every(r=>r.accepted_completed&&r.selection_retained&&r.root_detail_unchanged&&r.raw_response_unmutated&&!r.error),
 new_engine_queries:0,cases:rows};
writeFileSync(new URL('./normal21-decoder-audit.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
